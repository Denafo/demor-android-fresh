# Latest storefront improvement — 15 October 2026

Read `PEHLE-PADHO.txt` and `WEBSITE-UPDATE-15-OCT-2026.md` first for this update. No new database migration or secret is needed when updating the already configured payment store. The setup instructions below are for a fresh installation.

# DEMOR — Razorpay checkout and My Orders

Start with PAYMENT-SETUP.txt and UPGRADE-PAYMENTS.html. Keep the previous ZIP as a backup.

Node 22+, Netlify Functions, Neon PostgreSQL, plain HTML/CSS/JavaScript, Razorpay Node SDK. Secrets belong in Netlify Functions environment variables, not public files.

Includes server-priced payment orders, timing-safe HMAC verification plus captured payment validation, signed webhooks, retry recovery, browser-saved My Orders, and owner-entered delivery details. COD and automatic courier integration are not included.

This update is not live until deployed. Sandbox tests are mocked; perform an actual Razorpay test-mode checkout after configuring new keys. See PAYMENT-SETUP.txt for the complete testing and live-mode checklist.

Validation: 18 automated tests passed (mock gateway + PGlite + DOM frontend tests), production build passed, and Netlify function module imported successfully. Full provider test-mode checkout remains a manual step.
