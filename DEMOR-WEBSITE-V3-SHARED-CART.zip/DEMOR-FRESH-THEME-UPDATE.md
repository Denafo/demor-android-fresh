DEMOR Fresh Theme + My Orders Upgrade

Included in this update:
- Lighter, fresher premium theme across the storefront
- Softer green-gold premium accent instead of heavy dark look
- Homepage positioning updated for blazers, Jodhpuri, kurtas and occasion wear
- Improved category card visuals and section polish
- Better My Orders page with:
  - quick service highlights
  - richer order cards
  - order summary highlight boxes
  - improved buttons, chips and support blocks
  - more polished mobile and desktop presentation

Notes:
- This update is focused on layout/design refinement and better customer-facing order experience.
- Order logic, cancellation logic and Shiprocket-related backend added in previous ZIP remain in place.
- Live deploy and payment/shiprocket testing should still be done carefully after upload.
- Automated tests were not run in this environment because local test dependencies were unavailable.
