import {access} from 'node:fs/promises';
await access(new URL('../server/product-upgrade.sql',import.meta.url));
console.log('DEMOR storefront uses live database products. Run product-upgrade.sql and payments.sql before deployment.');
