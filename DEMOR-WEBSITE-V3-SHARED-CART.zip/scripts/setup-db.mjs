import {neon} from '@neondatabase/serverless';
import {readFile} from 'node:fs/promises';
if(!process.env.DATABASE_URL)throw Error('Set DATABASE_URL privately before running this command.');
const sql=neon(process.env.DATABASE_URL);
const statements=(await readFile(new URL('../server/schema.sql',import.meta.url),'utf8')).split(';').map(s=>s.trim()).filter(Boolean);
await sql.transaction(statements.map(s=>sql.query(s,[])));
console.log('Core tables are ready. Next run the complete server/product-upgrade.sql in Neon SQL Editor; do not split that file on semicolons.');
