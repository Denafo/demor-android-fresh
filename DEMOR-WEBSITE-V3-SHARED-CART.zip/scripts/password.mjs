import {random,passwordHash} from '../server/security.mjs';
const password=random(),secret=random();
console.log('Keep this output private. Save the owner password in your password manager.');
console.log('\nOWNER PASSWORD (use on /admin):\n'+password);
console.log('\nNetlify environment variable DEMOR_OWNER_HASH:\n'+await passwordHash(password));
console.log('\nNetlify environment variable DEMOR_SESSION_SECRET:\n'+secret);
console.log('\nDEMOR_ORIGIN=https://demor.in\nUse the actual canonical HTTPS address if different.');
