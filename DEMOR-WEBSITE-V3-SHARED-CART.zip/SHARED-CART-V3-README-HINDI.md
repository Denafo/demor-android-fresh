# DEMOR Website V3 — Shared Cart

This update adds an authenticated shared-cart API and website customer bag syncing. All cart rows are indexed by server-verified Netlify Identity user ID; the API never accepts user_id/email or product prices from the request body.

## Migration first (required)
1. Open your **existing** DEMOR Neon database project > SQL Editor.
2. Paste and run `server/cart-sync-migration.sql` as provided in this package.
3. The SQL creates only `demor_customer_carts`; it does not alter orders, products, payment or login tables.
4. Take a database backup/snapshot before changing production tables. If you don't have one, don't deploy yet.
5. Deploy this WHOLE website ZIP to the actual demor.in Netlify project. This site has Netlify Functions; if Netlify's manual ZIP deployment does not deploy functions, use a build-based Netlify deployment from the full source repository instead.

## Check
- Anonymous GET /api/my-cart: JSON 401 unauthorized (expected).
- After logging into demor.in, add a product to bag.
- After Android V3 sign-in, open Bag and press Sync; it should load the product.
- Change quantity in app, return to browser and refresh/focus cart.html.
- Test two different logins: each sees only their own cart.
- Test new products, stock changes, add/remove, checkout without paying real money.

## Rollback
The previous Netlify published deploy can be re-published. The new table is additive and may be left unused; do not delete it without an approved data-retention/rollback plan.

## Limitations
- No automatic syncing when logged out: anonymous carts are local to each device.
- Mobile app checkout stays disabled until secure payment integration is complete.
- Cart sync relies on a valid Netlify Identity session and connection. A status on cart.html warns if saving failed.
