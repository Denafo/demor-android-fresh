import Razorpay from 'razorpay';
import {createHmac} from 'node:crypto';
import {equal,hash} from './security.mjs';
export class PaymentError extends Error{constructor(message,status=400){super(message);this.status=status}}
const need=(condition,message,status=400)=>{if(!condition)throw new PaymentError(message,status)};
const validId=(value,prefix)=>typeof value==='string'&&new RegExp('^'+prefix+'_[a-zA-Z0-9]{1,80}$').test(value);
export function validSignature(message,signature,secret){return typeof signature==='string'&&/^[a-f0-9]{64}$/.test(signature)&&equal(createHmac('sha256',secret).update(message).digest('hex'),signature)}
export function makePayments({query,env,clock,gateway}){
 const mode=env.RAZORPAY_MODE||'test';
 const ready=()=>['test','live'].includes(mode)&&new RegExp('^rzp_'+mode+'_[A-Za-z0-9]+$').test(env.RAZORPAY_KEY_ID||'')&&!!env.RAZORPAY_KEY_SECRET&&(mode!=='live'||env.RAZORPAY_WEBHOOK_SECRET?.length>=32);
 const client=()=>{need(ready(),'Online payments are not configured. Please contact the store.',503);if(gateway)return gateway;const instance=new Razorpay({key_id:env.RAZORPAY_KEY_ID,key_secret:env.RAZORPAY_KEY_SECRET});instance.api.rq.defaults.timeout=10000;return instance};
 async function remote(fn){try{return await fn(client())}catch(e){if(e instanceof PaymentError)throw e;const auth=e.statusCode===401||e.status===401;throw new PaymentError(auth?'Payment service authentication failed. Please contact the store.':'Payment service is unavailable. Please check My Orders before retrying.',auth?401:500)}}
 async function owned(d){
  need(typeof d.id==='string'&&d.id.length<80,'Order number required');
  const [order]=await query('SELECT * FROM demor_orders WHERE id=$1',[d.id]);
  const byToken=order&&typeof d.token==='string'&&d.token.length<100&&d.token&&equal(order.token_hash,hash(d.token));
  const byAccount=order&&typeof d._verified_account_id==='string'&&d._verified_account_id&&order.customer?.account_id===d._verified_account_id;
  need(byToken||byAccount,'Order does not belong to this account',404);
  return order;
 }
 async function payment(id){const [p]=await query('SELECT * FROM demor_payments WHERE store_id=$1',[id]);return p}
 const label=p=>!p?null:(p.mode==='test'?'TEST — ':'')+({captured:'Paid online',refunded:'Refunded online',partial_refund:'Partially refunded online',authorized:'Payment processing',failed:'Payment failed',creating:'Payment setup pending',unknown:'Payment setup needs review',retry:'Awaiting payment',ready:'Awaiting payment'}[p.state]||'Payment pending');
 async function publicOrder(order){const p=await payment(order.id);return {id:order.id,created:order.created,items:order.items,total:order.total,status:order.status,payment:label(p)||order.payment,delivery:order.delivery||{},payment_mode:p?.mode||null,payment_state:p?.state||null,refunded_paise:p?.refunded||0,can_pay:ready()&&order.status!=='Cancelled'&&['New','Confirmed','Packed'].includes(order.status)&&!['Paid externally','Refunded externally'].includes(order.payment)&&(!p||!['captured','refunded','partial_refund','authorized'].includes(p.state))&&(!p||p.key_id===env.RAZORPAY_KEY_ID),review_required:order.status==='Cancelled'&&(['captured','partial_refund','authorized'].includes(p?.state)||order.payment==='Refund requested')}}
 async function create(d){
  const order=await owned(d);client();need(['New','Confirmed','Packed'].includes(order.status),'This order cannot accept a new payment.',409);need(!['Paid externally','Refunded externally'].includes(order.payment),'This order already has an external payment record. Contact the store.',409);
  const amount=order.total*100;need(Number.isSafeInteger(amount)&&amount>=100&&amount<=2147483647,'Order amount is invalid or below ₹1');
  // Claim before contacting Razorpay. A timeout is kept for reconciliation, never blindly re-created.
  const claims=await query(`INSERT INTO demor_payments(store_id,key_id,mode,amount,updated) VALUES($1,$2,$3,$4,$5)
ON CONFLICT(store_id) DO UPDATE SET state='creating',updated=$5 WHERE demor_payments.state='retry' AND demor_payments.provider_order_id IS NULL AND demor_payments.key_id=$2 RETURNING store_id`,[order.id,env.RAZORPAY_KEY_ID,mode,amount,clock()]);
  let p=await payment(order.id);need(p.key_id===env.RAZORPAY_KEY_ID,'This order belongs to an earlier payment configuration. Contact the store.',409);
  need(!['captured','refunded','partial_refund','authorized'].includes(p.state),'Payment already received or processing. Refresh My Orders.',409);
  if(claims.length){
   let provider;
   try{provider=await client().orders.create({amount,currency:'INR',receipt:order.id,partial_payment:false,notes:{demor_order:order.id}})}catch(e){const code=e.statusCode||e.status;await query("UPDATE demor_payments SET state=$2,updated=$3 WHERE store_id=$1 AND provider_order_id IS NULL",[order.id,[400,401,403,422].includes(code)?'retry':'unknown',clock()]);throw new PaymentError(code===401?'Payment service authentication failed. Please contact the store.':'Could not start payment. Your order is saved in My Orders; do not create another order.',code===401?401:500)}
   need(validId(provider.id,'order')&&provider.amount===amount&&provider.currency==='INR','Payment provider returned an unexpected order. Contact the store.',500);
   await query("UPDATE demor_payments SET provider_order_id=$2,state='ready',updated=$3 WHERE store_id=$1 AND provider_order_id IS NULL",[order.id,provider.id,clock()]);p=await payment(order.id);
  }
  need(p.provider_order_id,'Payment setup is still pending. Wait briefly and refresh My Orders. If it persists, contact the store with your order number.',409);
  return {order_id:p.provider_order_id,amount:p.amount,currency:'INR',key_id:p.key_id,mode:p.mode,store_order_id:order.id};
 }
 async function apply(store,p,entity){
  need(validId(entity.id,'pay')&&entity.order_id===p.provider_order_id&&entity.amount===p.amount&&entity.currency==='INR','Payment does not match this order',400);
  const refunded=entity.amount_refunded||0;need(Number.isSafeInteger(refunded)&&refunded>=0&&refunded<=p.amount,'Invalid refunded amount',400);
  let state;if(entity.status==='captured'&&entity.captured===true)state=refunded===p.amount?'refunded':refunded>0?'partial_refund':'captured';else if(entity.status==='refunded'&&refunded===p.amount)state='refunded';else if(entity.status==='authorized')state='authorized';else if(entity.status==='failed')state='failed';else return publicOrder(store);
  // Monotonic transitions: delayed failures/auths cannot undo captured/refunded funds.
  await query(`UPDATE demor_payments SET payment_id=CASE WHEN $3='failed' THEN payment_id ELSE $2 END,state=$3,refunded=GREATEST(refunded,$4),updated=$5
WHERE store_id=$1 AND (state NOT IN ('captured','partial_refund','refunded') OR payment_id=$2)
AND (state NOT IN ('captured','partial_refund','refunded') OR ($3 IN ('captured','partial_refund','refunded') AND $4>=refunded))`,[store.id,entity.id,state,refunded,clock()]);
  return publicOrder(store);
 }
 async function verify(d){
  const order=await owned(d);const p=await payment(order.id);need(p?.provider_order_id,'No payment order found');need(p.key_id===env.RAZORPAY_KEY_ID,'Payment configuration changed. Contact the store.',409);
  need(validId(d.razorpay_order_id,'order')&&validId(d.razorpay_payment_id,'pay')&&typeof d.razorpay_signature==='string','Payment verification fields are required');
  need(d.razorpay_order_id===p.provider_order_id&&validSignature(p.provider_order_id+'|'+d.razorpay_payment_id,d.razorpay_signature,env.RAZORPAY_KEY_SECRET||''),'Payment signature is invalid');
  const entity=await remote(c=>c.payments.fetch(d.razorpay_payment_id));return apply(order,p,entity);
 }
 async function refresh(d){const order=await owned(d),p=await payment(order.id);if(!p?.provider_order_id)return publicOrder(order);need(p.key_id===env.RAZORPAY_KEY_ID,'Payment configuration changed. Contact the store.',409);const list=await remote(c=>c.orders.fetchPayments(p.provider_order_id));const items=list.items||[];const captured=items.find(x=>x.status==='captured'||x.status==='refunded')||items.find(x=>x.status==='authorized')||items.find(x=>x.status==='failed');return captured?apply(order,p,captured):publicOrder(order)}
 async function webhook(raw,signature){
  need(env.RAZORPAY_WEBHOOK_SECRET?.length>=32,'Webhook is not configured',503);need(validSignature(raw,signature,env.RAZORPAY_WEBHOOK_SECRET),'Invalid webhook signature',400);
  let event;try{event=JSON.parse(raw)}catch{throw new PaymentError('Invalid webhook JSON')}
  if(!['payment.captured','payment.authorized','payment.failed','order.paid','refund.processed'].includes(event.event))return {ok:true};
  const candidate=event.payload?.payment?.entity;const pid=candidate?.id||event.payload?.refund?.entity?.payment_id;need(validId(pid,'pay'),'Invalid payment event');
  // Fetch current provider truth: handles retries/out-of-order/refund events without trusting browser state.
  const entity=await remote(c=>c.payments.fetch(pid));const [p]=await query('SELECT * FROM demor_payments WHERE provider_order_id=$1',[entity.order_id]);
  if(!p)return {ok:true,unmatched:true};need(p.key_id===env.RAZORPAY_KEY_ID,'Payment configuration mismatch',409);
  const [order]=await query('SELECT * FROM demor_orders WHERE id=$1',[p.store_id]);await apply(order,p,entity);return {ok:true};
 }
 async function recover(d){
  need(typeof d.id==='string'&&validId(d.provider_order_id,'order'),'Store and Razorpay order IDs are required');const p=await payment(d.id);need(p&&!p.provider_order_id&&['creating','unknown'].includes(p.state),'No unresolved payment setup for this order',409);need(p.key_id===env.RAZORPAY_KEY_ID,'Use the original payment configuration',409);
  const remoteOrder=await remote(c=>c.orders.fetch(d.provider_order_id));need(remoteOrder.id===d.provider_order_id&&remoteOrder.receipt===d.id&&remoteOrder.amount===p.amount&&remoteOrder.currency==='INR','Provider order does not match this store order');
  await query("UPDATE demor_payments SET provider_order_id=$2,state='ready',updated=$3 WHERE store_id=$1 AND provider_order_id IS NULL",[d.id,d.provider_order_id,clock()]);return {ok:true};
 }
 return {create,verify,refresh,webhook,recover,publicOrder,config:()=>({enabled:!!ready(),mode})};
}
