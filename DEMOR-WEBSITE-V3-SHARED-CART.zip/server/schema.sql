CREATE TABLE IF NOT EXISTS demor_orders (
 id TEXT PRIMARY KEY,
 token_hash TEXT NOT NULL,
 request_hash TEXT UNIQUE NOT NULL,
 payload_hash TEXT NOT NULL,
 created DOUBLE PRECISION NOT NULL,
 customer JSONB NOT NULL,
 items JSONB NOT NULL,
 total INTEGER NOT NULL CHECK(total >= 0),
 status TEXT NOT NULL DEFAULT 'New',
 payment TEXT NOT NULL DEFAULT 'Pending',
 notes TEXT NOT NULL DEFAULT '',
 revision INTEGER NOT NULL DEFAULT 1,
 history JSONB NOT NULL DEFAULT '[]'
);
CREATE TABLE IF NOT EXISTS demor_tickets (
 id TEXT PRIMARY KEY,
 request_hash TEXT UNIQUE NOT NULL,
 payload_hash TEXT NOT NULL,
 created DOUBLE PRECISION NOT NULL,
 data JSONB NOT NULL,
 status TEXT NOT NULL DEFAULT 'Open',
 notes TEXT NOT NULL DEFAULT '',
 revision INTEGER NOT NULL DEFAULT 1,
 history JSONB NOT NULL DEFAULT '[]'
);
CREATE TABLE IF NOT EXISTS demor_sessions (
 token_hash TEXT PRIMARY KEY,
 owner_version TEXT NOT NULL,
 expires DOUBLE PRECISION NOT NULL
);
CREATE TABLE IF NOT EXISTS demor_limits (
 key TEXT PRIMARY KEY,
 start DOUBLE PRECISION NOT NULL,
 count INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS demor_orders_created ON demor_orders(created DESC);
CREATE INDEX IF NOT EXISTS demor_tickets_created ON demor_tickets(created DESC);

-- Account cart shared by website and Android; login token determines the owner.
CREATE TABLE IF NOT EXISTS demor_customer_carts (
 account_id TEXT PRIMARY KEY,
 items JSONB NOT NULL DEFAULT '[]'::jsonb,
 revision INTEGER NOT NULL DEFAULT 0,
 updated DOUBLE PRECISION NOT NULL
);
