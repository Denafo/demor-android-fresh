// Server-only Shiprocket API client. Never expose API credentials or bearer tokens to browsers.
const BASE='https://apiv2.shiprocket.in/v1/external';
export class ShiprocketError extends Error{constructor(message,status=502){super(message);this.status=status}}
const fail=()=>new ShiprocketError('Shiprocket is unavailable or rejected the request. Check its dashboard before retrying.');
export function makeShiprocket({env,fetcher=globalThis.fetch}){
 const ready=()=>Boolean(env.SHIPROCKET_API_EMAIL&&env.SHIPROCKET_API_PASSWORD);
 async function request(path,{method='GET',payload,token}={}){
  let response;
  try{response=await fetcher(BASE+path,{method,headers:{'Accept':'application/json',...(payload?{'Content-Type':'application/json'}:{}),...(token?{'Authorization':'Bearer '+token}:{})},...(payload?{body:JSON.stringify(payload)}:{}),signal:AbortSignal.timeout(12000)})}
  catch{throw fail()}
  let data={};try{data=await response.json()}catch{}
  if(!response.ok||data?.status_code>=400||data?.success===false)throw fail();
  return data;
 }
 async function auth(){if(!ready())throw new ShiprocketError('Shiprocket credentials have not been configured.',503);
  const result=await request('/auth/login',{method:'POST',payload:{email:env.SHIPROCKET_API_EMAIL,password:env.SHIPROCKET_API_PASSWORD}});
  if(typeof result.token!=='string'||result.token.length<20)throw fail();return result.token;
 }
 async function queryCourier({pickup,drop,weight,cod}){
  const token=await auth();const params=new URLSearchParams({pickup_postcode:String(pickup),delivery_postcode:String(drop),weight:String(weight),cod:cod?'1':'0'});
  const result=await request('/courier/serviceability/?'+params,{token});
  const candidates=result.data?.available_courier_companies;
  if(!Array.isArray(candidates))return [];
  return candidates.map(c=>({id:Number(c.courier_company_id),name:String(c.courier_name||c.courier_company_name||'Courier').slice(0,80),rate:Number(c.rate),freight:Number(c.freight_charge),cod:Number(c.cod_charges||0),etd:String(c.etd||'').slice(0,60)})).filter(c=>Number.isInteger(c.id)&&c.id>0).sort((a,b)=>(Number.isFinite(a.rate)?a.rate:999999)-(Number.isFinite(b.rate)?b.rate:999999)).slice(0,12);
 }
 async function createOrder(payload){const token=await auth();const r=await request('/orders/create/adhoc',{method:'POST',payload,token});
  if(!Number.isInteger(Number(r.order_id))||!Number.isInteger(Number(r.shipment_id)))throw fail();
  return {order_id:Number(r.order_id),shipment_id:Number(r.shipment_id)};
 }
 async function assignAwb(shipment_id,courier_id){const token=await auth();const r=await request('/courier/assign/awb',{method:'POST',payload:{shipment_id,courier_id},token});
  const data=r.response?.data||r.data||r;const awb=String(data.awb_code||r.awb_code||'');
  if(!/^[A-Za-z0-9-]{5,80}$/.test(awb))throw fail();
  return {awb,carrier:String(data.courier_name||r.courier_name||'Shiprocket courier').slice(0,80)};
 }
 async function track(awb){const token=await auth();const r=await request('/courier/track/awb/'+encodeURIComponent(awb),{token});
  const track=r.tracking_data?.shipment_track?.[0]||r.data?.shipment_track?.[0]||{};
  const updates=r.tracking_data?.shipment_track_activities||r.data?.shipment_track_activities||[];
  const label=String(track.current_status||updates[0]?.activity||'Tracking details not available yet').slice(0,160);
  return {status:label};
 }
 return {ready,auth,queryCourier,createOrder,assignAwb,track};
}
