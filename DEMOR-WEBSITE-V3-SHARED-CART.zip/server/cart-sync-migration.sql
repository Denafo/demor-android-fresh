-- Run once in your EXISTING DEMOR Neon database before deploying new API.
-- Does not delete or modify products, orders, payments or existing users.
CREATE TABLE IF NOT EXISTS demor_customer_carts (
  account_id TEXT PRIMARY KEY,
  items JSONB NOT NULL DEFAULT '[]'::jsonb,
  revision INTEGER NOT NULL DEFAULT 0,
  updated DOUBLE PRECISION NOT NULL
);
