import {createHash,createHmac,randomBytes,scrypt as scryptCallback,timingSafeEqual} from 'node:crypto';
import {promisify} from 'node:util';
const scrypt=promisify(scryptCallback);
export const hash=value=>createHash('sha256').update(value).digest('hex');
export const random=()=>randomBytes(32).toString('base64url');
export function equal(a,b){const x=Buffer.from(a),y=Buffer.from(b);return x.length===y.length&&timingSafeEqual(x,y)}
export async function passwordHash(password){const salt=randomBytes(16).toString('hex');const key=await scrypt(password,salt,64,{N:16384,r:8,p:1});return `scrypt:${salt}:${key.toString('hex')}`}
export async function passwordMatches(password,encoded){const [type,salt,key]=encoded.split(':');if(type!=='scrypt'||!salt||!key)return false;const actual=await scrypt(password,salt,64,{N:16384,r:8,p:1});return equal(actual.toString('hex'),key)}
export const trackingCode=(secret,key)=>createHmac('sha256',secret).update('order:'+key).digest('base64url');
