import {makePayments,PaymentError} from './payments.mjs';
import {makeShiprocket,ShiprocketError} from './shiprocket.mjs';
import {hash,random,equal,passwordMatches,trackingCode} from './security.mjs';
const statuses=['New','Confirmed','Packed','Shipped','Delivered','Cancelled'];
const payments=['Pending','COD due','Paid externally','Payment issue','Refund requested','Refund approved','Refunded externally'];
class Problem extends Error{constructor(message,status=400){super(message);this.status=status}}
const check=(condition,message,status)=>{if(!condition)throw new Problem(message,status)};
const txt=(value='',max=2000)=>{check(typeof value==='string'&&value.length<=max,'Invalid text field');return value.trim()};
const reply=(data,status=200,headers={})=>new Response(JSON.stringify(data),{status,headers:{'Content-Type':'application/json','Cache-Control':'no-store','X-Content-Type-Options':'nosniff',...headers}});
function cookieToken(request){return request.headers.get('cookie')?.split(';').map(x=>x.trim()).find(x=>x.startsWith('__Host-demor_session='))?.slice('__Host-demor_session='.length)||''}
const cookie=value=>`__Host-demor_session=${value}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${value?28800:0}`;
export function makeHandler({query,env,catalog,clock=()=>Date.now()/1000,gateway,shiprocketFetch,identityFetch=fetch}){
 const pay=makePayments({query,env,clock,gateway});
 const ship=makeShiprocket({env,fetcher:shiprocketFetch});
 async function rate(kind,ip,max){
  const now=clock(),key=hash(kind+':'+ip);
  const [r]=await query(`INSERT INTO demor_limits (key,start,count) VALUES ($1,$2,1)
ON CONFLICT (key) DO UPDATE SET start=CASE WHEN demor_limits.start < $2-900 THEN $2 ELSE demor_limits.start END,
count=CASE WHEN demor_limits.start < $2-900 THEN 1 ELSE demor_limits.count+1 END RETURNING count`,[key,now]);
  check(r.count<=max,'Too many requests. Please try again in 15 minutes.',429);
 }
 async function customerIdentity(req){
  const bearer=req.headers.get('authorization')||'';
  check(/^Bearer [A-Za-z0-9_.-]{30,10000}$/.test(bearer),'Please log in to DEMOR before placing an order.',401);
  // Identity owns this endpoint; never trust user IDs or emails provided by the browser.
  // Netlify GoTrue GET /user validates the JWT and returns the authenticated identity.
  let response;
  try{response=await identityFetch(new URL('/.netlify/identity/user',env.DEMOR_ORIGIN),{
    method:'GET',headers:{Authorization:bearer,Accept:'application/json'},redirect:'error',signal:AbortSignal.timeout(8000)
  })}catch{throw new Problem('Login verification is unavailable. Try again shortly.',503)}
  check(response.ok,'Your login has expired. Please log in again.',401);
  let user;try{user=await response.json()}catch{throw new Problem('Could not verify login.',503)}
  check(typeof user?.id==='string'&&/^[a-zA-Z0-9-]{8,128}$/.test(user.id)&&typeof user?.email==='string'&&user.email.includes('@'),'Invalid login session.',401);
  return {id:user.id,email:user.email.toLowerCase()};
 }
 async function orderOwner(d,request){
  const id=txt(d.id,80),token=typeof d.token==='string'?d.token:'';
  const [order]=await query('SELECT * FROM demor_orders WHERE id=$1',[id]);
  check(order,'Order not found',404);
  if(token&&equal(order.token_hash,hash(token)))return {order,account:null};
  const account=await customerIdentity(request);
  check(order.customer?.account_id===account.id,'Order not found in this account',404);
  return {order,account};
 }
 async function owner(req){
  const token=cookieToken(req);check(token&&token.length<200,'Please sign in',401);
  const rows=await query('SELECT token_hash FROM demor_sessions WHERE token_hash=$1 AND expires>$2 AND owner_version=$3',[hash(token),clock(),hash(env.DEMOR_OWNER_HASH)]);
  check(rows.length,'Please sign in',401);
 }
 return async(request,context={})=>{
  try{
   check(env.DATABASE_URL&&env.DEMOR_OWNER_HASH&&env.DEMOR_SESSION_SECRET?.length>=32&&env.DEMOR_ORIGIN,'Store setup is incomplete. Please contact the store owner.',503);
   const expected=new URL(env.DEMOR_ORIGIN);check(expected.protocol==='https:'&&expected.origin===env.DEMOR_ORIGIN,'Store origin configuration is invalid',503);
   const url=new URL(request.url),path=url.pathname;
   check(url.origin===expected.origin,'Use the main store website for checkout and admin access.',403);
   const ip=context.ip;check(typeof ip==='string'&&ip.length>0,'Client verification unavailable',503);
   if(request.method==='GET'&&path==='/api/payment-config')return reply(pay.config());
   // Shared customer cart: the account ID comes only from verified Netlify Identity.
   // Do not store prices or trust any identity field supplied by a client.
   if(request.method==='GET'&&path==='/api/my-cart'){
    const account=await customerIdentity(request);
    const [cart]=await query('SELECT items,revision FROM demor_customer_carts WHERE account_id=$1',[account.id]);
    return reply({items:cart?.items||[],revision:cart?.revision||0});
   }
   if(request.method==='GET'&&path==='/api/my-orders'){
    const account=await customerIdentity(request);
    const rows=await query("SELECT * FROM demor_orders WHERE customer->>'account_id'=$1 ORDER BY created DESC LIMIT 50",[account.id]);
    return reply({email:account.email,orders:await Promise.all(rows.map(o=>pay.publicOrder(o)))});
   }
   if(request.method==='GET'&&['/api/catalog','/api/catalog.js'].includes(path)){
    const products=await query("SELECT id,details,stock,revision,image<>'' AS has_image FROM demor_products WHERE active=true ORDER BY id");
    let result=products.map(p=>({...p.details,id:p.id,stock:p.stock,sizes:Object.keys(p.stock).filter(s=>p.stock[s]>0),art:{...p.details.art,...(p.has_image?{image:'/api/product-image?id='+p.id+'&v='+p.revision}:{})}}));
    if(path.endsWith('.js')){
     const escape=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
     result=result.map(p=>({...p,...Object.fromEntries(['name','description','fabric','color'].map(k=>[k,escape(p[k]||'')])),care:(p.care||[]).map(escape)}));
     return new Response('PRODUCTS.push(...'+JSON.stringify(result).replace(/</g,'\\u003c')+');',{headers:{'Content-Type':'application/javascript','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
    }
    return reply(result);
   }
   if(request.method==='GET'&&path==='/api/product-image'){
    const [p]=await query("SELECT image FROM demor_products WHERE id=$1 AND active=true",[url.searchParams.get('id')]);
    check(p?.image,'Image not found',404);
    return new Response(Buffer.from(p.image.split(',')[1],'base64'),{headers:{'Content-Type':'image/jpeg','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
   }
   if(request.method==='GET'&&path==='/api/admin/shiprocket/check'){
    await owner(request);await ship.auth();return reply({connected:true});
   }
   if(request.method==='GET'&&path==='/api/admin/products'){
    await owner(request);return reply(await query("SELECT id,details,stock,active,revision,image<>'' AS has_image FROM demor_products ORDER BY id"));
   }
   if(request.method==='GET'&&path==='/api/admin'){
    await owner(request);
    const [orders,tickets]=await Promise.all([
     query('SELECT id,created,customer,items,total,status,payment,notes,revision,delivery FROM demor_orders ORDER BY created DESC'),
     query('SELECT id,created,data,status,notes,revision FROM demor_tickets ORDER BY created DESC')
    ]);
    return reply({orders:await Promise.all(orders.map(async r=>({...r,online:await pay.publicOrder(r),customer:JSON.stringify(r.customer),items:JSON.stringify(r.items)}))),tickets:tickets.map(r=>({...r,data:JSON.stringify(r.data)}))});
   }
   check(request.method==='POST','Method not allowed',405);
   const webhook=path==='/api/razorpay-webhook';
   check(webhook||request.headers.get('origin')===expected.origin,'Invalid request origin',403);
   check(request.headers.get('content-type')?.split(';')[0]==='application/json','JSON content required',415);
   if(path==='/api/admin/product')await owner(request);
   const bodyLimit=path==='/api/admin/product'?350000:32768;
   // Read the stream with a hard byte limit, including chunked requests.
   const reader=request.body?.getReader();check(reader,'Empty request');let chunks=[],length=0;
   while(true){const {value,done}=await reader.read();if(done)break;length+=value.length;if(length>bodyLimit){await reader.cancel();throw new Problem('Request too large',413)}chunks.push(value)}
   const raw=Buffer.concat(chunks).toString();
   if(webhook)return reply(await pay.webhook(raw,request.headers.get('x-razorpay-signature')));
   let d;try{d=JSON.parse(raw)}catch{throw new Problem('Invalid JSON')}
   check(d&&typeof d==='object'&&!Array.isArray(d),'Invalid request');
   if(path==='/api/my-cart'){
    await rate('cart-write',ip,100);
    const account=await customerIdentity(request);
    check(Number.isInteger(d.revision)&&d.revision>=0,'Refresh your bag before saving.',409);
    check(Array.isArray(d.items)&&d.items.length<=50,'Invalid cart');
    const seen=new Set();
    const products=await query('SELECT id,stock FROM demor_products WHERE active=true');
    const stockById=new Map(products.map(p=>[p.id,p.stock]));
    const items=d.items.map(item=>{
      check(item&&typeof item==='object'&&!Array.isArray(item),'Invalid cart item');
      const id=txt(item.id,60),size=txt(item.size,5),qty=item.qty;
      check(/^[a-z0-9][a-z0-9-]{2,59}$/.test(id)&&['S','M','L','XL','XXL'].includes(size)&&Number.isInteger(qty)&&qty>0&&qty<=20,'Invalid cart item');
      const key=id+'|'+size;check(!seen.has(key),'Duplicate cart item');seen.add(key);
      const stock=stockById.get(id);
      // Trust only current DB stock, not a claimed product/price from a device.
      check(stock&&Number(stock[size]||0)>=qty,'Stock changed. Refresh the bag.',409);
      return {id,size,qty};
    });
    // CAS prevents a stale app/device silently overwriting a newer website cart.
    const [saved]=await query(`INSERT INTO demor_customer_carts (account_id,items,revision,updated)
SELECT $1,$2::jsonb,1,$3 WHERE $4=0
ON CONFLICT(account_id) DO UPDATE SET items=EXCLUDED.items,revision=demor_customer_carts.revision+1,updated=EXCLUDED.updated
WHERE demor_customer_carts.revision=$4
RETURNING items,revision`,[account.id,JSON.stringify(items),clock(),d.revision]);
    check(saved,'Bag changed on another device. Refresh to see latest items.',409);
    return reply({items:saved.items,revision:saved.revision});
   }
   if(['/api/create-order','/api/verify-payment','/api/payment-status'].includes(path)){
    await rate('payment',ip,60);
    const safe={...d};delete safe._verified_account_id;
    // Legacy orders still work with their private tracking code. For account orders,
    // only a server-verified Identity user may access them without the private code.
    if(!safe.token){const account=await customerIdentity(request);safe._verified_account_id=account.id}
    const result=await (path==='/api/create-order'?pay.create(safe):path==='/api/verify-payment'?pay.verify(safe):pay.refresh(safe));
    return reply(result,path==='/api/verify-payment'&&result.payment_state==='authorized'?202:200);
   }
   if(path==='/api/admin/shiprocket/quote'){
    await owner(request);
    const [o]=await query('SELECT id,customer,status,payment FROM demor_orders WHERE id=$1',[txt(d.id,80)]);
    check(o,'Order not found',404);
    check(/^\d{6}$/.test(String(d.pickup||'')),'Enter the actual pickup PIN code');
    const weight=Number(d.weight);check(weight>=0.1&&weight<=25,'Enter packed weight in kg (0.1–25)');
    check(d.cod===true||d.cod===false,'Select COD or Prepaid');
    return reply({couriers:await ship.queryCourier({pickup:String(d.pickup),drop:o.customer.pincode,weight,cod:d.cod})});
   }
   if(path==='/api/admin/shiprocket/create'){
    await owner(request);
    const id=txt(d.id,80),pickup=txt(d.pickup,36),weight=Number(d.weight),length=Number(d.length),breadth=Number(d.breadth),height=Number(d.height);
    check(pickup&&/^[a-zA-Z0-9 _-]{1,36}$/.test(pickup),'Use exact Shiprocket pickup location name (up to 36 characters)');
    check(weight>=0.1&&weight<=25&&[length,breadth,height].every(v=>Number.isFinite(v)&&v>=0.5&&v<=150),'Enter real packed weight (kg) and dimensions (cm)');
    const [o]=await query('SELECT * FROM demor_orders WHERE id=$1',[id]);check(o,'Order not found',404);
    check(['Confirmed','Packed'].includes(o.status),'Confirm the order before creating a shipment',409);
    check(!o.delivery?.shiprocket,'A Shiprocket booking already exists or needs manual review. Check Shiprocket dashboard before trying again.',409);
    const [p]=await query('SELECT mode,state FROM demor_payments WHERE store_id=$1',[id]);
    const prepaid=!!p&&p.mode==='live'&&p.state==='captured'||(!p&&o.payment==='Paid externally'&&o.notes.trim().length>0);
    const cod=!p&&o.payment==='COD due';
    check(prepaid||cod,'Only captured LIVE prepaid, documented externally paid, or confirmed COD orders may be booked',409);
    const customer=o.customer;check(/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(customer.email||''),'Customer email is required for Shiprocket booking',409);
    const phone=String(customer.phone||'').replace(/\D/g,'').replace(/^91(?=\d{10}$)/,'');check(/^\d{10}$/.test(phone),'Customer needs a valid 10-digit Indian mobile number',409);
    const shipment={stage:'creating',pickup,weight,length,breadth,height};
    const claim=await query(`UPDATE demor_orders SET delivery=jsonb_set(COALESCE(delivery,'{}'::jsonb),'{shiprocket}',$2::jsonb,true),revision=revision+1 WHERE id=$1 AND revision=$3 AND NOT (COALESCE(delivery,'{}'::jsonb) ? 'shiprocket') AND status IN ('Confirmed','Packed') RETURNING id`,[id,JSON.stringify(shipment),o.revision]);
    check(claim.length,'Order changed or booking already started. Refresh before proceeding.',409);
    const names=customer.name.trim().split(/\s+/);const date=new Date(o.created*1000).toISOString().slice(0,19).replace('T',' ');
    const payload={order_id:id,order_date:date,pickup_location:pickup,billing_customer_name:names[0],billing_last_name:names.slice(1).join(' '),billing_address:customer.address,billing_city:customer.city,billing_pincode:customer.pincode,billing_state:customer.state,billing_country:'India',billing_email:customer.email,billing_phone:phone,shipping_is_billing:true,order_items:o.items.map(i=>({name:i.name,sku:i.id+'-'+i.size,units:i.qty,selling_price:i.price})),payment_method:cod?'COD':'Prepaid',shipping_charges:0,sub_total:o.total,length,breadth,height,weight};
    try{
     const info=await ship.createOrder(payload);
     await query(`UPDATE demor_orders SET delivery=jsonb_set(delivery,'{shiprocket}',$2::jsonb,true),revision=revision+1 WHERE id=$1`,[id,JSON.stringify({...shipment,stage:'draft',...info})]);
     return reply({ok:true,shiprocket:info});
    }catch(e){
     // This is intentionally NOT retried automatically: the remote order may already exist.
     await query(`UPDATE demor_orders SET delivery=jsonb_set(delivery,'{shiprocket}',$2::jsonb,true),revision=revision+1 WHERE id=$1`,[id,JSON.stringify({...shipment,stage:'review'})]);
     throw new Problem('Shiprocket booking outcome is uncertain. Check the Shiprocket panel for order '+id+' before contacting support or retrying.',502);
    }
   }
   if(path==='/api/admin/shiprocket/awb'){
    await owner(request);const id=txt(d.id,80),courier_id=Number(d.courier_id);
    check(Number.isInteger(courier_id)&&courier_id>0,'Select a courier ID from a fresh quote');
    const [o]=await query('SELECT id,status,delivery,revision FROM demor_orders WHERE id=$1',[id]);check(o,'Order not found',404);
    check(['Confirmed','Packed'].includes(o.status)&&o.delivery?.shiprocket?.stage==='draft','Shiprocket order must be a draft before AWB assignment',409);
    const shipdata={...o.delivery.shiprocket,stage:'assigning'};
    const claim=await query(`UPDATE demor_orders SET delivery=jsonb_set(delivery,'{shiprocket}',$2::jsonb,true),revision=revision+1 WHERE id=$1 AND revision=$3 AND status IN ('Confirmed','Packed') AND delivery->'shiprocket'->>'stage'='draft' RETURNING id`,[id,JSON.stringify(shipdata),o.revision]);
    check(claim.length,'Order changed. Refresh first.',409);
    try{
     const details=await ship.assignAwb(shipdata.shipment_id,courier_id);
     const delivery={...o.delivery,shiprocket:{...shipdata,stage:'awb_assigned',courier_id},carrier:details.carrier,tracking:details.awb,url:'https://shiprocket.co/tracking/',message:'Tracking number generated. Courier pickup is not yet confirmed.'};
     await query('UPDATE demor_orders SET delivery=$2::jsonb,revision=revision+1 WHERE id=$1',[id,JSON.stringify(delivery)]);
     return reply({ok:true,awb:details.awb});
    }catch(e){
     await query(`UPDATE demor_orders SET delivery=jsonb_set(delivery,'{shiprocket}',$2::jsonb,true),revision=revision+1 WHERE id=$1`,[id,JSON.stringify({...shipdata,stage:'review'})]);
     throw new Problem('AWB assignment outcome is uncertain. Check Shiprocket before retrying.',502);
    }
   }
   if(path==='/api/admin/shiprocket/tracking'){
    await owner(request);const id=txt(d.id,80);
    const [o]=await query('SELECT id,delivery FROM demor_orders WHERE id=$1',[id]);check(o?.delivery?.tracking,'No tracking number saved',404);
    const result=await ship.track(o.delivery.tracking);
    // Does not auto-mark Delivered/Shipped: the administrator verifies carrier updates first.
    const updated={...o.delivery,message:result.status};
    await query('UPDATE demor_orders SET delivery=$2::jsonb,revision=revision+1 WHERE id=$1',[id,JSON.stringify(updated)]);
    return reply({ok:true,status:result.status});
   }
   if(path==='/api/admin/payment-recover'){await owner(request);return reply(await pay.recover(d));}
   if(path==='/api/admin/delivery'){
    await owner(request);check(Number.isInteger(d.revision),'Refresh before saving',409);
    const delivery={carrier:txt(d.carrier,100),tracking:txt(d.tracking,100),url:txt(d.url,500),estimate:txt(d.estimate,100),message:txt(d.message,1000)};
    if(delivery.url){let link;try{link=new URL(delivery.url)}catch{}check(link?.protocol==='https:'&&!link.username&&!link.password,'Tracking link must be an HTTPS courier link');}
    const rows=await query(`UPDATE demor_orders SET delivery=COALESCE(delivery,'{}'::jsonb)||$1::jsonb,revision=revision+1 WHERE id=$2 AND revision=$3 RETURNING id`,[JSON.stringify(delivery),txt(d.id,80),d.revision]);
    check(rows.length,'Order changed. Refresh before saving.',409);return reply({ok:true});
   }
   if(path==='/api/admin/product'){
    const id=txt(d.id,60);check(/^[a-z0-9][a-z0-9-]{2,59}$/.test(id),'Use a product ID with lowercase letters, numbers and hyphens');
    check(d.details&&d.stock&&typeof d.stock==='object'&&!Array.isArray(d.stock),'Product details and stock required');
    const x=d.details;
    const details={id,name:txt(x.name,120),description:txt(x.description,2000),fabric:txt(x.fabric,100),color:txt(x.color,60),category:txt(x.category,40),price:x.price,compareAt:x.compareAt||null,newArrival:!!x.newArrival,bestSeller:!!x.bestSeller,rating:0,reviewCount:0,care:txt(x.care,1000).split('\n').filter(Boolean),art:{garment:x.category==='blazers'?'blazer':x.category==='jodhpuri'?'jodhpuri':x.category==='nehru-jackets'?'nehru':'kurta',tone:'#d4c2a1',collar:'nehru',pattern:'none',includePajama:x.category==='kurta-pajama-sets'}};
    check(details.name&&['kurtas','kurta-pajama-sets','nehru-jackets','blazers','jodhpuri'].includes(details.category),'Name and valid category required');
    check(Number.isInteger(details.price)&&details.price>0&&details.price<=1000000,'Price must be whole rupees between 1 and 1000000');
    check(details.compareAt===null||(Number.isInteger(details.compareAt)&&details.compareAt>details.price&&details.compareAt<=1000000),'Original price must be greater than sale price');
    const stock={};for(const size of ['S','M','L','XL','XXL']){const n=d.stock[size]??0;check(Number.isInteger(n)&&n>=0&&n<=100000,'Stock must be a whole number from 0 to 100000');stock[size]=n}
    details.sizes=Object.keys(stock);
    check(typeof d.active==='boolean','Choose draft or published');
    if(d.image!==undefined){check(typeof d.image==='string'&&d.image.length<=280000&&(/^data:image\/jpeg;base64,[A-Za-z0-9+/]+=*$/.test(d.image)||d.image===''),'Choose a JPEG photo');if(d.image){const bytes=Buffer.from(d.image.split(',')[1],'base64');check(bytes[0]===255&&bytes[1]===216&&bytes[2]===255,'Invalid JPEG photo')}}
    let rows;
    if(d.revision===0){rows=await query('INSERT INTO demor_products(id,details,stock,active,image) VALUES($1,$2::jsonb,$3::jsonb,$4,$5) ON CONFLICT(id) DO NOTHING RETURNING id',[id,JSON.stringify(details),JSON.stringify(stock),d.active,d.image||''])}
    else{check(Number.isInteger(d.revision),'Reload products before editing');rows=await query('UPDATE demor_products SET details=$2::jsonb,stock=$3::jsonb,active=$4,image=COALESCE($5,image),revision=revision+1 WHERE id=$1 AND revision=$6 RETURNING id',[id,JSON.stringify(details),JSON.stringify(stock),d.active,d.image??null,d.revision])}
    check(rows.length,'Product or stock changed. Reload products, then edit again. New products need a unique ID.',409);return reply({ok:true});
   }
   if(path==='/api/login'){
    await rate('login',ip,10);
    check(await passwordMatches(txt(d.password,256),env.DEMOR_OWNER_HASH),'Incorrect password',401);
    const token=random();await query('INSERT INTO demor_sessions (token_hash,owner_version,expires) VALUES ($1,$2,$3)',[hash(token),hash(env.DEMOR_OWNER_HASH),clock()+28800]);
    await query('DELETE FROM demor_sessions WHERE expires<$1',[clock()]);
    return reply({ok:true},200,{'Set-Cookie':cookie(token)});
   }
   if(path==='/api/logout'){
    await query('DELETE FROM demor_sessions WHERE token_hash=$1',[hash(cookieToken(request))]);return reply({ok:true},200,{'Set-Cookie':cookie('')});
   }
   if(path==='/api/orders'){
    await rate('order',ip,30);
    const account=await customerIdentity(request);
    if(d.online)check(pay.config().enabled,'Online payments are not configured yet.',503);
    check(d.customer&&typeof d.customer==='object','Delivery details required');
    const customer=Object.fromEntries(['name','phone','address','city','state','pincode','email','notes'].map(k=>[k,txt(d.customer[k],500)]));
    check(['name','phone','address','city','state','pincode'].every(k=>customer[k]),'Complete all delivery details');
    check(/^[0-9+ ()-]{10,18}$/.test(customer.phone)&&/^\d{6}$/.test(customer.pincode),'Check phone and six-digit pincode');
    check(!customer.email||/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(customer.email),'Enter a valid email for delivery and order updates');
    customer.email=account.email;customer.account_id=account.id;
    check(Array.isArray(d.items)&&d.items.length>0&&d.items.length<=50,'Invalid cart');
    const catalog=(await query('SELECT id,details FROM demor_products WHERE active=true')).map(p=>({...p.details,id:p.id}));
    const items=d.items.map(i=>{check(i&&typeof i==='object','Invalid item');const p=catalog.find(p=>p.id===i.id);check(p&&p.sizes.includes(i.size)&&Number.isInteger(i.qty)&&i.qty>=1&&i.qty<=20,'Invalid product, size or quantity');check(i.expectedPrice===undefined||i.expectedPrice===p.price,'Price changed. Refresh your bag before ordering.',409);return {id:p.id,name:p.name,size:i.size,qty:i.qty,price:p.price}});
    const total=items.reduce((sum,i)=>sum+i.price*i.qty,0),key=txt(d.requestKey,100);
    check(/^[a-zA-Z0-9_-]{20,100}$/.test(key),'Invalid checkout request key');
    const requestHash=hash(key),payloadHash=hash(JSON.stringify({customer,items})),id='DM-'+random().slice(0,14),token=trackingCode(env.DEMOR_SESSION_SECRET,key);
    let [order]=await query(`INSERT INTO demor_orders (id,token_hash,request_hash,payload_hash,created,customer,items,total,inventory_reserved)
VALUES ($1,$2,$3,$4,$5,$6::jsonb,$7::jsonb,$8,true) ON CONFLICT (request_hash) DO NOTHING RETURNING id,payload_hash,token_hash`,[id,hash(token),requestHash,payloadHash,clock(),JSON.stringify(customer),JSON.stringify(items),total]);
    if(!order)[order]=await query('SELECT id,payload_hash,token_hash FROM demor_orders WHERE request_hash=$1',[requestHash]);
    check(order&&equal(order.payload_hash,payloadHash),'Checkout details changed. Reload checkout to create a new request.',409);
    check(equal(order.token_hash,hash(token)),'Order exists. Contact customer care if you lost the tracking code.',409);
    return reply({id:order.id,token},201);
   }
   if(path==='/api/track'){
    await rate('track',ip,60);
    const {order}=await orderOwner(d,request);
    return reply(await pay.publicOrder(order));
   }
   if(path==='/api/claim-order'){
    const account=await customerIdentity(request);
    const id=txt(d.id,80),token=txt(d.token,100);
    check(token.length>=20,'Private tracking code required');
    const rows=await query(`UPDATE demor_orders
      SET customer=jsonb_set(customer,'{account_id}',to_jsonb($3::text),true),revision=revision+1
      WHERE id=$1 AND token_hash=$2 AND COALESCE(customer->>'account_id','')='' RETURNING id`,[id,hash(token),account.id]);
    check(rows.length,'Order not found or already linked to an account',404);
    return reply({ok:true});
   }
   if(path==='/api/cancel-order'){
    await rate('cancel',ip,12);
    const id=txt(d.id,80),token=txt(d.token,100),reason=txt(d.reason,500);
    check(reason.length>=5,'Please give a reason for cancellation (at least 5 characters).');
    const {order:o}=await orderOwner(d,request);
    check(['New','Confirmed','Packed'].includes(o.status),'This order can no longer be cancelled online. Contact customer care.',409);
    // One atomic, conditional update: a courier-booking claim or a dispatch blocks cancellation.
    // The inventory trigger restores unshipped reserved items exactly once.
    const event=JSON.stringify([{at:clock(),status:'Cancelled',source:'customer',reason}]);
    const result=await query(`UPDATE demor_orders SET status='Cancelled',
      payment=CASE WHEN payment='Paid externally' OR EXISTS (
        SELECT 1 FROM demor_payments p WHERE p.store_id=demor_orders.id AND p.state IN ('captured','partial_refund','authorized')
      ) THEN 'Refund requested' ELSE payment END,
      history=history||$3::jsonb,revision=revision+1
      WHERE id=$1 AND (token_hash=$2 OR customer->>'account_id'=$4) AND status IN ('New','Confirmed','Packed')
      AND NOT (COALESCE(delivery,'{}'::jsonb) ? 'shiprocket')
      AND COALESCE(delivery->>'tracking','')=''
      RETURNING *`,[id,hash(token),event,o.customer?.account_id||'']);
    check(result.length,'A shipment may already be booked, or this order has changed. Please contact customer care.',409);
    const updated=await pay.publicOrder(result[0]);
    return reply({...updated,cancellation_message:updated.review_required||updated.payment==='Refund requested'?'Order cancelled. Any payment refund must be reviewed and processed separately.':'Order cancelled successfully. No refund was processed.'});
   }
   if(path==='/api/order-request'){
    await rate('order-request',ip,10);
    const id=txt(d.id,80),token=txt(d.token,100),type=txt(d.type,30),message=txt(d.message,1000);
    check(['Cancellation request','Return request'].includes(type)&&message.length>=5,'Explain your request (at least 5 characters)');
    const {order:o}=await orderOwner(d,request);
    check(type==='Cancellation request'?['New','Confirmed','Packed'].includes(o.status):o.status==='Delivered','This request is not available for the current order status',409);
    const key=txt(d.requestKey,100);check(/^[a-zA-Z0-9_-]{20,100}$/.test(key),'Invalid request key');
    const data={name:o.customer.name,phone:o.customer.phone,email:o.customer.email||'',order:id,type,message};
    const requestHash=hash(key),payloadHash=hash(JSON.stringify(data));
    let [r]=await query(`INSERT INTO demor_tickets (id,request_hash,payload_hash,created,data) VALUES ($1,$2,$3,$4,$5::jsonb) ON CONFLICT (request_hash) DO NOTHING RETURNING id,payload_hash`,['HELP-'+random().slice(0,14),requestHash,payloadHash,clock(),JSON.stringify(data)]);
    if(!r)[r]=await query('SELECT id,payload_hash FROM demor_tickets WHERE request_hash=$1',[requestHash]);
    check(r&&equal(r.payload_hash,payloadHash),'Request details changed. Try again.',409);
    return reply({id:r.id,status:'Request received for review'},201);
   }
   if(path==='/api/tickets'){
    await rate('ticket',ip,20);
    const data=Object.fromEntries(['name','phone','email','order','type','message'].map(k=>[k,txt(d[k])])) ;
    check(data.name&&data.phone&&data.message,'Name, phone and message are required');
    const key=txt(d.requestKey,100);check(/^[a-zA-Z0-9_-]{20,100}$/.test(key),'Invalid support request key');
    const requestHash=hash(key),payloadHash=hash(JSON.stringify(data));
    let [r]=await query(`INSERT INTO demor_tickets (id,request_hash,payload_hash,created,data) VALUES ($1,$2,$3,$4,$5::jsonb)
ON CONFLICT (request_hash) DO NOTHING RETURNING id,payload_hash`,['HELP-'+random().slice(0,14),requestHash,payloadHash,clock(),JSON.stringify(data)]);
    if(!r)[r]=await query('SELECT id,payload_hash FROM demor_tickets WHERE request_hash=$1',[requestHash]);
    check(r&&equal(r.payload_hash,payloadHash),'Request details changed. Reload the page and try again.',409);return reply({id:r.id},201);
   }
   if(path==='/api/admin/update'){
    await owner(request);const id=txt(d.id,80),notes=txt(d.notes,4000);check(Number.isInteger(d.revision),'Refresh the panel before saving',409);
    let rows;const event=JSON.stringify([{at:clock(),status:d.status,payment:d.payment,notes}]);
    if(d.kind==='order'){
     check(statuses.includes(d.status)&&payments.includes(d.payment),'Invalid order or payment status');
     check(!['Paid externally','Refunded externally'].includes(d.payment)||notes,'Add an external transaction reference to notes');
     rows=await query(`UPDATE demor_orders SET status=$1,payment=$2,notes=$3,revision=revision+1,history=history||$4::jsonb WHERE id=$5 AND revision=$6 AND ($1 <> 'Cancelled' OR (NOT (COALESCE(delivery,'{}'::jsonb) ? 'shiprocket') AND COALESCE(delivery->>'tracking','')='')) AND ($1 NOT IN ('Confirmed','Packed','Shipped','Delivered') OR NOT EXISTS(SELECT 1 FROM demor_payments p WHERE p.store_id=demor_orders.id AND (p.mode='test' OR p.state<>'captured'))) RETURNING id`,[d.status,d.payment,notes,event,id,d.revision]);
    }else if(d.kind==='ticket'){
     check(['Open','In progress','Resolved','Closed'].includes(d.status),'Invalid ticket status');
     rows=await query('UPDATE demor_tickets SET status=$1,notes=$2,revision=revision+1,history=history||$3::jsonb WHERE id=$4 AND revision=$5 RETURNING id',[d.status,notes,event,id,d.revision]);
    }else throw new Problem('Invalid record type');
    check(rows.length,'Record changed or fulfilment blocked: online orders need a captured LIVE payment. Refresh and try again.',409);return reply({ok:true});
   }
   throw new Problem('Not found',404);
  }catch(e){if(e.code==='P0001')return reply({error:e.message},409);if(e instanceof Problem||e instanceof PaymentError||e instanceof ShiprocketError)return reply({error:e.message},e.status);return reply({error:'Unable to complete request. Please try again or contact the store owner.'},500)}
 };
}
