-- Run after the existing schema and product-upgrade.sql. No existing data is removed.
BEGIN;
CREATE TABLE IF NOT EXISTS demor_payments (
 store_id TEXT PRIMARY KEY REFERENCES demor_orders(id),
 provider_order_id TEXT UNIQUE,
 payment_id TEXT UNIQUE,
 key_id TEXT NOT NULL,
 mode TEXT NOT NULL CHECK(mode IN ('test','live')),
 amount INTEGER NOT NULL CHECK(amount>=100),
 state TEXT NOT NULL DEFAULT 'creating',
 refunded INTEGER NOT NULL DEFAULT 0,
 updated DOUBLE PRECISION NOT NULL
);
ALTER TABLE demor_orders ADD COLUMN IF NOT EXISTS delivery JSONB NOT NULL DEFAULT '{}';
COMMIT;
