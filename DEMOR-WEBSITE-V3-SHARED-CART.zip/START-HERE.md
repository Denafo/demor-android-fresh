# DEMOR — Netlify setup (pehle yeh padhein)

Yeh updated website Netlify Functions + Neon PostgreSQL ke liye hai. Purana Python server ab required nahi hai.

**ZIP sirf drag-and-drop karne se checkout/admin backend deploy nahi hoga.** Neeche repository/CLI deployment use karein. Yeh package abhi live website par deploy nahi hua hai.

## Aapko kya milega

- Website par order submit, order number aur private tracking code.
- Owner password wala /admin panel; public signup nahi hai.
- Orders, customers, complaint/refund/payment issue requests; status aur internal notes.
- Server catalog se price calculation; duplicate checkout protection.
- Concurrent admin edits ki protection aur database mein change history.

Online payments aur actual refund transfer abhi enabled nahi hain. Product/photos/page editing admin mein abhi nahi hai. Original products abhi sample catalog hain: real catalog, photos aur policies verify karke hi real orders shuru karein.

## 1. Database banayein

Neon (https://neon.com) par PostgreSQL database banayein. Apne plan, region aur usage charges check karein. Database connection string ko private rakhein.

Neon SQL Editor mein `server/schema.sql` ka poora content run karein. Isse orders, tickets, sessions aur security tables banenge. Yeh destructive reset script nahi hai.

Alternative: local terminal mein DATABASE_URL securely set karke `npm run db:setup` run karein. Connection string chat mein ya public GitHub files mein paste na karein.

## 2. Owner login banayein

Laptop/computer par Node.js 22+ install ho. Is ZIP ko extract karke us folder mein terminal kholein jahan package.json hai:

```sh
npm ci
npm run setup:password
```

Command aapke local terminal mein ek random owner password, DEMOR_OWNER_HASH aur DEMOR_SESSION_SECRET dega. Owner password password manager mein save karein. Output kisi public file mein save na karein. ZIP mein koi default password nahi hai.

## 3. Existing Netlify project mein settings

demor.in ke **existing** Netlify project ki environment variable settings mein add karein:

| Name | Value |
| --- | --- |
| DATABASE_URL | Neon ki private PostgreSQL connection string |
| DEMOR_OWNER_HASH | Setup command ka generated hash |
| DEMOR_SESSION_SECRET | Setup command ka generated secret |
| DEMOR_ORIGIN | https://demor.in |

Agar aapka canonical address https://www.demor.in hai to DEMOR_ORIGIN mein wahi exact origin use karein. Trailing slash na lagayein. Main domain ko primary domain rakhein. Secrets ko Functions runtime ke liye available rakhein. Sirf production context mein production credentials configure karein; deploy previews ko alag test DB/secrets dein ya unconfigured rehne dein.

## 4. Deploy

Recommended: is folder ke contents ko private Git repository mein push karke **existing Netlify project** se connect karein. Node modules, .env, generated passwords ya database exports upload na karein. Netlify settings:

- Build command: `npm run build`
- Publish directory: `public`
- Functions directory: `netlify/functions`

Yeh settings netlify.toml mein already hain. Repository mein folder ke contents root par hone chahiye, ya Netlify base directory isi folder ko set karein.

Computer se alternative (Netlify CLI):

```sh
npx netlify-cli login
npx netlify-cli link
npx netlify-cli deploy --prod --context production
```

`link` mein demor.in wala existing project carefully choose karein. Command live website update karega. Netlify/Git login password ya tokens chat mein share na karein. Apne current deploy ka rollback option aur existing files ki backup copy rakhein.

## 5. Live check

1. https://demor.in/admin par generated owner password se login.
2. Store par ek test order place karein; tracking code save karein.
3. Admin mein order aur correct total check karein, status update karein.
4. Customer support form se test complaint bhejein; admin mein resolve karein.
5. Incognito mein /admin bina password customer data nahi dikhana chahiye.
6. Test order ko Cancelled aur ticket ko Closed mark karein.

## Payment, refund aur operational limits

- Checkout payment collect nahi karta. Shipping, availability aur payment method confirmation pending rehta hai.
- Refund approved ka matlab paise transfer hona nahi hai. Provider se actual refund karke reference notes mein record karein, phir Refunded externally mark karein.
- Gateway integration, payment verification/webhooks, courier tracking, email/SMS delivery aur automatic customer replies is version mein nahi hain.
- Support notes internal hain; customer ko response aapke usual communication channel se dena hoga.
- Admin list manual Refresh se update hoti hai. Yeh small-store version hai; high-volume use ke liye pagination/monitoring aur abuse protection further configure karein.
- `server/catalog.json` product source hai. Edit karke redeploy karein; build storefront catalog automatically banata hai.
- Database backups/retention Neon mein configure karein; customer information private rakhein.
- Password rotate karne ke liye setup command se naya hash generate karke DEMOR_OWNER_HASH update aur redeploy karein. Purane sessions invalid ho jayenge. DEMOR_SESSION_SECRET ko stable rakhein: ise badalne se interrupted checkout ki old retry tracking-code recovery affected ho sakti hai; existing issued tracking codes still validate against their saved hashes.

## Kya verify hua hai

Local PostgreSQL-compatible PGlite tests: login restrictions, cookie flags, server-side totals, repeat-order protection, private tracking, validation, owner-only updates, concurrent changes, ticket submission, origin checks, login rate limits aur logout pass hue hain. Build aur JavaScript syntax checks pass hain. Actual Netlify deployment/Neon connection live verify nahi hue kyunki aapka account configure nahi kiya gaya hai.

Official references:
- https://docs.netlify.com/build/functions/configuration/
- https://docs.netlify.com/build/functions/environment-variables/
- https://github.com/neondatabase/serverless
