# DEMOR — Shiprocket, Cancellation, Blazers and Jodhpuri

This archive is an update to the owner-provided **demor-razorpay-my-orders-update.zip**. It is a *complete source project*, not a static-only web folder. It is **NOT deployed** to demor.in, and no real API requests, refunds, bookings or payments have been attempted.

## What changed

1. Home page: premium Blazer, Jodhpuri and Kurta category cards; category tabs.
2. Main navigation, shop filters, search labeling and new Blazers / Jodhpuri category pages. Existing kurta pages remain.
3. Admin → Products & stock can create real products in `blazers` and `jodhpuri`, set real prices, upload JPEG/PNG/WebP photos (converted to JPEG client-side), set sizes and inventory. **No made-up products were published**. Until you add stock and publish a real product, the category page shows no purchasable items.
4. My Orders: authenticated self-cancellation using order number **and private tracking code**. Allowed when order is `New`, `Confirmed`, or `Packed` **and** there is no Shiprocket booking and no tracking number. Each cancellation is conditional and atomic, writes audit history and restores inventory through the existing SQL trigger. Cannot cancel repeatedly. Once booking/dispatch begins, customer must contact support.
5. Paid cancellation does **not** automatically issue a refund: it flags refund review. Owner must verify Razorpay and process any approved refund there, with an accurate payment record in admin.
6. Owner-only Shiprocket REST client + API endpoints: credential check, courier serviceability estimate, creating a manual draft order, assigning AWB after fresh rate check, tracking refresh. Admin panel has explicit confirmations and rate/weight entry. **No automatic order creation and no automatic wallet charging** on checkout. The owner must arrange pickup in Shiprocket separately after AWB assignment. Remote-API errors leave an order requiring manual reconciliation to avoid duplicate shipping.
7. Standard delivery messaging updated to free shipping on serviceable Indian PIN codes. Courier serviceability is **not yet automated at checkout**; check manually for initial orders. The policy and checkout explain exceptions.
8. Existing Netlify, Neon, payment, owner login and order code architecture retained.

## Security and operational checklist

- Keep `SHIPROCKET_API_EMAIL` and `SHIPROCKET_API_PASSWORD` only in **Netlify Environment Variables** with Functions access. **Never** put them in files, frontend code or messages. These credentials are not included in this ZIP.
- Netlify environment must still include the original database, store origin, owner/session and Razorpay secrets. Do not delete or rename existing variables.
- The shipping pickup location name must **match Shiprocket's actual configured label**, with a maximum of 36 characters. Enter the actual pickup PIN code and **packed** weight/dimensions. Do not use the test pickup PIN or dimensions blindly.
- Do not activate courier labels for unpaid/uncaptured payments. The server allows owner-confirmed live captured/prepaid, documented externally-paid or COD-due orders, not test captures.
- A created Shiprocket draft is **not** an arranged pickup. After AWB assignment, visit the Shiprocket dashboard to book/confirm pickup. Do not update order to Shipped/Delivered until delivery milestones are verified.
- Return-to-origin fees, COD fees, courier reliability and express rates may vary. Rates tested for 411051→110001 are **not guaranteed elsewhere**.
- Customer cancellations before booking are irreversible in this version. For physically handed-over items, work through courier and customer support. Handle Razorpay refunds manually.
- Do not create false ratings, fabricate photos or publish products before confirming genuine stock and supplier availability.

## Deployment (important)

1. Keep a working copy/rollback of the most recent **live** DEMOR source and Netlify production deploy. Compare this ZIP against the newest live code before deploying — the supplied source has previously been described as not yet published, and any later live fixes must be merged rather than overwritten.
2. Use the existing **source-based** deployment workflow (Git or Netlify CLI `netlify deploy --build --prod` after `npm ci`), which builds **both static files and Netlify Functions**. Do not deploy only `public/` or use a static-only drag-and-drop deployment — it may omit `/api/*` and break checkout, Razorpay and admin.
3. Build config is in `netlify.toml`. Publish: `public`; Functions: `netlify/functions`; build command: `npm run build`.
4. Verify the existing Neon DB has already been upgraded with `server/product-upgrade.sql` and `server/payments.sql`. **This feature adds no new database migration**; it uses existing `delivery`, `history`, `demor_products` and payments tables.
5. After staging deploy, verify product listings, blazer/Jodhpuri admin entry, cart, Razorpay payment and payment verification, owner login, My Orders and cancellations with non-live test orders. Check Shiprocket credentials using the owner's admin control. Only then promote to production.
6. Before real shipment, test quote, create, AWB and pickup with one real, owner-verified order. Confirm wallet charges and courier dashboard state manually.

## Validation performed here

- `node --check` for every server and browser JavaScript file: **passed**.
- `npm run build`: **passed** (existing build script validates required SQL setup file).
- Static local HTML file, script, CSS and page references: **passed**.
- Categories verified in the admin, backend and frontend code; cancellation guarded by private token and conditional DB update.
- Full automated integration suite: **not run successfully** in this environment; dependency installation failed (the required npm packages were unavailable and environment's Node 22.16 predates the required jsdom Node version). Tests are included, including new cancellation regression tests, and should be run on Node >=22.22.2 with `npm ci && npm test` in a connected development environment.
- Not browser-verified, not tested against live Shiprocket, Razorpay or Neon; no deployment has been performed.
