# DEMOR website update — 15 October 2026

This package improves the existing Netlify store. It has not been published to demor.in.

## Live website findings

During the live review, the homepage linked to the old `dm-003` Oxblood product, which was unavailable. The live catalogue showed one Ivory Silk-Blend Kurta, repeated in the featured, new-arrival and bestseller sections. The hero used an illustration. My Orders had a basic text-and-form layout.

The source also selected the first product size automatically, allowed quantity controls to go beyond available stock before rejecting the addition, and let an unavailable cart reach checkout before showing an error. Cart and checkout used different explanations of shipping charges.

## Changes included

- The hero now uses the name, price, artwork and link of an actual published product, preferring an in-stock product with a photograph.
- Homepage product sections avoid repeating the same items. Empty occasion tiles and duplicate rails are hidden. Small collections use a more compact layout, and products appear before the occasion cards.
- Product pages require an explicit size selection. Quantity controls account for stock and items already in the bag. Sold-out sizes and products have clear states.
- Removed products offer links back to the collection and customer care. Empty related-product sections are hidden.
- The bag blocks checkout when an item or quantity is unavailable. Shipping wording now matches the existing item-only payment arrangement.
- Multiword search, clear-filter recovery, labelled controls, collapsible mobile filters, keyboard focus, skip links and reduced-motion support improve browsing.
- Actual uploaded product images have meaningful alternative text, dimensions and appropriate loading priority. Illustrations are clearly labelled.
- My Orders now has summary counts, search, status filters, order cards, a five-step delivery timeline, payment status, courier details and a secure private-code section.
- Payment retry, verification, refund review and order access continue to use the existing endpoints and stored credentials. Order codes are never added to URLs.

## Still requires owner input

- Add actual photographs of every published product, including front, fabric and detail views when available. The current admin supports one main product photo; a multi-photo gallery would need a separate backend change.
- Publish only real products with correct descriptions, prices and size stock. The single product seen during review has the ID `test-order`; confirm it represents a genuine item intended for customers. This update does not delete, rename or publish products.
- Provide product-specific garment measurements for an exact size chart. The new fit help gives measuring guidance and directs customers to the store; it does not invent measurements.
- Set a clear shipping policy/rate before adding a shipping calculator. Current payments cover items only, with shipping confirmed separately by the store.

## Validation

- All 26 automated tests passed: the original 18 checkout, payment, ownership and inventory tests, plus 8 storefront/order regression tests.
- Production build command passed.
- Modified JavaScript syntax checks passed.
- Static local asset/link validation found no missing targets.
- Backend, database migrations, Netlify configuration, dependencies and payment gateway configuration were not changed.
- The local preview was blocked by the review browser. The revised mobile/desktop visual layout has NOT been browser-verified.
- No live order, payment, stock update or production deployment was performed.

## Deploy to the existing Netlify site

Use the same source-upload/deployment workflow that deployed the previous payment update. This is the full project, with `package.json`, `netlify.toml`, `netlify/functions`, `server` and `public` at the ZIP root.

1. Keep a local copy of the previously working ZIP or the previous Netlify deployment for rollback.
2. Extract this ZIP and update the existing site's source using its normal build/deploy workflow.
3. Keep the existing environment variables. No new secret, SQL migration or paid service is required by this update.
4. Build command: `npm run build`; publish directory: `public`; functions directory: `netlify/functions`.
5. Do not deploy only the HTML files through a static-only workflow that omits the existing API functions.
6. After deployment, check the homepage featured link, product size selection, bag, shop filters and My Orders on a phone and a desktop.
7. For payment validation, use the store's established Razorpay testing process. Do not create real payments just to test the design.

The server still enforces its configured store origin. A random preview hostname will not provide a working production checkout without its own appropriately configured test environment.
