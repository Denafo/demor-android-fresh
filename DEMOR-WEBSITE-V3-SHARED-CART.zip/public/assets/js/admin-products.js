let productRequest=0;
async function renderProducts(){
 const out=$('#records'),request=++productRequest;
 out.replaceChildren(el('p','Loading products…'));
 try{
  const products=await api('/api/admin/products');if(tab!=='products'||request!==productRequest)return;
  out.replaceChildren();
  const intro=el('section'),add=el('button','+ Add product');
  intro.append(el('h2','Products & stock'),el('p','Stock is the quantity still available to sell. New orders reduce it automatically. Cancelling an unshipped new order restores it. Existing orders from before this upgrade do not change stock.'),el('p','Sample products start as drafts with zero stock. Check details, upload a real photo, enter available quantities, then publish. Editing stock replaces the available quantity.'),add);out.append(intro);add.onclick=()=>editProduct({id:'',revision:0,details:{category:'kurtas',care:[]},stock:{},active:false});
  const q=$('#search').value.toLowerCase();
  products.filter(p=>(p.id+' '+p.details.name).toLowerCase().includes(q)).forEach(p=>{
   const card=el('section'),button=el('button','Edit product / stock');
   card.append(el('h2',p.details.name),el('p',p.id+' · '+(p.active?'Published':'Draft')+' · ₹'+p.details.price),el('p',Object.entries(p.stock).map(([size,n])=>size+': '+n).join('  |  ')),el('p',p.has_image?'Photo uploaded':'Illustration only — add your product photo'),button);out.append(card);button.onclick=()=>editProduct(p);
  });
 }catch(e){if(tab==='products')out.replaceChildren(el('p',e.message+' If this is your first upgrade, run product-upgrade.sql in Neon.'))}
}
function editProduct(p){
 const out=$('#records'),form=el('form'),title=el('h2',p.revision?'Edit '+p.details.name:'New product');out.replaceChildren(title,form);
 const fields={};
 function field(key,label,value,type='text'){const wrap=el('label',label),input=el(type==='textarea'?'textarea':'input');if(type!=='textarea')input.type=type;input.value=value??'';wrap.append(input);form.append(wrap);fields[key]=input;return input}
 field('id','Product ID (unique, e.g. dm-021)',p.id).readOnly=!!p.revision;
 field('name','Product name',p.details.name).required=true;
 const category=select('Category',['kurtas','kurta-pajama-sets','nehru-jackets','blazers','jodhpuri'],p.details.category);form.append(category[0]);fields.category=category[1];
 field('price','Selling price (whole ₹)',p.details.price,'number').min=1;
 field('compareAt','Original price (optional, higher than selling price)',p.details.compareAt,'number');
 field('fabric','Fabric',p.details.fabric);field('color','Colour',p.details.color);
 field('description','Description',p.details.description,'textarea');field('care','Care instructions (one per line)',(p.details.care||[]).join('\n'),'textarea');
 form.append(el('h3','Available stock by size'));
 for(const size of ['S','M','L','XL','XXL']){const input=field('stock_'+size,size,p.stock[size]||0,'number');input.min=0;input.max=100000;input.required=true;input.step=1}
 const active=select('Visibility',['Draft','Published'],p.active?'Published':'Draft');form.append(active[0]);
 const fresh=field('newArrival','New arrival',undefined,'checkbox');fresh.checked=!!p.details.newArrival;
 const best=field('bestSeller','Feature as bestseller',undefined,'checkbox');best.checked=!!p.details.bestSeller;
 const file=field('photo','Product photo (choose from your phone)',undefined,'file');file.accept='image/jpeg,image/png,image/webp';
 const preview=el('img');preview.style.cssText='max-width:100%;max-height:280px;display:none';form.append(preview);
 let imageValue,photoBusy=false;
 const photoStatus=el('p');form.append(photoStatus);
 file.onchange=async()=>{imageValue=undefined;preview.style.display='none';if(!file.files[0])return;photoBusy=true;photoStatus.textContent='Preparing photo…';save.disabled=true;try{imageValue=await compressPhoto(file.files[0]);preview.src=imageValue;preview.style.display='block';photoStatus.textContent='Photo ready. Save changes to upload it.'}catch(e){file.value='';photoStatus.textContent=e.message}finally{photoBusy=false;save.disabled=false}};
 if(p.has_image){const remove=el('button','Remove existing photo');remove.type='button';remove.onclick=()=>{imageValue='';file.value='';photoStatus.textContent='Photo will be removed when you save.'};form.append(remove)}
 const message=el('p');message.setAttribute('role','status');const save=el('button','Save product'),back=el('button','Back to products');save.type='submit';back.type='button';back.onclick=renderProducts;form.append(message,save,back);
 form.onsubmit=async e=>{e.preventDefault();if(photoBusy)return;save.disabled=true;message.textContent='Saving…';try{
  const details=Object.fromEntries(['name','category','fabric','color','description','care'].map(k=>[k,fields[k].value]));details.price=Number(fields.price.value);details.compareAt=fields.compareAt.value?Number(fields.compareAt.value):null;details.newArrival=fresh.checked;details.bestSeller=best.checked;
  await api('/api/admin/product',{id:fields.id.value.trim(),revision:p.revision,details,stock:Object.fromEntries(['S','M','L','XL','XXL'].map(size=>[size,Number(fields['stock_'+size].value)])),active:active[1].value==='Published',...(imageValue!==undefined?{image:imageValue}:{})});$('#message').textContent='Product saved. Refresh the shop to see published changes.';await renderProducts();
 }catch(e){message.textContent=e.message}finally{save.disabled=false}};
 title.scrollIntoView({block:'start',behavior:'smooth'});
}
async function compressPhoto(file){
 if(file.size>20000000)throw Error('Choose a photo smaller than 20 MB.');
 const url=URL.createObjectURL(file),img=new Image();
 try{await new Promise((resolve,reject)=>{img.onload=resolve;img.onerror=()=>reject(Error('Choose a JPEG, PNG or WebP photo.'));img.src=url});let edge=1000;const canvas=document.createElement('canvas');
 for(let attempt=0;attempt<5;attempt++){const scale=Math.min(1,edge/Math.max(img.width,img.height));canvas.width=Math.max(1,Math.round(img.width*scale));canvas.height=Math.max(1,Math.round(img.height*scale));const ctx=canvas.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.drawImage(img,0,0,canvas.width,canvas.height);const data=canvas.toDataURL('image/jpeg',0.78);if(data.length<=280000)return data;edge*=0.75}throw Error('This photo is too large. Choose a smaller photo.');
 }finally{URL.revokeObjectURL(url)}
}
