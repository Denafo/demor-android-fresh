/* Progressive shopping features. Wishlists stay on this browser. */
(()=>{
'use strict';
const savedKey='demor_saved_v1',recentKey='demor_recent_v1';
function read(key){try{const values=JSON.parse(localStorage.getItem(key)||'[]');return Array.isArray(values)?[...new Set(values)].filter(id=>PRODUCTS.some(p=>p.id===id)):[]}catch{return []}}
let saved=read(savedKey);
function write(key,value){try{localStorage.setItem(key,JSON.stringify(value));return true}catch{showToast('Storage unavailable. Your selection lasts for this visit.');return false}}
const dialog=document.createElement('dialog');dialog.className='modern-dialog';document.body.append(dialog);
let opener;
function open(content,label){
 if(!dialog.open)opener=document.activeElement;
 dialog.setAttribute('aria-label',label);dialog.innerHTML='<button class="dialog-close" aria-label="Close dialog">×</button>'+content;
 if(!dialog.open)dialog.showModal();
 dialog.querySelector('.dialog-close').onclick=()=>dialog.close();
}
dialog.addEventListener('close',()=>{if(opener?.isConnected)opener.focus()});
dialog.addEventListener('click',e=>{if(e.target===dialog){const r=dialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)dialog.close()}});
function plain(value){const el=document.createElement('textarea');el.innerHTML=value;return el.value}
function sync(){
 document.querySelectorAll('[data-save]').forEach(button=>{const p=PRODUCTS.find(p=>p.id===button.dataset.save);if(!p)return;const on=saved.includes(p.id);button.setAttribute('aria-pressed',String(on));button.textContent=on?'♥':'♡';button.setAttribute('aria-label',(on?'Remove from wishlist: ':'Save to wishlist: ')+plain(p.name))});
 document.querySelectorAll('.saved-count').forEach(el=>el.textContent=saved.length);
}
function savedView(){
 dialog.dataset.mode='saved';
 open('<span class="eyebrow">KEEP THE ONES YOU LOVE</span><h2>Your wishlist</h2><p class="dialog-note">Saved on this browser, ready when you are.</p><div class="product-grid">'+(saved.length?saved.map(id=>productCard(PRODUCTS.find(p=>p.id===id))).join(''):'<div class="empty-state"><p>Your next favourite is waiting.</p><a class="btn" href="shop.html">Explore the collection</a></div>')+'</div>','Your wishlist');sync();
}
function fitGuide(){
 dialog.dataset.mode='fit';
 open('<span class="eyebrow">A BETTER FIT STARTS HERE</span><h2>Let’s find your size.</h2><p>Fit can vary between styles. Ask our team for the measurements of the exact product before ordering.</p><ol class="fit-steps"><li><strong>Start with a garment you already own and like.</strong><span>Lay it flat and measure across the chest, from underarm to underarm.</span></li><li><strong>Check the length.</strong><span>Measure from the highest shoulder point to the hem.</span></li><li><strong>Share your measurements.</strong><span>Tell customer care the product name and your preferred fit.</span></li></ol><a href="support.html" class="btn">Ask for sizing help →</a>','Size and fit help');
}
function quick(id){
 const p=PRODUCTS.find(p=>p.id===id);if(!p)return;
 const sizes=p.sizes.filter(s=>(p.stock?.[s]||0)>0);dialog.dataset.mode='quick';
 open(`<div class="dialog-grid"><div class="dialog-art">${garmentSVG({...p.art,id:p.id+'-quick',alt:p.name,priority:true})}${p.art?.image?'':'<p class="photo-disclaimer">Illustration only</p>'}</div><div class="dialog-copy"><span class="eyebrow">${p.fabric}</span><h2>${p.name}</h2><div class="dialog-price">${INR(p.price)}</div><small>Taxes included · Free standard delivery on serviceable PIN codes.</small><p>${p.color}</p><strong>${sizes.length?'Choose your size':'Sold out'}</strong><div class="dialog-sizes" role="group" aria-label="Choose size">${sizes.map(size=>`<button data-pick-size="${size}" aria-pressed="false">${size}</button>`).join('')}</div><div class="dialog-actions"><button class="btn" id="quick-add" disabled>${sizes.length?'Select a size to continue':'Currently sold out'}</button><a class="link-u" href="product.html?id=${p.id}">View full details →</a><button type="button" class="link-button" data-fit-guide>Need help with fit?</button></div></div></div>`,'Choose size for '+plain(p.name));
 let size='';dialog.querySelectorAll('[data-pick-size]').forEach(button=>button.onclick=()=>{size=button.dataset.pickSize;dialog.querySelectorAll('[data-pick-size]').forEach(other=>other.setAttribute('aria-pressed',String(other===button)));const add=dialog.querySelector('#quick-add');add.disabled=false;add.textContent='Add to bag — '+INR(p.price)});
 dialog.querySelector('#quick-add').onclick=()=>{
  if(!size||!addToCart(p.id,size,1))return;
  dialog.dataset.mode='added';
  open('<span class="eyebrow">A GOOD CHOICE</span><h2>Added to your bag.</h2><p>'+p.name+' · Size '+size+'</p><div class="dialog-actions" style="margin-top:25px"><a class="btn" href="cart.html">View bag & continue →</a><button class="text-button" id="keep-shopping">Keep exploring</button></div>','Added to bag');
  dialog.querySelector('#keep-shopping').onclick=()=>dialog.close();
 };
}
function stylist(){
 dialog.dataset.mode='stylist';
 open('<span class="eyebrow">THE PERSONAL EDIT</span><h2>Find your kind of occasion wear.</h2><form class="stylist-form"><label>What are you dressing for?<select name="occasion"><option value="all">A little of everything</option><option value="wedding">A wedding or celebration</option><option value="everyday">Everyday comfort</option><option value="sets">A complete kurta set</option><option value="blazers">A tailored blazer</option><option value="jodhpuri">A wedding Jodhpuri</option></select></label><label>Your budget<select name="budget"><option value="100000">Show me everything</option><option value="2500">Up to ₹2,500</option><option value="4000">Up to ₹4,000</option><option value="6000">Up to ₹6,000</option></select></label><button class="btn" type="submit">Discover my edit →</button></form><div class="style-results" aria-live="polite"></div>','Find your style');
 dialog.querySelector('form').onsubmit=e=>{
  e.preventDefault();const data=new FormData(e.target),occasion=data.get('occasion');
  const picks=PRODUCTS.filter(p=>p.sizes.length&&p.price<=Number(data.get('budget'))&&(occasion==='all'||occasion==='sets'&&p.category==='kurta-pajama-sets'||occasion==='blazers'&&p.category==='blazers'||occasion==='jodhpuri'&&p.category==='jodhpuri'||occasion==='everyday'&&/cotton|linen/i.test(p.fabric)||occasion==='wedding'&&/silk/i.test(p.fabric)));
  dialog.querySelector('.style-results').innerHTML=picks.length?'<p>Your edit · '+picks.length+' styles to explore</p><div class="product-grid">'+picks.slice(0,4).map(productCard).join('')+'</div>':'<p>No exact match yet. Try a different occasion or <a class="link-u" href="shop.html">browse the collection</a>.</p>';sync();
 };
}
document.addEventListener('click',e=>{
 const button=e.target.closest('[data-save],[data-open-saved],[data-quick],[data-stylist],[data-edit],[data-fit-guide]');if(!button)return;
 if(button.hasAttribute('data-save')){const id=button.dataset.save;saved=saved.includes(id)?saved.filter(x=>x!==id):[...saved,id];write(savedKey,saved);sync();if(dialog.open&&dialog.dataset.mode==='saved')savedView()}
 else if(button.hasAttribute('data-open-saved'))savedView();
 else if(button.hasAttribute('data-quick'))quick(button.dataset.quick);
 else if(button.hasAttribute('data-stylist'))stylist();
 else if(button.hasAttribute('data-fit-guide'))fitGuide();
 else{document.querySelectorAll('[data-edit]').forEach(other=>{other.classList.toggle('active',other===button);other.setAttribute('aria-pressed',String(other===button))});renderProductGrid('#featured-grid',PRODUCTS.filter(p=>button.dataset.edit==='all'||p.category===button.dataset.edit).slice(0,4));sync()}
});
function init(){
 const hero=document.getElementById('hero-garment'),heroLink=document.querySelector('.hero-product');
 if(hero){
  const product=PRODUCTS.find(p=>p.sizes.length&&p.art?.image)||PRODUCTS.find(p=>p.sizes.length)||PRODUCTS[0];
  if(product){
   hero.innerHTML=garmentSVG({...product.art,id:'editorial-hero',alt:product.name,priority:true});
   if(heroLink){heroLink.href='product.html?id='+encodeURIComponent(product.id);heroLink.innerHTML='<span>'+product.name+'<br><small>'+INR(product.price)+' · '+(product.sizes.length?'Explore this style':'View this style')+'</small></span><b aria-hidden="true">↗</b>'}
   if(!product.art?.image){const caption=document.createElement('span');caption.className='hero-image-note';caption.textContent='Illustration · product photos coming soon';hero.append(caption)}
  }else{hero.innerHTML='<div class="hero-collection-note">Your next<br>favourite awaits.</div>';if(heroLink){heroLink.href='shop.html';heroLink.innerHTML='<span>Explore the collection<br><small>Find a look that feels like you.</small></span><b aria-hidden="true">↗</b>'}}
  const featured=document.getElementById('featured-grid');if(featured)featured.closest('section').classList.toggle('collection-compact',PRODUCTS.length>0&&PRODUCTS.length<=2);
  for(const [selector,match] of [['.occasion-wedding',p=>/silk/i.test(p.fabric)||p.category==='jodhpuri'||p.category==='blazers'],['.occasion-everyday',p=>/cotton/i.test(p.fabric)],['.occasion-festive',p=>p.category==='kurta-pajama-sets']]){
   const card=document.querySelector(selector);if(card)card.hidden=!PRODUCTS.some(match);
  }
  const occasion=document.querySelector('.occasion-section');if(occasion)occasion.hidden=!occasion.querySelector('.occasion-card:not([hidden])');
 }
 const actions=document.querySelector('.header-actions');
 if(actions&&!actions.querySelector('.orders-link')){const link=document.createElement('a');link.href='my-orders.html';link.className='orders-link';link.textContent='My Orders';actions.prepend(link)}
 const mobileNav=document.querySelector('.mobile-nav');if(mobileNav&&!mobileNav.querySelector('a[href="my-orders.html"]')){const link=document.createElement('a');link.href='my-orders.html';link.textContent='My Orders';mobileNav.append(link)}
 const dock=document.createElement('nav');dock.className='mobile-dock';dock.setAttribute('aria-label','Shopping shortcuts');
 const icons={home:'<path d="M3 10l9-7 9 7v10H3z"/><path d="M9 20v-7h6v7"/>',shop:'<circle cx="10" cy="10" r="7"/><path d="M15 15l6 6"/>',orders:'<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M8 8h8M8 12h8M8 16h5"/>',bag:'<path d="M5 7h14l1 14H4L5 7z"/><path d="M9 7V5a3 3 0 016 0v2"/>'};
 dock.innerHTML=[['index.html','Home','home'],['shop.html','Shop','shop'],['my-orders.html','My Orders','orders'],['cart.html','Bag','bag']].map(([href,label,key])=>'<a href="'+href+'"><svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.5">'+icons[key]+'</svg><span>'+label+'</span></a>').join('');
 const path=location.pathname.split('/').pop().replace('.html','')||'index';dock.querySelectorAll('a').forEach(link=>{if(link.getAttribute('href').replace('.html','')===path)link.setAttribute('aria-current','page')});document.body.append(dock);
 const current=new URLSearchParams(location.search).get('id'),recent=read(recentKey),others=recent.filter(id=>id!==current).slice(0,4);
 if(current&&PRODUCTS.some(p=>p.id===current))write(recentKey,[current,...recent.filter(id=>id!==current)].slice(0,8));
 if(others.length&&document.querySelector('#pd-root')){const section=document.createElement('section');section.className='recent-section';section.innerHTML='<div class="wrap"><div class="section-head"><span class="eyebrow">TAKE ANOTHER LOOK</span><h2>Recently viewed</h2></div><div class="product-grid">'+others.map(id=>productCard(PRODUCTS.find(p=>p.id===id))).join('')+'</div></div>';document.querySelector('.site-footer')?.before(section)}
 sync();document.addEventListener('demor:grid-updated',sync);
 const burger=document.querySelector('.burger');if(burger)document.addEventListener('keydown',e=>{if(e.key==='Escape'&&mobileNav?.classList.contains('open')){mobileNav.classList.remove('open');document.body.style.overflow='';burger.setAttribute('aria-expanded','false');burger.focus()}});
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
