/* No API secret is sent to the browser. Private order codes stay on this device. */
(()=>{
'use strict';
const KEY='demor_orders_v1',DRAFT='demor_checkout_request_v1';
const node=(tag,text)=>{const n=document.createElement(tag);if(text!==undefined)n.textContent=text;return n};
const money=n=>'₹'+Number(n).toLocaleString('en-IN');
function saved(){try{const a=JSON.parse(localStorage.getItem(KEY)||'[]');return Array.isArray(a)?a.filter(x=>typeof x.id==='string'&&typeof x.token==='string').slice(0,50):[]}catch{return []}}
function remember(order){try{const list=saved().filter(x=>x.id!==order.id);localStorage.setItem(KEY,JSON.stringify([{id:order.id,token:order.token},...list].slice(0,50)));return true}catch{return false}}
function forget(id){try{localStorage.setItem(KEY,JSON.stringify(saved().filter(x=>x.id!==id)))}catch{}}
async function api(path,data){
 const headers=data?{'Content-Type':'application/json'}:{};
 const token=await window.DemorAuth?.token?.();if(token)headers.Authorization='Bearer '+token;
 const response=await fetch(path,{method:data?'POST':'GET',headers,body:data?JSON.stringify(data):undefined});
 let result;try{result=await response.json()}catch{throw Error('Store is unavailable. Please try again shortly.')}
 if(!response.ok)throw Error(result.error||'Request failed');return result
}
async function fingerprint(value){const bytes=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(JSON.stringify(value)));return [...new Uint8Array(bytes)].map(x=>x.toString(16).padStart(2,'0')).join('')}
async function requestKey(payload){const signature=await fingerprint(payload);let old;try{old=JSON.parse(localStorage.getItem(DRAFT)||'null')}catch{}if(old?.signature===signature)return old.key;const key=crypto.randomUUID();try{localStorage.setItem(DRAFT,JSON.stringify({signature,key}))}catch{}return key}
let paying=false;
async function startPayment(order,message,done){
 if(paying)return;paying=true;
 try{
  if(typeof window.Razorpay!=='function')throw Error('Payment window could not load. Refresh this page and try again. Your order is saved.');
  message.textContent='Preparing secure payment…';const details=await api('/api/create-order',order);
  message.textContent=details.mode==='test'?'TEST MODE: no real money will be collected.':'Opening secure payment…';
  let verifying=false,completed=false;
  const checkout=new window.Razorpay({key:details.key_id,order_id:details.order_id,amount:details.amount,currency:details.currency,name:'DEMOR',description:(details.mode==='test'?'TEST · ':'')+'Order '+order.id,theme:{color:'#174d43'},retry:{enabled:true},
   modal:{ondismiss:()=>{paying=false;if(!verifying&&!completed)message.textContent='Payment window closed. Your order is saved; check payment status before retrying.'}},
   handler:async result=>{verifying=true;message.textContent='Verifying payment with the store…';try{const status=await api('/api/verify-payment',{...order,...result});completed=true;message.textContent=status.payment_state==='captured'?(status.payment_mode==='test'?'Test payment verified. No real payment was collected.':'Payment verified. Thank you!'):'Payment is processing. Use Refresh payment status; do not pay again yet.';await done?.(status)}catch(e){message.textContent=e.message+' Use Refresh payment status before attempting another payment.'}finally{verifying=false;paying=false}}});
  checkout.on('payment.failed',()=>{message.textContent='Payment attempt failed. You can retry in the payment window. If money was debited, check payment status before retrying.'});
  checkout.open();
 }catch(e){paying=false;message.textContent=e.message}
}
const orderStates=new Map();
let orderGeneration=0;
const orderView={filter:'all',search:''};
let accountOrders=[];
const knownOrders=()=>{const all=[...accountOrders,...saved()];return [...new Map(all.map(o=>[o.id,o])).values()]};
function nextStepMessage(status,details){
 const map={New:"We're reviewing your order and preparing confirmation.",Confirmed:"Your order is confirmed and will be prepared next.",Packed:"Your order is packed and almost ready for shipment.",Shipped:"Your order is on the move. Use tracking for the latest movement.",Delivered:"Your order has been delivered. Need a return? Use the option below.",Cancelled:"This order is closed. Support can help with payment or refund review."};
 return map[status]||details?.message||"We'll keep you updated here."
}
function deliveryWindow(details){
 if(details?.estimate) return details.estimate;
 if(details?.tracking) return 'Tracking generated';
 return 'Awaiting update';
}
function styled(tag,text,className){const el=node(tag,text);if(className)el.className=className;return el}
function applyOrderView(){
 const entries=knownOrders();let visible=0;
 document.querySelectorAll('#my-order-list > .order-card').forEach(card=>{
  const state=orderStates.get(card.dataset.orderId);
  const matchesFilter=orderView.filter==='all'||orderView.filter==='active'&&state&&!['Delivered','Cancelled'].includes(state.status)||orderView.filter==='delivered'&&state?.status==='Delivered'||orderView.filter==='cancelled'&&state?.status==='Cancelled';
  const matchesSearch=(card.dataset.orderSearch||card.dataset.orderId||'').toLowerCase().includes(orderView.search.toLowerCase().trim());
  card.hidden=!(matchesFilter&&matchesSearch);if(!card.hidden)visible++;
 });
 const noMatch=document.getElementById('orders-no-match');if(noMatch)noMatch.hidden=!entries.length||visible>0;
 const values=[...orderStates.values()];
 for(const [id,value] of [['orders-total',entries.length],['orders-active',values.filter(x=>!['Delivered','Cancelled'].includes(x.status)).length],['orders-delivered',values.filter(x=>x.status==='Delivered').length]]){const el=document.getElementById(id);if(el)el.textContent=String(value)}
}
function showOrder(parent,order,status){
 orderStates.set(order.id,status);parent.replaceChildren();parent.className='order-card';parent.dataset.orderId=order.id;
 parent.dataset.orderSearch=[order.id,...(status.items||[]).map(item=>item.name)].join(' ');
 const head=styled('div',undefined,'order-card-head'),identity=node('div'),label=styled('p','ORDER NUMBER','order-eyebrow');
 identity.append(label,node('h2',order.id));const date=new Date(status.created*1000);
 identity.append(styled('p','Placed '+(Number.isNaN(date.getTime())?'recently':date.toLocaleDateString('en-IN',{day:'numeric',month:'short',year:'numeric'})),'order-muted'));
 const badges=styled('div',undefined,'order-badges'),statusBadge=styled('span',status.status==='New'?'Order placed':status.status,'order-badge');
 statusBadge.dataset.status=status.status;badges.append(statusBadge);
 const paymentBadge=styled('span',status.payment||'Payment pending','payment-badge');paymentBadge.dataset.state=status.payment_state||'pending';badges.append(paymentBadge);head.append(identity,badges);parent.append(head);
 if(status.payment_mode==='test')parent.append(styled('p','Test order — no real payment or dispatch.','order-alert'));
 const details=status.delivery||{};
 const highlights=styled('div',undefined,'order-highlights');
 const highlightData=[
  ['Current status', status.status==='New'?'Order placed':status.status, nextStepMessage(status.status,details)],
  ['Payment', status.payment||'Payment pending', status.payment_state==='captured'?'Payment verified by DEMOR.':status.payment_state==='pending'?'Complete payment to avoid delays.':'Latest payment state shown here.'],
  ['Estimated delivery', deliveryWindow(details), details.carrier?`Courier: ${details.carrier}`:'Courier details appear after booking.'],
  ['Order total', money(status.total), `${(status.items||[]).length} item${(status.items||[]).length===1?'':'s'} in this order`]
 ];
 for(const [label,value,meta] of highlightData){const card=styled('div',undefined,'order-highlight');card.append(styled('span',label,'order-highlight-label'),node('strong',value),styled('small',meta));highlights.append(card)}
 parent.append(highlights);
 const items=styled('ul',undefined,'order-items');
 for(const item of status.items||[]){const li=node('li'),icon=styled('span','D','order-item-icon');icon.setAttribute('aria-hidden','true');const detail=node('div');detail.append(node('strong',item.name),styled('p','Size '+item.size+' · Quantity '+item.qty,'order-muted'));li.append(icon,detail,styled('strong',money(item.price*item.qty),'order-line-price'));items.append(li)}
 parent.append(items);const total=styled('div',undefined,'order-total');total.append(node('span','Item total'),node('strong',money(status.total)));parent.append(total);
 const delivery=styled('div',undefined,'order-delivery');delivery.append(styled('h3','Delivery progress','order-section-title'));
 const steps=['New','Confirmed','Packed','Shipped','Delivered'],current=steps.indexOf(status.status);
 if(status.status!=='Cancelled'){
  const timeline=styled('ol',undefined,'order-timeline');timeline.setAttribute('aria-label','Delivery progress');
  steps.forEach((step,index)=>{const li=node('li'),dot=styled('span',index<current?'✓':String(index+1),'step-dot');dot.setAttribute('aria-hidden','true');li.append(dot,node('span',step==='New'?'Placed':step));if(index<current)li.className='complete';if(index===current){li.className='current';li.setAttribute('aria-current','step')}timeline.append(li)});delivery.append(timeline);
 }else delivery.append(styled('p','This order was cancelled. Contact customer care if you need help with a payment or refund.','order-muted'));
 const grid=styled('dl',undefined,'delivery-details');
 for(const [title,value] of [['Courier',details.carrier],['Tracking number',details.tracking],['Estimated delivery',details.estimate],['Latest update',details.message]])if(value){const group=node('div');group.append(node('dt',title),node('dd',value));grid.append(group)}
 if(grid.childElementCount)delivery.append(grid);
 if(details.url){try{const url=new URL(details.url);if(url.protocol==='https:'){const link=styled('a','Track with courier ↗','order-track-link');link.href=url.href;link.target='_blank';link.rel='noopener noreferrer';delivery.append(link)}}catch{}}
 if(!details.carrier&&!['Cancelled','Delivered'].includes(status.status))delivery.append(styled('p','Courier and tracking details will appear here once available.','order-muted'));
 parent.append(delivery);
 if(status.review_required)parent.append(styled('p','A payment for this cancelled order requires refund review. No automatic refund has been issued.','order-alert'));
 const message=styled('p',undefined,'order-message');message.setAttribute('role','status');parent.append(message);
 const actions=styled('div',undefined,'order-actions');
 const refresh=styled('button','Refresh status','order-secondary');refresh.type='button';refresh.onclick=async()=>{refresh.disabled=true;message.textContent='Checking the latest order and payment status…';try{const next=await api('/api/payment-status',order);showOrder(parent,order,next);parent.querySelector('.order-message').textContent='Status updated just now.'}catch(e){message.textContent=e.message}finally{refresh.disabled=false}};actions.append(refresh);
 if(status.can_pay){const pay=styled('button',status.payment_mode==='test'?'Make test payment':'Pay online','order-primary');pay.type='button';pay.onclick=()=>startPayment(order,message,next=>showOrder(parent,order,next));actions.prepend(pay)}
 if(['New','Confirmed','Packed'].includes(status.status)){
  const box=styled('details',undefined,'order-private');
  box.append(node('summary','Cancel this order'));
  box.append(styled('p','Cancel before courier booking or dispatch. If payment was collected, the refund is reviewed separately and is not instant.','order-muted'));
  const reason=node('textarea');reason.rows=3;reason.maxLength=500;reason.required=true;reason.placeholder='Reason for cancellation (minimum 5 characters)';reason.setAttribute('aria-label','Cancellation reason');box.append(reason);
  const cancel=styled('button','Confirm cancellation','order-danger');cancel.type='button';cancel.onclick=async()=>{
   if(reason.value.trim().length<5){message.textContent='Please enter a reason (at least 5 characters).';return}
   if(!confirm('Cancel order '+order.id+'? This cannot be undone. If your parcel is already being booked, contact customer care instead.'))return;
   cancel.disabled=true;message.textContent='Checking order eligibility…';
   try{const next=await api('/api/cancel-order',{id:order.id,token:order.token,reason:reason.value});showOrder(parent,order,next);parent.querySelector('.order-message').textContent=next.cancellation_message||'Order cancelled.'}
   catch(e){message.textContent=e.message;cancel.disabled=false}
  };box.append(cancel);actions.append(box);
 }
 if(status.status==='Delivered'){
  const box=styled('details',undefined,'order-private');box.append(node('summary','Request a return'));
  box.append(styled('p','Returns are reviewed against our published returns policy. Sending this request does not issue a refund.','order-muted'));
  const reason=node('textarea');reason.placeholder='Reason for return (at least 5 characters)';reason.rows=3;reason.maxLength=1000;reason.setAttribute('aria-label','Return reason');box.append(reason);
  const send=styled('button','Send return request','order-secondary');send.type='button';send.onclick=async()=>{send.disabled=true;try{const r=await api('/api/order-request',{id:order.id,token:order.token,type:'Return request',message:reason.value,requestKey:crypto.randomUUID()});message.textContent='Return request sent: '+r.id;send.textContent='Request sent'}catch(e){message.textContent=e.message;send.disabled=false}};box.append(send);actions.append(box);
 }
 const support=styled('a','Get help / request a refund','order-help');support.href='support.html';actions.append(support);parent.append(actions);
 const privateCode=styled('details',undefined,'order-private');privateCode.append(node('summary',order.token?'Private order access':'Account order access'));
 if(order.token)privateCode.append(styled('p','Keep this code private. You can use it with your order number to open this order on another device.','order-muted'),styled('code',order.token,'private-code'));
 else privateCode.append(styled('p','This order is linked to your DEMOR account. Log in on another device to access it.','order-muted'));
 if(order.token){const copy=styled('button','Copy order number & code','order-secondary');copy.type='button';copy.onclick=async()=>{try{await navigator.clipboard.writeText('Order: '+order.id+'\nPrivate tracking code: '+order.token);message.textContent='Order number and private code copied.'}catch{message.textContent='Copy is unavailable. Select the order number and code to copy them manually.'}};privateCode.append(copy)}
 if(order.token){
  if(window.DemorAuth?.user?.()){
   const claim=styled('button','Link this order to My Account','order-secondary');claim.type='button';claim.onclick=async()=>{claim.disabled=true;message.textContent='Linking order to your account…';try{await api('/api/claim-order',order);message.textContent='Order linked. It will now appear whenever you sign in.';await orders()}catch(e){message.textContent=e.message;claim.disabled=false}};privateCode.append(claim);
  }
  const remove=styled('button','Forget on this device','order-forget');remove.type='button';remove.onclick=()=>{if(confirm('Remove this saved order from this device? Keep the private code if you want to open it again. This will not cancel your order.')){forget(order.id);orderStates.delete(order.id);orders()}};privateCode.append(remove);
 }
 parent.append(privateCode);applyOrderView();
}

async function init(){
 const root=document.getElementById('checkout-root');if(!root)return;const lines=cartLines(),form=document.getElementById('checkout-form'),summary=document.getElementById('checkout-summary');
 if(!lines.length){root.replaceChildren(node('h2','Your bag is empty.'));const link=node('a','View My Orders');link.href='my-orders.html';root.append(link);return}
 if(lines.some(l=>l.unavailable)){root.replaceChildren(node('h2','Please update your bag — an item or quantity is unavailable.'));const link=node('a','Review bag');link.href='cart.html';root.append(link);return}
 summary.replaceChildren();for(const l of lines)summary.append(node('p',l.product.name+' · '+l.size+' × '+l.qty+' — '+money(l.product.price*l.qty)));summary.append(node('strong','Item total: '+money(cartSubtotal())),node('p','Free standard delivery to serviceable Indian PIN codes. No extra standard shipping charge at checkout.'));
 const button=form.querySelector('button[type="submit"]');button.textContent='Place order & pay online';button.disabled=true;
 const gate=styled('section',undefined,'checkout-login-gate');
 const gateTitle=node('h2','Sign in to finish your order');const gateText=node('p','Browse and add to your bag without an account. Sign in with Google or email before placing an order.');
 const gateLink=styled('a','Log in / Create Account →','btn');gateLink.href='account.html?next=checkout.html';gate.append(gateTitle,gateText,gateLink);root.prepend(gate);
 const message=node('p');message.setAttribute('role','status');button.before(message);
 await window.DemorAuth?.ready?.();
 function showGate(){const signed=!!window.DemorAuth?.user?.();gate.hidden=signed;button.disabled=!signed;if(signed){const email=form.querySelector('[name=email]');if(email){email.value=window.DemorAuth.user().email;email.readOnly=true}}}
 showGate();document.addEventListener('demor:auth-changed',showGate);
 const notice=node('p','Order access is saved on this browser. On a shared device, use “Forget on this device” afterwards. Keep your private code to view the order on another phone.');button.before(notice);
 try{const config=await api('/api/payment-config');if(!config.enabled){message.textContent='Online payment setup is not complete. Please contact the store.';return}if(config.mode==='test'){message.textContent='TEST MODE — no real money is collected and test orders are not dispatched.';button.textContent='Place test order & test payment'}button.disabled=!window.DemorAuth?.user?.()}catch(e){message.textContent=e.message;return}
 form.addEventListener('submit',async event=>{
  event.preventDefault();
  if(!window.DemorAuth?.user?.()){message.textContent='Please log in before placing an order.';gate.hidden=false;return}
  button.disabled=true;message.textContent='Saving your order…';
  try{
   const payload={customer:Object.fromEntries(new FormData(form)),items:lines.map(l=>({id:l.product.id,size:l.size,qty:l.qty,expectedPrice:l.product.price})),online:true};
   const key=await requestKey(payload);const order=await api('/api/orders',{...payload,requestKey:key});const stored=remember(order);saveCart([]);await window.DemorCartSync?.flush?.();try{localStorage.removeItem(DRAFT)}catch{}
   root.replaceChildren(node('h2','Order saved: '+order.id),node('p','Keep your private tracking code: '+order.token));
   if(!stored)root.append(node('p','Your browser could not save this order. Copy the order number and private code now.'));
   const link=node('a','My Orders');link.href='my-orders.html';link.className='btn';root.append(link);
   const result=node('p');result.setAttribute('role','status');root.append(result);const retry=node('button','Open payment window');retry.className='btn';retry.onclick=()=>startPayment(order,result,()=>{location.href='my-orders.html'});root.append(retry);
   await startPayment(order,result,()=>{location.href='my-orders.html'});
  }catch(e){message.textContent=e.message;button.disabled=false}
 });
}
async function orders(){
 const list=document.getElementById('my-order-list');if(!list)return;
 const generation=++orderGeneration;orderStates.clear();list.replaceChildren();list.setAttribute('aria-busy','true');
 accountOrders=[];
 if(window.DemorAuth){await window.DemorAuth.ready();if(window.DemorAuth.user()){
  try{const mine=await api('/api/my-orders');accountOrders=(mine.orders||[]).map(item=>({id:item.id,token:''}));}
  catch(e){list.append(styled('p','Account orders could not be loaded: '+e.message,'order-alert'))}
 }}
 if(generation!==orderGeneration)return;
 const entries=knownOrders();
 const toolbar=document.getElementById('orders-toolbar');if(toolbar)toolbar.hidden=!entries.length;
 if(!entries.length){const empty=styled('div',undefined,'orders-empty');empty.append(styled('span','D','empty-monogram'),node('h2','Your next story starts here.'),styled('p','No orders are saved on this browser yet. Explore the collection, or add an existing order using its private code.','order-muted'));const shop=styled('a','Explore the collection →','order-primary');shop.href='shop.html';const find=styled('a','Add an existing order','order-secondary');find.href='#find-existing';empty.append(shop,find);list.append(empty)}
 const cards=entries.map(order=>{const card=styled('section',undefined,'order-card');card.dataset.orderId=order.id;card.append(node('h2',order.id),styled('p','Loading your latest update…','order-muted'));list.append(card);return card});applyOrderView();
 // Keep requests serial and preserve all private order credentials locally.
 for(let i=0;i<entries.length;i++){
  const order=entries[i],card=cards[i];if(generation!==orderGeneration)return;
  try{const status=await api('/api/track',order);if(generation!==orderGeneration)return;showOrder(card,order,status)}
  catch(e){card.replaceChildren(node('h2',order.id),styled('p',e.message,'order-alert'));const retry=styled('button','Try again','order-secondary');retry.type='button';retry.onclick=()=>orders();const remove=styled('button','Forget this saved code','order-forget');remove.type='button';remove.onclick=()=>{if(confirm('Forget this saved order on this device? The order itself will not be cancelled.')){forget(order.id);orders()}};card.append(retry,remove)}
 }
 if(generation===orderGeneration){list.setAttribute('aria-busy','false');applyOrderView()}
}

window.DemorCheckout={init,orders,startPayment};
document.addEventListener('DOMContentLoaded',()=>{
 const form=document.getElementById('find-order');if(!form)return;
 document.querySelectorAll('[data-order-filter]').forEach(button=>button.addEventListener('click',()=>{orderView.filter=button.dataset.orderFilter;document.querySelectorAll('[data-order-filter]').forEach(other=>other.setAttribute('aria-pressed',String(other===button)));applyOrderView()}));
 document.getElementById('order-search')?.addEventListener('input',e=>{orderView.search=e.target.value;applyOrderView()});
 document.getElementById('reset-order-filters')?.addEventListener('click',()=>{orderView.filter='all';orderView.search='';const input=document.getElementById('order-search');if(input)input.value='';document.querySelectorAll('[data-order-filter]').forEach(button=>button.setAttribute('aria-pressed',String(button.dataset.orderFilter==='all')));applyOrderView()});
 form.onsubmit=async e=>{
  e.preventDefault();const message=document.getElementById('find-message'),button=form.querySelector('button[type="submit"]');if(button)button.disabled=true;message.textContent='Finding your order…';
  const inputs=new FormData(form),order={id:String(inputs.get('id')||'').trim(),token:String(inputs.get('token')||'').trim()};
  try{await api('/api/track',order);if(!remember(order))throw Error('Browser storage is unavailable. Enable site storage before saving orders.');message.textContent='Order added to this device.';form.reset();orderView.filter='all';orderView.search='';const search=document.getElementById('order-search');if(search)search.value='';document.querySelectorAll('[data-order-filter]').forEach(item=>item.setAttribute('aria-pressed',String(item.dataset.orderFilter==='all')));await orders()}
  catch(err){message.textContent=err.message}finally{if(button)button.disabled=false}
 };
 document.addEventListener('demor:auth-changed',()=>orders());
 orders();
});
})();
