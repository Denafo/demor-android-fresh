/* DEMOR customer accounts: custom user-facing forms, Netlify Identity underneath.
   Admin credentials and third-party OAuth secrets never enter the browser.
   The widget stays loaded only for existing Identity sessions / OAuth-email callbacks;
   the normal login and signup forms DO NOT open the widget's branded modal. */
(()=>{
  'use strict';
  // Netlify's default recovery email returns to the site root with a URL-hash token.
  // Route it to DEMOR's mobile reset form before Identity widget initialises.
  const recoveryParams=new URLSearchParams(window.location.hash.slice(1));
  if(recoveryParams.has('recovery_token')&&!window.location.pathname.endsWith('/reset-password.html')){
    window.location.replace('/reset-password.html'+window.location.hash);
    return;
  }
  let initialized=false, resolveReady;
  const readyPromise=new Promise(resolve=>{resolveReady=resolve});
  const identity=()=>window.netlifyIdentity;
  const currentUser=()=>identity()?.currentUser()||null;
  const allowedNext=['checkout.html','my-orders.html','account.html'];
  const urlNext=()=>{const next=new URLSearchParams(location.search).get('next');return allowedNext.includes(next)?next:''};
  const message=(text,error=false)=>{
    const box=document.getElementById('demor-auth-message')||document.querySelector('[data-auth-error]');
    if(!box)return;
    box.textContent=text;box.hidden=!text;box.classList.toggle('auth-error',error);
  };
  function open(tab='login'){
    const next=location.pathname.endsWith('/checkout.html')?'checkout.html':urlNext();
    location.assign('account.html'+(next?'?next='+encodeURIComponent(next):'')+(tab==='signup'?'#signup':''));
  }
  async function token(){
    await readyPromise;
    const user=currentUser();if(!user)return null;
    try{return await user.jwt()}catch{return null}
  }
  function accountName(user){return user?.user_metadata?.full_name||user?.email?.split('@')[0]||'My Account'}
  function updateUI(){
    const user=currentUser();
    document.querySelectorAll('[data-customer-account]').forEach(el=>{
      el.textContent=user?'My Account':'Login / Sign Up';
      el.setAttribute('aria-label',user?accountName(user):'Login or sign up');
      el.setAttribute('href','account.html'+(location.pathname.endsWith('/checkout.html')?'?next=checkout.html':''));
    });
    document.querySelectorAll('[data-customer-name]').forEach(el=>el.textContent=user?accountName(user):'Guest');
    document.querySelectorAll('[data-auth-required]').forEach(el=>el.hidden=!!user);
    document.querySelectorAll('[data-auth-signed-in]').forEach(el=>el.hidden=!user);
    document.querySelectorAll('[data-customer-email]').forEach(el=>el.textContent=user?.email||'');
    document.dispatchEvent(new CustomEvent('demor:auth-changed',{detail:{signedIn:!!user}}));
  }
  function addHeader(){
    const header=document.querySelector('.header-actions');
    if(header&&!header.querySelector('[data-customer-account]')){
      const link=document.createElement('a');link.className='demor-account-link';link.href='account.html';link.dataset.customerAccount='';link.textContent='Login / Sign Up';header.prepend(link);
    }
    const nav=document.querySelector('.mobile-nav');
    if(nav&&!nav.querySelector('[data-customer-account]')){
      const link=document.createElement('a');link.href='account.html';link.dataset.customerAccount='';link.textContent='Login / Sign Up';nav.append(link);
    }
  }
  function formState(button,busy){
    if(!button)return;
    if(busy){button.dataset.originalText=button.textContent;button.textContent='Please wait…'}
    else if(button.dataset.originalText){button.textContent=button.dataset.originalText;delete button.dataset.originalText}
    button.disabled=busy;
  }
  function showTab(tab){
    const selected=tab==='signup'?'signup':'login';
    document.querySelectorAll('[data-auth-tab]').forEach(el=>el.setAttribute('aria-selected',String(el.dataset.authTab===selected)));
    document.querySelectorAll('[data-auth-form]').forEach(el=>el.hidden=el.dataset.authForm!==selected);
    const title=document.getElementById('auth-form-title'),intro=document.getElementById('auth-form-intro');
    if(title)title.textContent=selected==='signup'?'Join the club.':'Welcome back.';
    if(intro)intro.textContent=selected==='signup'?'Create your free account and make every order easier.':'Sign in to continue shopping and manage your orders.';
    message('');
  }
  function showRecovery(){
    document.querySelectorAll('[data-auth-form]').forEach(el=>el.hidden=el.dataset.authForm!=='recover');
    const title=document.getElementById('auth-form-title'),intro=document.getElementById('auth-form-intro');
    if(title)title.textContent='Reset your password.';
    if(intro)intro.textContent='We will help you regain secure access to your DEMOR account.';
    const email=document.getElementById('auth-login-email');
    const recoveryEmail=document.getElementById('auth-recovery-email');
    if(email&&recoveryEmail)recoveryEmail.value=email.value;
    message('');
  }
  function accountPage(){
    if(!document.querySelector('[data-account-page]'))return;
    document.querySelectorAll('[data-auth-tab]').forEach(tab=>tab.addEventListener('click',()=>showTab(tab.dataset.authTab)));
    document.querySelector('[data-action-recover]')?.addEventListener('click',showRecovery);
    document.querySelector('[data-action-login]')?.addEventListener('click',()=>showTab('login'));
    document.querySelector('[data-action-logout]')?.addEventListener('click',()=>identity()?.logout());
    document.querySelectorAll('.auth-show-password').forEach(button=>button.addEventListener('click',()=>{
      const field=button.parentElement.querySelector('input');
      if(!field)return;
      const reveal=field.type==='password';field.type=reveal?'text':'password';
      button.textContent=reveal?'Hide':'Show';button.setAttribute('aria-pressed',String(reveal));
      button.setAttribute('aria-label',reveal?'Hide password':'Show password');
    }));
    const next=urlNext();
    const after=document.querySelector('[data-account-next]');
    if(after){after.href=next||'my-orders.html';after.textContent=next==='checkout.html'?'Continue to checkout →':'View My Orders →'}
    if(location.hash==='#signup')showTab('signup');
    const submit=async(event,mode)=>{
      event.preventDefault();
      const form=event.currentTarget;
      if(!form.checkValidity()){form.reportValidity();return}
      if(!initialized||!identity()?.gotrue){message('Login is still loading. Please refresh and try again.',true);return}
      const button=form.querySelector('[type=submit]');formState(button,true);message('');
      const values=new FormData(form),email=String(values.get('email')||'').trim(),password=String(values.get('password')||'');
      try{
        if(mode==='login'){
          await identity().gotrue.login(email,password,true);
          // The GoTrue client and Identity widget use the same persisted account session.
          // Reload to let the existing widget initialize its currentUser and JWT state.
          location.assign(urlNext()||'my-orders.html');
          return;
        }
        if(mode==='signup'){
          await identity().gotrue.signup(email,password,{full_name:String(values.get('full_name')||'').trim()});
          form.reset();
          message('Account created. Please check your email and confirm your address before logging in.');
          return;
        }
        await identity().gotrue.requestPasswordRecovery(email);
        message('If this address is registered, a password reset email has been sent. Check your inbox and spam folder.');
      }catch(error){
        message(error?.message||'We could not complete this request. Please try again.',true);
      }finally{formState(button,false)}
    };
    document.querySelectorAll('[data-auth-form]').forEach(form=>form.addEventListener('submit',event=>submit(event,form.dataset.authForm)));
    document.querySelector('[data-action-google]')?.addEventListener('click',()=>{
      if(!initialized||!identity()?.gotrue){message('Google Login is still loading. Please try again.',true);return}
      try{
        // Google's custom OAuth Client ID/Secret are configured in Netlify dashboard, never here.
        // Save an allow-listed destination to restore after the Identity redirect to home.
        sessionStorage.setItem('demor_auth_destination',urlNext()||'my-orders.html');
        location.assign(identity().gotrue.loginExternalUrl('google'));
      }catch(error){message(error?.message||'Unable to start Google Login.',true)}
    });
  }
  document.addEventListener('DOMContentLoaded',()=>{
    addHeader();accountPage();
    if(!identity()){
      resolveReady();
      const box=document.querySelector('[data-auth-error]');
      if(box){box.hidden=false;box.textContent='Customer login is temporarily unavailable. Refresh this page and try again.'}
      return;
    }
    identity().on('init',()=>{initialized=true;resolveReady();updateUI()});
    identity().on('login',()=>{
      updateUI();identity().close();
      let destination='';
      try{destination=sessionStorage.getItem('demor_auth_destination')||'';sessionStorage.removeItem('demor_auth_destination')}catch{}
      if(allowedNext.includes(destination)&&!location.pathname.endsWith('/'+destination)){location.replace(destination);return}
      if(document.querySelector('[data-account-page]')&&urlNext()){location.assign(urlNext())}
    });
    identity().on('logout',updateUI);
    identity().on('error',error=>{
      const box=document.querySelector('[data-auth-error]');
      if(box){box.hidden=false;box.textContent=error?.message||'Login failed. Please try again.'}
    });
    identity().init({logo:false});
  });
  window.DemorAuth={ready:()=>readyPromise,user:currentUser,token,open,logout:()=>identity()?.logout()};
})();
