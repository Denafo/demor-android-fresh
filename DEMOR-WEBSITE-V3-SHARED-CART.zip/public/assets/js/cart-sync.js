/* DEMOR account shopping bag sync, shared by website and Android.
   No customer IDs or prices are trusted from a browser. All saves require a
   verified Identity bearer token and optimistic server revision. */
(() => {
  'use strict';
  const migratePrefix = 'demor_cloud_cart_migrated_v1:';
  const pendingKey = 'demor_guest_cart_pending_v1';
  const eq = (a,b) => JSON.stringify(a) === JSON.stringify(b);
  let accountId = null, revision = null, serverItems = [];
  let loading = false, saving = false, dirty = false, applying = false, timer = null;
  let generation = 0;
  const validItems = (items) => {
    if (!Array.isArray(items)) return [];
    const distinct = new Map();
    for (const i of items) {
      if (!i || typeof i.id !== 'string' || !['S','M','L','XL','XXL'].includes(i.size) ||
          !Number.isInteger(i.qty) || i.qty < 1) continue;
      const product = (window.PRODUCTS || PRODUCTS).find(p => p.id === i.id);
      const max = Math.min(20, Number(product?.stock?.[i.size] || 0));
      if (max < 1) continue;
      distinct.set(i.id + '/' + i.size, {id:i.id,size:i.size,qty:Math.min(max,i.qty)});
    }
    return Array.from(distinct.values()).slice(0,50);
  };
  const itemsMap = items => new Map(items.map(i=>[i.id+'/'+i.size,i]));
  const merge = (remote, local) => {
    const byKey = itemsMap(validItems(remote));
    for (const entry of validItems(local)) {
      const key = entry.id+'/'+entry.size;
      byKey.set(key,{...entry,qty:Math.max(byKey.get(key)?.qty || 0, entry.qty)});
    }
    return validItems(Array.from(byKey.values()));
  };
  function status(message, failed=false) {
    let node = document.getElementById('demor-cart-sync-status');
    if (!node && document.getElementById('cart-root')) {
      node = document.createElement('p');node.id = 'demor-cart-sync-status';
      node.setAttribute('role','status');node.style.cssText='font-size:13px;margin:10px 0;color:#225d50';
      document.getElementById('cart-root').before(node);
    }
    if (node) { node.textContent=message;node.style.color=failed?'#a32626':'#225d50'; }
  }
  function apply(items) {
    applying=true;
    try {
      localStorage.setItem('demor_cart_v1',JSON.stringify(items));
      window.updateCartCount?.();
      window.renderCartPage?.();
    } finally {applying=false;}
  }
  async function request(method, payload) {
    const token = await window.DemorAuth?.token();
    if (!token) throw Error('Session expired. Please sign in again.');
    const headers = {'Authorization':'Bearer '+token, 'Accept':'application/json'};
    if (method==='POST') headers['Content-Type']='application/json';
    const response=await fetch('/api/my-cart',{method,headers,cache:'no-store',
      ...(payload ? {body:JSON.stringify(payload)}:{} )});
    const result=await response.json().catch(()=>({}));
    if(!response.ok){const e=Error(result.error||'Could not sync bag');e.status=response.status;throw e;}
    return result;
  }
  function changes(base,current) {
    const previous=itemsMap(base),now=itemsMap(current),patch=new Map();
    for (const [key,i] of now) if (!eq(i,previous.get(key))) patch.set(key,i);
    for (const key of previous.keys()) if (!now.has(key)) patch.set(key,null);
    return patch;
  }
  function applyPatch(base, patch) {
    const map=itemsMap(base);
    for (const [key,item] of patch) item ? map.set(key,item) : map.delete(key);
    return validItems(Array.from(map.values()));
  }
  async function saveNow() {
    if (saving||loading||revision===null||!accountId||!dirty) return;
    saving=true;
    try {
      let attempted=validItems(window.getCart());
      let base=serverItems,expected=revision;
      for (let attempt=0;attempt<3;attempt++) {
        try {
          const saved=await request('POST',{items:attempted,revision:expected});
          serverItems=validItems(saved.items);revision=saved.revision;
          // Edits made during the request are preserved for another flush.
          const current=validItems(window.getCart());
          dirty=!eq(current,attempted);
          if(!dirty) apply(serverItems);
          if(!dirty)localStorage.removeItem(pendingKey);
          status(dirty?'Saving new changes…':'Bag synced across devices');
          return;
        } catch(error) {
          if(error.status!==409) throw error;
          const fresh=await request('GET');
          attempted=applyPatch(validItems(fresh.items),changes(base,attempted));
          base=validItems(fresh.items);expected=fresh.revision;
        }
      }
      throw Error('Another device changed your bag. Open your bag again to retry.');
    } catch (error) {dirty=true;status(error.message,true)}
    finally {saving=false;if(dirty&&accountId) schedule(1600)}
  }
  function schedule(delay=350) {
    if(timer) clearTimeout(timer);
    timer=setTimeout(()=>{timer=null;void saveNow()},delay);
  }
  function localChanged() {
    if(applying) return;
    dirty=true;
    try{localStorage.setItem(pendingKey,'1')}catch{}
    if(accountId&&revision!==null) schedule();
  }
  async function init() {
    if(loading||saving)return;
    await window.DemorAuth?.ready();
    const user=window.DemorAuth?.user();
    if(!user?.id){accountId=null;revision=null;serverItems=[];return}
    const current=String(user.id);
    if(accountId===current&&revision!==null)return;
    accountId=current;revision=null;serverItems=[];
    const myGeneration=++generation;
    loading=true;
    status('Loading your shared bag…');
    try {
      const loaded=await request('GET');
      if(myGeneration!==generation)return;
      revision=loaded.revision;serverItems=validItems(loaded.items);
      const key=migratePrefix+current;
      const firstTime=!localStorage.getItem(key) || !!localStorage.getItem(pendingKey);
      if(firstTime) {
        const combined=merge(serverItems,window.getCart());
        if(!eq(combined,serverItems)){
          // This device had a pre-sync cart: preserve it instead of replacing.
          const saved=await request('POST',{items:combined,revision});
          revision=saved.revision;serverItems=validItems(saved.items);
        }
        localStorage.setItem(key,'1');
        localStorage.removeItem(pendingKey);
      }
      if(dirty){
        // Guest edits made while loading must not silently disappear.
        const combined=merge(serverItems,window.getCart());
        apply(combined);dirty=!eq(combined,serverItems);
      }else apply(serverItems);
      status('Bag synced across devices');
    } catch(error) {status(error.message,true)}
    finally {loading=false;if(dirty&&revision!==null)schedule()}
  }
  async function pull() {
    if(!accountId||revision===null||loading||saving)return;
    if(dirty){schedule(50);return}
    loading=true;
    try{const latest=await request('GET');revision=latest.revision;serverItems=validItems(latest.items);apply(serverItems);status('Bag synced across devices')}
    catch(error){status(error.message,true)}finally{loading=false}
  }
  window.DemorCartSync={localChanged,pull,flush:()=>saveNow()};
  document.addEventListener('DOMContentLoaded',()=>void init());
  document.addEventListener('demor:auth-changed',()=>{if(!window.DemorAuth?.user()){accountId=null;revision=null;serverItems=[];generation++;return}void init()});
  window.addEventListener('focus',()=>void pull());
  document.addEventListener('visibilitychange',()=>{if(!document.hidden)void pull()});
})();
