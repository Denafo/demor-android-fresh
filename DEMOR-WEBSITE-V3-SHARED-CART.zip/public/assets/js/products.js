// Live products load immediately after this script. Never fall back to stale sample stock.
const PRODUCTS=[];
document.addEventListener('DOMContentLoaded',()=>{
 if(!PRODUCTS.length){const notice=document.createElement('p');notice.textContent='Our collection is being updated. Please check back shortly.';notice.setAttribute('role','status');notice.style.cssText='padding:20px;text-align:center;background:#f5ecdf;color:#352b23';document.querySelector('main')?.prepend(notice)}
});
