/* =========================================================
   DEMOR — placeholder garment illustrations
   These are simple line-art SVGs standing in for real product
   photography. Replace with actual photoshoot images before
   launch — see README.md ("Replacing placeholder artwork").
   ========================================================= */

function paisley(x, y, scale, color, rot){
  rot = rot || 0;
  return `<g transform="translate(${x} ${y}) rotate(${rot}) scale(${scale})" fill="none" stroke="${color}" stroke-width="1.4">
    <path d="M0 0c-8-10-2-24 10-24 10 0 16 8 14 18-1 7-8 10-8 16 0 5 4 7 8 6" />
    <circle cx="10" cy="-14" r="1.6" fill="${color}" stroke="none"/>
  </g>`;
}

function borderMotif(cx, topY, width, color){
  let dots = '';
  const n = 7;
  for(let i=0;i<n;i++){
    const x = cx - width/2 + (width/(n-1))*i;
    dots += `<path d="M${x} ${topY} q4 6 0 12 q-4 -6 0 -12" fill="none" stroke="${color}" stroke-width="1"/>`;
  }
  return dots;
}

/**
 * garmentSVG - returns an inline SVG string illustrating a garment silhouette.
 * opts: { garment, collar, pattern, tone, accent, includePajama, id }
 *   garment: 'kurta' | 'sherwani' | 'nehru'
 *   collar:  'band' | 'nehru' | 'open'
 *   pattern: 'none' | 'paisley' | 'border'
 *   tone:    fill color of garment body
 *   accent:  gold linework color
 */
function garmentSVG(opts){
  if(opts?.image && /^\/api\/product-image\?id=[a-z0-9-]+&v=\d+$/.test(opts.image))return '<img src="'+opts.image.replace(/&/g,'&amp;')+'" alt="'+(opts.alt||'Product photograph')+'" width="400" height="560" style="width:100%;height:100%;object-fit:contain" loading="'+(opts.priority?'eager':'lazy')+'" '+(opts.priority?'fetchpriority="high"':'decoding="async"')+'>';
  const o = Object.assign({
    garment:'kurta', collar:'band', pattern:'none',
    tone:'#EFE6D0', accent:'#A9832E', includePajama:true, id:'g'+Math.random().toString(36).slice(2)
  }, opts);

  if(o.garment==='blazer'||o.garment==='jodhpuri'){
    const jodh=o.garment==='jodhpuri';
    const collar=jodh?'<path d="M175 105v-19q25-14 50 0v19" fill="none" stroke="#272420" stroke-width="3"/>':'<path d="M175 104l25 56 25-56-25 24z" fill="#f5eee0" stroke="#272420" stroke-width="2"/><path d="M175 104l-18 55 43 20 43-20-18-55" fill="none" stroke="#272420" stroke-width="2"/>';
    return `<svg viewBox="0 0 400 560" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Illustration of ${jodh?'Jodhpuri':'blazer'}"><defs><linearGradient id="bg-${o.id}" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#ebe4d6"/><stop offset="1" stop-color="#d6cbb8"/></linearGradient></defs><rect width="400" height="560" fill="url(#bg-${o.id})"/><ellipse cx="200" cy="525" rx="104" ry="10" fill="#171717" opacity=".08"/><circle cx="200" cy="58" r="27" fill="none" stroke="#272420" stroke-width="1.5" opacity=".5"/><path d="M157 101L132 115 98 275l35 15 28-99-8 223q48 27 94 0l-8-223 28 99 35-15-34-160-26-14z" fill="${o.tone}" stroke="#272420" stroke-width="3"/>${collar}<path d="M200 167v239" stroke="#272420" stroke-width="1.5" opacity=".7"/><circle cx="200" cy="203" r="3.3" fill="${o.accent}"/><circle cx="200" cy="244" r="3.3" fill="${o.accent}"/><circle cx="200" cy="285" r="3.3" fill="${o.accent}"/>${jodh?'<path d="M161 110Q199 123 238 110M166 141q34 12 68 0" fill="none" stroke="#c8a86b" stroke-width="1.6"/>':'<path d="M153 337h38M209 337h38" stroke="#272420" stroke-width="3"/>'}<path d="M160 418l-8 101h40l8-94 8 94h40l-8-101" fill="#666158" stroke="#272420" stroke-width="1.5"/></svg>`;
  }
  const ink = '#241F17';
  const hemY = o.garment==='sherwani' ? 430 : (o.garment==='nehru' ? 330 : 400);
  const flare = o.garment==='sherwani' ? 46 : 26;

  let collarPath = '';
  if(o.collar==='band'){
    collarPath = `<path d="M172 96c8-10 20-16 28-16s20 6 28 16" fill="none" stroke="${ink}" stroke-width="2"/>`;
  } else if(o.collar==='nehru'){
    collarPath = `<path d="M170 92c10-14 26-20 30-20s20 6 30 20" fill="none" stroke="${ink}" stroke-width="3"/>`;
  } else {
    collarPath = `<path d="M168 94l32 26 32-26" fill="none" stroke="${ink}" stroke-width="2"/>`;
  }

  let sherwaniLayer = '';
  if(o.garment==='sherwani'){
    sherwaniLayer = `<path d="M150 150c-10 90-16 180-8 260" fill="none" stroke="${o.accent}" stroke-width="1.2" opacity=".6"/>
      <path d="M250 150c10 90 16 180 8 260" fill="none" stroke="${o.accent}" stroke-width="1.2" opacity=".6"/>`;
  }

  let pattern = '';
  if(o.pattern==='paisley'){
    pattern += paisley(160,150,0.9,o.accent,-10);
    pattern += paisley(238,150,0.9,o.accent,10);
    pattern += paisley(200,120,0.7,o.accent,0);
  } else if(o.pattern==='border'){
    pattern += borderMotif(200, hemY-14, 150, o.accent);
  }

  const pajama = o.includePajama ? `
    <path d="M172 ${hemY} c-6 46-10 92-16 130 c8 6 18 6 24 0 c4-40 8-78 12-118 c8 40 4 92 10 118 c6 6 16 6 24 0 c-4-40-6-84-10-130 z"
      fill="${shade(o.tone,-8)}" stroke="${ink}" stroke-width="1.6"/>
  ` : '';

  return `
  <svg viewBox="0 0 400 560" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Illustration of ${o.garment}">
    <defs>
      <linearGradient id="bg-${o.id}" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stop-color="#F1E9D8"/>
        <stop offset="1" stop-color="#E8DBBE"/>
      </linearGradient>
    </defs>
    <rect width="400" height="560" fill="url(#bg-${o.id})"/>
    <ellipse cx="200" cy="520" rx="120" ry="14" fill="#1A160F" opacity=".06"/>

    <!-- head hint -->
    <circle cx="200" cy="62" r="26" fill="none" stroke="${ink}" stroke-width="1.6" opacity=".55"/>

    <!-- sleeves -->
    <path d="M150 118c-30 20-46 70-40 132" fill="none" stroke="${ink}" stroke-width="2"/>
    <path d="M250 118c30 20 46 70 40 132" fill="none" stroke="${ink}" stroke-width="2"/>
    <path d="M110 250c-4 26 4 46 16 54" fill="none" stroke="${ink}" stroke-width="2"/>
    <path d="M290 250c4 26-4 46-16 54" fill="none" stroke="${ink}" stroke-width="2"/>

    <!-- body / tunic -->
    <path d="M150 118
             c-6 14-8 30-6 46
             l-${flare>30?18:10} 232
             c16 14 40 20 56 20
             ${o.garment!=='nehru' ? `l6-110 6 110` : ''}
             c16 0 40-6 56-20
             l-${flare>30?18:10} -232
             c2-16 0-32-6-46
             ${collar_curveTop()}
             z"
          fill="${o.tone}" stroke="${ink}" stroke-width="2"/>

    ${collarPath}
    <!-- placket -->
    <line x1="200" y1="112" x2="200" y2="${hemY-40}" stroke="${ink}" stroke-width="1.4" opacity=".7"/>
    <circle cx="200" cy="140" r="2.4" fill="${ink}"/>
    <circle cx="200" cy="168" r="2.4" fill="${ink}"/>
    <circle cx="200" cy="196" r="2.4" fill="${ink}"/>

    ${sherwaniLayer}
    ${pattern}
    ${pajama}
  </svg>`;

  function collar_curveTop(){ return ''; }
  function shade(hex, amt){
    const c = hex.replace('#','');
    const num = parseInt(c,16);
    let r=(num>>16)+amt, g=((num>>8)&0xff)+amt, b=(num&0xff)+amt;
    r=Math.max(0,Math.min(255,r)); g=Math.max(0,Math.min(255,g)); b=Math.max(0,Math.min(255,b));
    return `#${(1<<24|r<<16|g<<8|b).toString(16).slice(1)}`;
  }
}

function starIcon(){
  return `<svg viewBox="0 0 20 20" fill="currentColor"><path d="M10 1l2.6 5.9 6.4.6-4.8 4.3 1.4 6.2L10 14.9 4.4 18l1.4-6.2L1 7.5l6.4-.6L10 1z"/></svg>`;
}
