/* DEMOR storefront */

const CART_KEY = "demor_cart_v1";

/* Explicit Android -> website bag transfer. This is intentionally not
   automatic synchronization. Uses a URL fragment (not a query string) so
   items are not sent to the web server as URL parameters. No user tokens.
   Server checkout still validates price, stock and identity. */
function importAndroidBagOnce() {
  if (location.pathname !== '/cart.html') return;
  const hash = location.hash.slice(1);
  if (!hash.startsWith('demor_app_cart=')) return;
  // Remove transferred payload from the address bar immediately, even on error.
  history.replaceState(history.state, '', location.pathname + location.search);
  try {
    const encoded = hash.slice('demor_app_cart='.length);
    if (!encoded || encoded.length > 8000 || !/^[A-Za-z0-9_-]+$/.test(encoded)) throw Error('Invalid transfer');
    const normalized = encoded.replace(/-/g, '+').replace(/_/g, '/');
    const raw = atob(normalized + '='.repeat((4 - normalized.length % 4) % 4));
    if (raw.length > 6000) throw Error('Transfer too large');
    const incoming = JSON.parse(raw);
    if (!Array.isArray(incoming) || incoming.length < 1 || incoming.length > 30) throw Error('Invalid bag');
    const combined = getCart();
    const used = new Set();
    for (const entry of incoming) {
      if (!entry || typeof entry !== 'object' || Array.isArray(entry) ||
          typeof entry.id !== 'string' || !/^[a-z0-9][a-z0-9-]{2,59}$/.test(entry.id) ||
          !['S', 'M', 'L', 'XL', 'XXL'].includes(entry.size) ||
          !Number.isInteger(entry.qty) || entry.qty < 1 || entry.qty > 20) throw Error('Invalid item');
      const key = entry.id + '/' + entry.size;
      if (used.has(key)) throw Error('Duplicate bag item');
      used.add(key);
      // Do not trust a claimed price: getCart and checkout resolve the live product.
      const product = PRODUCTS.find(p => p.id === entry.id);
      if (!product) throw Error('Product no longer available');
      const allowed = Math.min(20, product.stock?.[entry.size] || 0);
      if (allowed < entry.qty) throw Error('Stock changed. Update the app bag first');
    }
    for (const entry of incoming) {
      const existing = combined.find(x => x.id === entry.id && x.size === entry.size);
      if (existing) existing.qty = entry.qty;
      else combined.push({id:entry.id, size:entry.size, qty:entry.qty});
    }
    if (combined.length > 50) throw Error('Bag is too large');
    if (!saveCart(combined)) throw Error('Bag could not be saved');
    showToast('Items transferred from your DEMOR app');
  } catch (error) {
    console.warn('DEMOR bag transfer rejected:', error.message);
    showToast('Could not transfer bag. Please refresh products and try again.');
  }
}
const INR = n => "₹" + Number(n).toLocaleString("en-IN");
const CATEGORY_LABELS={kurtas:"Kurta","kurta-pajama-sets":"Kurta Pajama Set","nehru-jackets":"Nehru Jacket",blazers:"Blazer",jodhpuri:"Jodhpuri"};
const categoryLabel=key=>CATEGORY_LABELS[key]||"Menswear";

/* ---------------- Cart storage ---------------- */
function getCart(){
  try{ const items=JSON.parse(localStorage.getItem(CART_KEY))||[];return Array.isArray(items)?items.filter(i=>i&&/^[a-z0-9][a-z0-9-]{2,59}$/.test(i.id)&&['S','M','L','XL','XXL'].includes(i.size)&&Number.isInteger(i.qty)&&i.qty>0&&i.qty<=100):[]; }
  catch(e){ return []; }
}
function saveCart(cart){
  try { localStorage.setItem(CART_KEY, JSON.stringify(cart)); } catch(e) { showToast("Your browser could not save the bag. Please enable site storage."); return false; }
  updateCartCount();
  window.DemorCartSync?.localChanged();
  return true;
}
function addToCart(productId, size, qty){
  qty = qty || 1;
  const cart = getCart();
  const existing = cart.find(i => i.id === productId && i.size === size);
  const p=PRODUCTS.find(p=>p.id===productId);
  if(!p||!size||!Number.isInteger(qty)||qty<1||(existing?.qty||0)+qty>Math.min(20,p.stock?.[size]||0)){showToast('Not enough stock in this size. Please choose another size or quantity.');return false;}
  if(existing){ existing.qty += qty; }
  else{ cart.push({ id: productId, size: size, qty: qty }); }
  if(!saveCart(cart)) return false;
  showToast("Added to bag");
  return true;
}
function removeFromCart(productId, size){
  saveCart(getCart().filter(i => !(i.id === productId && i.size === size)));
  if(document.getElementById("cart-root")) renderCartPage();
}
function updateCartQty(productId, size, qty){
  if(!Number.isInteger(qty) || qty<1) return;
  const cart = getCart();
  const item = cart.find(i => i.id === productId && i.size === size);
  const p=PRODUCTS.find(p=>p.id===productId);
  if(item){if(qty>Math.min(20,p?.stock?.[size]||0)){showToast('This quantity is unavailable.');return;}item.qty = Math.max(1, qty); saveCart(cart); }
  if(document.getElementById("cart-root")) renderCartPage();
}
function cartCount(){ return getCart().reduce((n,i)=>n+i.qty,0); }
function cartLines(){
  return getCart().map(i => {
    const p = PRODUCTS.find(p => p.id === i.id);
    return { ...i, unavailable:!p||i.qty>(p.stock?.[i.size]||0), product:p||{id:i.id,name:'Unavailable product — remove from bag',price:0,art:{garment:'kurta',tone:'#ddd'},stock:{}} };
  }).filter(Boolean);
}
function cartSubtotal(){ return cartLines().reduce((s,l)=> s + l.product.price * l.qty, 0); }

function updateCartCount(){
  document.querySelectorAll(".cart-count").forEach(el => {
    const n = cartCount();
    el.textContent = n;
    el.style.display = n > 0 ? "flex" : "none";
  });
}

/* ---------------- Toast ---------------- */
function showToast(msg){
  let t = document.querySelector(".toast");
  if(!t){
    t = document.createElement("div");
    t.className = "toast";
    t.setAttribute("role", "status");
    document.body.appendChild(t);
  }
  t.textContent = msg;
  requestAnimationFrame(()=> t.classList.add("show"));
  clearTimeout(t._timer);
  t._timer = setTimeout(()=> t.classList.remove("show"), 2400);
}

/* ---------------- Header / nav wiring ---------------- */
function initChrome(){
  updateCartCount();

  const burger = document.querySelector(".burger");
  const mobileNav = document.querySelector(".mobile-nav");
  if(burger && mobileNav){
    mobileNav.id = 'mobile-navigation';
    burger.setAttribute('aria-controls', mobileNav.id);
    burger.setAttribute('aria-expanded', 'false');
    burger.addEventListener("click", ()=>{
      mobileNav.classList.toggle("open");
      burger.setAttribute('aria-expanded', String(mobileNav.classList.contains('open')));
      document.body.style.overflow = mobileNav.classList.contains("open") ? "hidden" : "";
    });
    mobileNav.querySelectorAll("a").forEach(a => a.addEventListener("click", ()=>{
      mobileNav.classList.remove("open");
      burger.setAttribute('aria-expanded', 'false');
      document.body.style.overflow = "";
    }));
  }

  document.querySelectorAll("form.search-form").forEach(form=>{
    form.addEventListener("submit", e=>{
      e.preventDefault();
      const q = form.querySelector("input").value.trim();
      window.location.href = "shop.html" + (q ? ("?search=" + encodeURIComponent(q)) : "");
    });
  });
}

/* ---------------- Star rating markup ---------------- */
function starsMarkup(rating){
  const full = Math.round(rating || 0);
  let out = "";
  for(let i=0;i<5;i++){
    out += `<svg viewBox="0 0 20 20" fill="${i<full ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="1"><path d="M10 1l2.6 5.9 6.4.6-4.8 4.3 1.4 6.2L10 14.9 4.4 18l1.4-6.2L1 7.5l6.4-.6L10 1z"/></svg>`;
  }
  return out;
}

/* ---------------- Product card ---------------- */
function productCard(p){
  const available = p.sizes.filter(size => (p.stock?.[size] || 0) > 0);
  const badge = !available.length ? `<span class="product-badge">Sold out</span>` : p.newArrival ? `<span class="product-badge">New</span>`
    : (p.compareAt ? `<span class="product-badge sale">Sale</span>` : "");
  const price = p.compareAt
    ? `<span class="was">${INR(p.compareAt)}</span>${INR(p.price)}`
    : INR(p.price);
  return `
  <div class="product-card"><button class="save-item" data-save="${p.id}" aria-label="Save ${p.name}" aria-pressed="false">♡</button>
    <a href="product.html?id=${p.id}" aria-label="${p.name}">
      <div class="product-media">
        ${badge}
        ${garmentSVG(Object.assign({id:p.id,alt:p.name}, p.art))}
        ${p.art?.image ? '' : '<span class="image-note">Illustration · photo coming soon</span>'}
        <div class="product-quickadd">View details &amp; sizes</div>
      </div>
    </a>
    <div class="product-info">
      <div class="product-cat">${p.fabric} · ${categoryLabel(p.category)}</div>
      <h3 class="product-name"><a href="product.html?id=${p.id}">${p.name}</a></h3>
      <div class="product-price">${price}</div>
      <p class="available-sizes">${available.length ? 'Available: '+available.join(' · ') : 'Currently out of stock'}</p>
      <button class="quick-shop" data-quick="${p.id}" ${available.length?'':'disabled'}>${available.length?'Choose size':'Sold out'} <span aria-hidden="true">+</span></button>
      ${p.reviewCount > 0 ? `<div class="product-stars">${starsMarkup(p.rating)}</div>` : ""}
    </div>
  </div>`;
}

function renderProductGrid(target, list){
  const el = document.querySelector(target);
  if(!el) return;
  el.dataset.count=String(list.length);
  if(list.length === 0){
    el.innerHTML = `<div class="empty-state collection-empty" style="grid-column:1/-1"><span class="eyebrow">LET'S FIND YOUR LOOK</span><h3>${PRODUCTS.length?'No matching styles just yet':'The collection is being refreshed'}</h3><p>${PRODUCTS.length?'Try another size, a wider price range or a different search.':'Please check back shortly, or ask our team for help.'}</p><div class="empty-actions">${document.getElementById('clear-filters')?'<button type="button" class="btn" data-reset-filters>Clear filters</button>':''}<a class="link-u" href="${PRODUCTS.length?'shop.html':'support.html'}">${PRODUCTS.length?'Browse all styles':'Contact customer care'} →</a></div></div>`;
    el.querySelector('[data-reset-filters]')?.addEventListener('click',()=>document.getElementById('clear-filters').click());
    return;
  }
  el.innerHTML = list.map(productCard).join("");
  document.dispatchEvent(new Event("demor:grid-updated"));
}

/* ---------------- Shop page (filters + sort + search) ---------------- */
function initShopPage(fixedCategory){
  const grid = document.getElementById("product-grid");
  if(!grid) return;

  const params = new URLSearchParams(window.location.search);
  const state = {
    category: fixedCategory ? [fixedCategory] : (params.getAll("category").length ? params.getAll("category") : []),
    sizes: [],
    min: "",
    max: "",
    search: params.get("search") || "",
    tag: params.get("tag") || "",
    sort: "featured"
  };

  const searchInput = document.getElementById("shop-search");
  if(searchInput) searchInput.value = state.search;
  searchInput?.setAttribute('aria-label','Search this collection');
  document.getElementById('price-min')?.setAttribute('aria-label','Minimum price in rupees');
  document.getElementById('price-max')?.setAttribute('aria-label','Maximum price in rupees');
  document.getElementById('sort-select')?.setAttribute('aria-label','Sort products');
  document.getElementById('result-count')?.setAttribute('aria-live','polite');
  const filters = document.querySelector('.filters');
  if(filters){
    filters.id='collection-filters';
    const toggle=document.createElement('button');
    toggle.type='button'; toggle.className='filter-toggle'; toggle.textContent='Filter by size, category & price';
    toggle.setAttribute('aria-expanded','false'); toggle.setAttribute('aria-controls',filters.id);
    filters.before(toggle);
    toggle.onclick=()=>{const expanded=toggle.getAttribute('aria-expanded')!=='true';toggle.setAttribute('aria-expanded',String(expanded));filters.classList.toggle('filters-open',expanded)};
  }

  function apply(){
    let list = PRODUCTS.slice();

    if(state.category.length) list = list.filter(p => state.category.includes(p.category));
    if(state.sizes.length) list = list.filter(p => p.sizes.some(s => state.sizes.includes(s)));
    if(state.min) list = list.filter(p => p.price >= Number(state.min));
    if(state.max) list = list.filter(p => p.price <= Number(state.max));
    if(state.tag === "new") list = list.filter(p => p.newArrival);
    if(state.tag === "best") list = list.filter(p => p.bestSeller);
    if(state.search.trim()){
      const words = state.search.toLowerCase().trim().split(/\s+/);
      list = list.filter(p => words.every(word => [p.name,p.fabric,p.color,p.category.replace(/-/g,' ')].join(' ').toLowerCase().includes(word)));
    }

    if(state.sort === "price-asc") list.sort((a,b)=>a.price-b.price);
    else if(state.sort === "price-desc") list.sort((a,b)=>b.price-a.price);
    else if(state.sort === "name") list.sort((a,b)=>a.name.localeCompare(b.name));

    renderProductGrid("#product-grid", list);
    const countEl = document.getElementById("result-count");
    if(countEl) countEl.textContent = `${list.length} ${list.length === 1 ? "product" : "products"}`;
  }

  document.querySelectorAll(".js-cat-filter").forEach(cb=>{
    cb.checked = state.category.includes(cb.value);
    cb.addEventListener("change", ()=>{
      state.category = Array.from(document.querySelectorAll(".js-cat-filter:checked")).map(c=>c.value);
      apply();
    });
  });
  document.querySelectorAll(".js-size-filter").forEach(cb=>{
    cb.addEventListener("change", ()=>{
      state.sizes = Array.from(document.querySelectorAll(".js-size-filter:checked")).map(c=>c.value);
      apply();
    });
  });
  const minInput = document.getElementById("price-min");
  const maxInput = document.getElementById("price-max");
  if(minInput) minInput.addEventListener("input", ()=>{ state.min = minInput.value; apply(); });
  if(maxInput) maxInput.addEventListener("input", ()=>{ state.max = maxInput.value; apply(); });

  const sortSelect = document.getElementById("sort-select");
  if(sortSelect) sortSelect.addEventListener("change", ()=>{ state.sort = sortSelect.value; apply(); });

  if(searchInput) searchInput.addEventListener("input", ()=>{ state.search = searchInput.value; apply(); });

  const clearBtn = document.getElementById("clear-filters");
  if(clearBtn) clearBtn.addEventListener("click", ()=>{
    state.category = fixedCategory ? [fixedCategory] : [];
    state.sizes = []; state.min=""; state.max=""; state.search=""; state.tag="";
    document.querySelectorAll(".js-cat-filter, .js-size-filter").forEach(cb=> cb.checked = fixedCategory ? cb.value===fixedCategory : false);
    if(minInput) minInput.value=""; if(maxInput) maxInput.value=""; if(searchInput) searchInput.value="";
    apply();
  });

  apply();
}

/* ---------------- Home page rails ---------------- */
function initHomeRails(){
  const featured=PRODUCTS.slice().sort((a,b)=>Number(b.sizes.length>0)-Number(a.sizes.length>0)).slice(0,4);
  renderProductGrid('#featured-grid',featured);
  const used=new Set(featured.map(p=>p.id));
  for(const [selector,key] of [['#new-arrivals-grid','newArrival'],['#best-sellers-grid','bestSeller']]){
    const list=PRODUCTS.filter(p=>p[key]&&!used.has(p.id)).slice(0,4);
    const grid=document.querySelector(selector);
    if(grid){grid.closest('section').hidden=!list.length;if(list.length)renderProductGrid(selector,list);}
    list.forEach(p=>used.add(p.id));
  }
  document.querySelectorAll('[data-edit]').forEach(button=>{
    button.hidden=button.dataset.edit!=='all'&&!PRODUCTS.some(p=>p.category===button.dataset.edit);
  });
}

/* ---------------- Product detail page ---------------- */
function initProductPage(){
  const root = document.getElementById("pd-root");
  if(!root) return;
  const id = new URLSearchParams(window.location.search).get("id");
  const p = PRODUCTS.find(p => p.id === id);
  if(!p){
    root.innerHTML='<div class="product-unavailable"><span class="eyebrow">LET’S FIND ANOTHER FAVOURITE</span><h1>This style is unavailable</h1><p>It may have sold out or moved out of the collection. Explore the styles currently available.</p><a href="shop.html" class="btn">Browse the collection →</a><a href="support.html" class="link-u">Ask customer care</a></div>';
    document.querySelector('#related-grid')?.closest('section')?.setAttribute('hidden','');
    return;
  }

  document.title = `${p.name} — DEMOR`;
  let selectedSize = '';
  let qty = 1;

  function render(){
    const focus=document.activeElement;
    const focusId=root.contains(focus)?focus.id:'';
    const focusSize=root.contains(focus)?focus.dataset.size:'';
    const maxQty=selectedSize?Math.max(0,Math.min(20,(p.stock?.[selectedSize]||0)-(getCart().find(i=>i.id===p.id&&i.size===selectedSize)?.qty||0))):0;
    qty=Math.min(qty,Math.max(1,maxQty));
    root.innerHTML = `
    <div class="pd-layout">
      <div class="pd-gallery">
        <div class="pd-gallery-main">${garmentSVG(Object.assign({id:p.id+"-main",alt:p.name,priority:true}, p.art))}</div>
        ${p.art?.image?'':'<p class="photo-disclaimer">Illustration only. Ask our team for actual product photos before ordering.</p>'}
        <div class="pd-thumbs" hidden>
          ${[0,1,2].map(i=>`<button class="pd-thumb ${i===0?'active':''}" data-i="${i}">${garmentSVG(Object.assign({id:p.id+"-t"+i}, p.art))}</button>`).join("")}
        </div>
      </div>
      <div class="pd-info">
        <div class="pd-cat">${categoryLabel(p.category)} · ${p.fabric}</div>
        <h1 class="pd-title">${p.name}</h1>
        <div class="pd-price">${p.compareAt ? `<span class="was">${INR(p.compareAt)}</span>` : ""}${INR(p.price)}</div>
        <div class="pd-tax">MRP inclusive of all taxes. GSTIN 27HBNPM6784E1ZY.</div>
        <p class="pd-desc">${p.description}</p>

        <div class="pd-block">
          <h4>Colour — ${p.color}</h4>
        </div>

        <div class="pd-block">
          <div class="size-label"><h4>Choose your size</h4><button type="button" class="link-button" data-fit-guide>Need help with fit?</button></div>
          <div class="size-grid" id="size-grid" role="group" aria-label="Choose your size">
            ${["S","M","L","XL","XXL"].map(s=>{
              const available = p.sizes.includes(s) && (p.stock?.[s]||0)>0;
              return `<button type="button" class="size-opt ${!available ? 'disabled' : ''} ${s===selectedSize?'active':''}" data-size="${s}" aria-pressed="${s===selectedSize}" aria-label="Size ${s}${available?'':' — sold out'}" ${!available?'disabled':''}>${s}</button>`;
            }).join("")}
          </div>
          <p class="selection-hint" aria-live="polite">${!p.sizes.length?'This style is currently sold out.':selectedSize?maxQty?'Size '+selectedSize+' selected':'All available pieces in this size are already in your bag.':'Select a size to add this style to your bag.'}</p>
        </div>

        <div class="pd-block">
          <h4>Quantity</h4>
          <div class="qty-stepper">
            <button type="button" id="qty-minus" aria-label="Decrease quantity" ${qty<=1?'disabled':''}>−</button>
            <span id="qty-val" aria-live="polite">${qty}</span>
            <button type="button" id="qty-plus" aria-label="Increase quantity" ${!selectedSize||qty>=maxQty?'disabled':''}>+</button>
          </div>
        </div>

        <div class="pd-actions">
          <button class="btn btn--block" id="add-to-cart-btn" ${!selectedSize||!maxQty?'disabled':''} style="flex:1">${!p.sizes.length?'Sold out':!selectedSize?'Select a size':!maxQty?'View your bag':'Add to bag — '+INR(p.price*qty)}</button>
        </div>
        <a href="cart.html" class="link-u" id="view-bag-link" style="display:none">View bag</a>

        <hr class="hr" style="margin:26px 0">
        <div class="pd-meta">
          GST invoice included &middot; <a href="shipping-returns.html" class="link-u">See exchange policy</a><br>Free standard delivery on serviceable Indian PIN codes.
        </div>

        <div class="accordion" style="margin-top:20px">
          <div class="accordion-item">
            <button class="accordion-btn">Fabric &amp; fit <svg viewBox="0 0 20 20" stroke="currentColor" stroke-width="1.6" fill="none"><path d="M10 3v14M3 10h14"/></svg></button>
            <div class="accordion-panel"><div class="accordion-panel-in">${p.fabric}. Contact customer support for measurements before ordering; sizing may vary between styles.</div></div>
          </div>
          <div class="accordion-item">
            <button class="accordion-btn">Care instructions <svg viewBox="0 0 20 20" stroke="currentColor" stroke-width="1.6" fill="none"><path d="M10 3v14M3 10h14"/></svg></button>
            <div class="accordion-panel"><div class="accordion-panel-in"><ul style="margin:0;padding-left:18px">${p.care.map(c=>`<li>${c}</li>`).join("")}</ul></div></div>
          </div>
          <div class="accordion-item">
            <button class="accordion-btn">Shipping &amp; returns <svg viewBox="0 0 20 20" stroke="currentColor" stroke-width="1.6" fill="none"><path d="M10 3v14M3 10h14"/></svg></button>
            <div class="accordion-panel"><div class="accordion-panel-in">See our <a class="link-u" href="shipping-returns.html">Shipping &amp; Returns</a> page for timelines and the return process.</div></div>
          </div>
        </div>
      </div>
    </div>`;

    root.querySelectorAll(".size-opt:not(.disabled)").forEach(btn=>{
      btn.addEventListener("click", ()=>{ selectedSize = btn.dataset.size; qty=1; render(); });
    });
    const minus = document.getElementById("qty-minus");
    const plus = document.getElementById("qty-plus");
    if(minus) minus.addEventListener("click", ()=>{ if(qty>1){ qty--; render(); } });
    if(plus) plus.addEventListener("click", ()=>{ if(qty<maxQty){qty++; render();} });

    document.getElementById("add-to-cart-btn").addEventListener("click", ()=>{
      if(!addToCart(p.id, selectedSize, qty))return;
      document.getElementById("view-bag-link").style.display = "inline-block";
      render();
      document.getElementById("view-bag-link").style.display = "inline-block";
    });

    root.querySelectorAll(".accordion-btn").forEach(btn=>{
      btn.addEventListener("click", ()=>{
        const item = btn.closest(".accordion-item");
        const panel = item.querySelector(".accordion-panel");
        const isOpen = item.classList.contains("open");
        root.querySelectorAll(".accordion-item").forEach(i=>{ i.classList.remove("open"); i.querySelector('.accordion-btn').setAttribute('aria-expanded','false'); i.querySelector(".accordion-panel").style.maxHeight = null; });
        if(!isOpen){ item.classList.add("open"); panel.style.maxHeight = panel.scrollHeight + "px"; }
        btn.setAttribute('aria-expanded',String(!isOpen));
      });
      btn.setAttribute('aria-expanded','false');
    });
    if(focusSize)root.querySelector('[data-size="'+focusSize+'"]')?.focus({preventScroll:true});
    else if(focusId)document.getElementById(focusId)?.focus({preventScroll:true});
  }
  render();

  const related=PRODUCTS.filter(x => x.id !== p.id && x.category === p.category).slice(0,4);
  const relatedGrid=document.getElementById('related-grid');
  if(relatedGrid){relatedGrid.closest('section').hidden=!related.length;if(related.length)renderProductGrid('#related-grid',related);}
}

/* ---------------- Cart page ---------------- */
function renderCartPage(){
  const root = document.getElementById("cart-root");
  if(!root) return;
  const lines = cartLines();

  if(lines.length === 0){
    root.innerHTML = `
    <div class="cart-empty">
      <h2>Your bag is empty</h2>
      <p class="lede" style="margin:14px auto 28px">Browse the collection and add a piece you like.</p>
      <a href="shop.html" class="btn">Continue Shopping</a>
    </div>`;
    return;
  }

  root.innerHTML = `
  <div class="cart-layout" style="display:grid;grid-template-columns:1.7fr 1fr;gap:48px;align-items:flex-start">
    <table class="cart-table">
      <thead><tr><th>Product</th><th>Quantity</th><th>Subtotal</th></tr></thead>
      <tbody>
        ${lines.map(l => `
        <tr>
          <td>
            <div class="cart-item">
              <div class="cart-item-img">${garmentSVG(Object.assign({id:l.id+l.size}, l.product.art))}</div>
              <div>
                <h4>${l.product.name}</h4>
                <div class="meta">Size: ${l.size}</div>
                <div class="meta">${INR(l.product.price)} each</div>${l.unavailable?'<div role="status">Quantity unavailable. Reduce quantity or remove this item.</div>':''}
                <button type="button" class="remove-link js-remove" data-id="${l.id}" data-size="${l.size}" aria-label="Remove ${l.product.name}, size ${l.size}">Remove</button>
              </div>
            </div>
          </td>
          <td>
            <div class="qty-stepper">
              <button type="button" class="js-qty-minus" data-id="${l.id}" data-size="${l.size}" aria-label="Decrease quantity of ${l.product.name}, size ${l.size}" ${l.qty<=1?'disabled':''}>−</button>
              <span>${l.qty}</span>
              <button type="button" class="js-qty-plus" data-id="${l.id}" data-size="${l.size}" aria-label="Increase quantity of ${l.product.name}, size ${l.size}" ${l.qty>=Math.min(20,l.product.stock?.[l.size]||0)?'disabled':''}>+</button>
            </div>
          </td>
          <td>${INR(l.product.price * l.qty)}</td>
        </tr>`).join("")}
      </tbody>
    </table>
    <div class="cart-summary">
      <h3 style="margin-bottom:18px">Order Summary</h3>
      <div class="row"><span>Subtotal</span><span>${INR(cartSubtotal())}</span></div>
      <div class="row"><span>Shipping</span><span>FREE standard delivery</span></div>
      <div class="row total"><span>Item total</span><span>${INR(cartSubtotal())}</span></div>
      <p class="shipping-note">Taxes included. Complimentary standard delivery where courier service is available.</p>
      ${lines.some(l=>l.unavailable)?'<p role="status" class="stock-warning">Update unavailable items before checkout.</p><button class="btn btn--block" disabled>Update your bag to continue</button>':'<a href="checkout.html" class="btn btn--block" style="margin-top:20px">Continue to secure checkout →</a>'}
      <a href="shop.html" class="link-u" style="display:block;text-align:center;margin-top:16px">Continue Shopping</a>
    </div>
  </div>`;

  root.querySelectorAll(".js-remove").forEach(a=> a.addEventListener("click", ()=> removeFromCart(a.dataset.id, a.dataset.size)));
  root.querySelectorAll(".js-qty-minus").forEach(b=> b.addEventListener("click", ()=>{
    const cur = getCart().find(i=>i.id===b.dataset.id && i.size===b.dataset.size);
    if(cur) updateCartQty(b.dataset.id, b.dataset.size, cur.qty - 1);
  }));
  root.querySelectorAll(".js-qty-plus").forEach(b=> b.addEventListener("click", ()=>{
    const cur = getCart().find(i=>i.id===b.dataset.id && i.size===b.dataset.size);
    if(cur) updateCartQty(b.dataset.id, b.dataset.size, cur.qty + 1);
  }));
}

/* ---------------- Checkout page ---------------- */
function initCheckoutPage(){window.DemorCheckout?.init();}

/* ---------------- FAQ / accordion (generic) ---------------- */
function initGenericAccordion(selector){
  document.querySelectorAll(selector || ".faq-item").forEach(item=>{
    const btn = item.querySelector(".accordion-btn");
    const panel = item.querySelector(".accordion-panel");
    if(!btn || !panel) return;
    btn.addEventListener("click", ()=>{
      const isOpen = item.classList.contains("open");
      item.classList.toggle("open", !isOpen);
      panel.style.maxHeight = !isOpen ? panel.scrollHeight + "px" : null;
    });
  });
}

document.addEventListener("DOMContentLoaded", ()=>{
  importAndroidBagOnce();
  initChrome();
  initHomeRails();
  initProductPage();
  renderCartPage();
  initCheckoutPage();
  initGenericAccordion(".faq-item");
});
