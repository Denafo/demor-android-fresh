/* Dedicated password reset for Netlify Identity's #recovery_token email links.
   Only the same-origin GoTrue endpoint receives the one-use token; it is never logged or stored. */
(() => {
  'use strict';
  const form = document.getElementById('reset-form');
  const status = document.getElementById('reset-status');
  const submit = document.getElementById('reset-submit');
  if (!form || !status || !submit) return;
  const token = new URLSearchParams(window.location.hash.slice(1)).get('recovery_token');
  // Remove the secret token from browser history/address bar as soon as it is read.
  window.history.replaceState(null, '', window.location.pathname + window.location.search);
  const notice = (text, state = '') => {
    status.textContent = text;
    if (state) status.dataset.state = state;
    else delete status.dataset.state;
  };
  if (!token || token.length > 4096) {
    notice('This password reset link is missing or invalid. Request a new link from the login page.', 'error');
    return;
  }
  form.hidden = false;
  notice('Enter a new password to continue.');
  for (const button of document.querySelectorAll('[data-toggle]')) {
    button.addEventListener('click', () => {
      const field = document.getElementById(button.dataset.toggle);
      if (!field) return;
      field.type = field.type === 'password' ? 'text' : 'password';
      button.textContent = field.type === 'password' ? 'Show' : 'Hide';
      button.setAttribute('aria-label', field.type === 'password' ? 'Show password' : 'Hide password');
    });
  }
  async function jsonOrThrow(response) {
    let body;
    try { body = await response.json(); } catch { body = {}; }
    if (!response.ok) throw new Error('Password reset could not be completed. The link may have expired or already been used. Request a new reset link.');
    return body;
  }
  form.addEventListener('submit', async event => {
    event.preventDefault();
    if (submit.disabled) return;
    const password = document.getElementById('password').value;
    const confirm = document.getElementById('confirm').value;
    if (password.length < 12 || password.length > 128) {
      notice('Please choose a password between 12 and 128 characters.', 'error');
      return;
    }
    if (password !== confirm) {
      notice('The passwords do not match. Please try again.', 'error');
      return;
    }
    submit.disabled = true;
    notice('Verifying reset link and updating your password…');
    try {
      // The recovery token is exchanged for a temporary user access token.
      const verify = await fetch('/.netlify/identity/verify', {
        method: 'POST', credentials: 'same-origin', cache: 'no-store',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ type: 'recovery', token })
      });
      const session = await jsonOrThrow(verify);
      if (!session.access_token) throw new Error('Reset link verification failed. Please request a new reset link.');
      try {
        const update = await fetch('/.netlify/identity/user', {
          method: 'PUT', credentials: 'same-origin', cache: 'no-store',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + session.access_token
          },
          body: JSON.stringify({ password })
        });
        await jsonOrThrow(update);
        document.getElementById('password').value = '';
        document.getElementById('confirm').value = '';
        form.hidden = true;
        notice('Password changed successfully. You can now log in with your new password.', 'success');
      } finally {
        // Best-effort revoke of the temporary recovery session.
        try {
          await fetch('/.netlify/identity/logout', {
            method: 'POST', cache: 'no-store',
            headers: {'Authorization': 'Bearer ' + session.access_token}
          });
        } catch { /* Password change may already have succeeded; do not mask it. */ }
      }
    } catch (error) {
      notice(error.message || 'Something went wrong. Please request another reset link.', 'error');
    } finally {
      submit.disabled = false;
    }
  });
})();
