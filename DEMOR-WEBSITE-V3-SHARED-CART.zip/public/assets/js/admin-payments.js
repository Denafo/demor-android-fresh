function extendOrderCard(card,r){
 const online=r.online||{};card.append(el('h3','Online payment'),el('p',online.payment||'No online payment'));
 if(online.payment_mode==='test')card.append(el('p','TEST ORDER — no real money received. Do not dispatch.'));
 if(online.review_required)card.append(el('p','ACTION REQUIRED: payment received on a cancelled order. Review and refund through Razorpay.'));
 if(['creating','unknown'].includes(online.payment_state)){
  const label=el('label','Recover interrupted setup: matching Razorpay Order ID'),input=el('input');input.placeholder='order_…';label.append(input);const recover=el('button','Verify & link Razorpay order');card.append(label,recover);recover.onclick=async()=>{recover.disabled=true;try{await api('/api/admin/payment-recover',{id:r.id,provider_order_id:input.value.trim()});await load()}catch(e){$('#message').textContent=e.message}finally{recover.disabled=false}};
 }
 const panel=el('details'),heading=el('summary','Delivery details shown to customer');panel.append(heading);const fields={};
 for(const [key,title] of [['carrier','Courier name'],['tracking','Tracking number / AWB'],['url','HTTPS courier tracking link'],['estimate','Estimated delivery date or range'],['message','Customer delivery update']]){const label=el('label',title),input=el(key==='message'?'textarea':'input');input.value=r.delivery?.[key]||'';fields[key]=input;label.append(input);panel.append(label)}
 if(r.delivery?.shiprocket)panel.append(el('p','Courier booking metadata is preserved. Avoid changing the AWB manually; use the Shiprocket control below.'));const save=el('button','Save delivery details');panel.append(save);card.append(panel);shiprocketOrderPanel(card,r);save.onclick=async()=>{save.disabled=true;try{await api('/api/admin/delivery',{id:r.id,revision:r.revision,...Object.fromEntries(Object.entries(fields).map(([k,v])=>[k,v.value]))});await load();$('#message').textContent='Delivery details saved for the customer.'}catch(e){$('#message').textContent=e.message}finally{save.disabled=false}};
}

// Shiprocket actions are owner-only. Nothing is booked until the owner explicitly confirms.
function shiprocketOrderPanel(card,r){
 const panel=el('details');panel.className='shiprocket-panel';panel.append(el('summary','Shiprocket · shipping control'));
 const data=r.delivery?.shiprocket;
 if(data){
  panel.append(el('p','State: '+data.stage+' · Shiprocket order: '+(data.order_id||'pending')+' · Shipment: '+(data.shipment_id||'pending')));
  if(data.stage==='review')panel.append(el('p','CHECK SHIPROCKET DASHBOARD before any retry. A duplicate booking or AWB charge may already exist.'));
 }
 const message=el('p');message.setAttribute('role','status');panel.append(message);
 const button=(caption,fn)=>{const b=el('button',caption);b.type='button';panel.append(b);b.onclick=async()=>{b.disabled=true;try{await fn();}catch(e){message.textContent=e.message}finally{b.disabled=false}};return b};
 button('Test Shiprocket connection',async()=>{const res=await api('/api/admin/shiprocket/check');message.textContent=res.connected?'Shiprocket API credentials are working.':'Connection unavailable.'});
 if(!data){
  panel.append(el('p','Only confirmed LIVE-paid, documented externally-paid, or verified COD orders can be sent to Shiprocket. Do not use placeholder parcel sizes.'));
  const fields={};
  for(const [key,caption,initial] of [['pickup','Exact pickup LOCATION NAME from Shiprocket',''],['pickupPin','Actual pickup PIN code',''],['weight','Packed weight in kg','0.5'],['length','Length in cm',''],['breadth','Breadth in cm',''],['height','Height in cm','']]){
   const lab=el('label',caption),inp=el('input');inp.value=initial;inp.autocomplete='off';inp.placeholder=caption;lab.append(inp);panel.append(lab);fields[key]=inp;
  }
  let couriers=[];
  button('Check courier rates (no booking)',async()=>{
   const result=await api('/api/admin/shiprocket/quote',{id:r.id,pickup:fields.pickupPin.value.trim(),weight:Number(fields.weight.value),cod:r.payment==='COD due'});
   couriers=result.couriers||[];
   message.textContent=couriers.length?couriers.map(c=>`${c.id} · ${c.name} · estimated ₹${Number.isFinite(c.rate)?c.rate:'check panel'}`).join(' | '):'No couriers returned for this route. Check coverage in Shiprocket.';
  });
  button('Create Shiprocket draft order',async()=>{
   if(!confirm('Create ONE draft order in Shiprocket? Check customer address, payment and packed dimensions first. This action is not a courier pickup.'))return;
   const body={id:r.id,pickup:fields.pickup.value.trim(),weight:Number(fields.weight.value),length:Number(fields.length.value),breadth:Number(fields.breadth.value),height:Number(fields.height.value)};
   const result=await api('/api/admin/shiprocket/create',body);message.textContent='Shiprocket draft created: '+result.shiprocket.order_id+'. Refresh the admin page to continue.';
  });
 }else if(data.stage==='draft'){
  panel.append(el('p','Choose courier ID from a fresh rate check before AWB assignment. AWB may incur a shipping-wallet charge. Pickup must be scheduled separately.'));
  const lab=el('label','Courier ID from Shiprocket quote'),input=el('input');input.type='number';input.min='1';lab.append(input);panel.append(lab);
  button('Assign AWB (may charge wallet)',async()=>{
   if(!confirm('Confirm courier and shipment. Assign an AWB now? This may charge your Shiprocket wallet.'))return;
   const result=await api('/api/admin/shiprocket/awb',{id:r.id,courier_id:Number(input.value)});
   message.textContent='AWB assigned: '+result.awb+'. Schedule pickup in Shiprocket panel, then refresh.';
  });
 }else if(data.stage==='awb_assigned'){
  panel.append(el('p','AWB '+(r.delivery?.tracking||'')+' saved. Schedule pickup from Shiprocket, then verify delivery status before marking Shipped or Delivered.'));
  button('Refresh courier tracking',async()=>{const result=await api('/api/admin/shiprocket/tracking',{id:r.id});message.textContent='Latest courier update: '+result.status+'. Refresh admin panel to see stored customer message.'});
 }
 const link=el('a','Open Shiprocket dashboard ↗');link.href='https://app.shiprocket.in/';link.target='_blank';link.rel='noopener noreferrer';panel.append(link);card.append(panel);
}
