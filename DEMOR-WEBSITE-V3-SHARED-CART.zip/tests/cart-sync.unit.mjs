import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';

// Isolated real handler test: only payment/courier dependencies are stubbed.
// All auth, cart validation, and CAS logic below runs from server/handler.mjs.
let source=await readFile(new URL('../server/handler.mjs',import.meta.url),'utf8');
source=source.replace(/^import .*\n/gm,'');
source=`const makePayments=()=>({});const makeShiprocket=()=>({});\n`+
`class PaymentError extends Error{};class ShiprocketError extends Error{};\n`+
`const hash=x=>requireHash(x),random=()=>'',equal=(a,b)=>a===b,passwordMatches=()=>false,trackingCode=()=>'';\n`+
source.replace('export function makeHandler','function makeHandler')+`\nreturn makeHandler;`;
const makeHandler=new Function('requireHash',source)(x=>createHash('sha256').update(x).digest('hex'));
const carts=new Map(),stock=new Map([['dm-001',{S:4,M:2}],['new-product',{XL:5}]]);
const env={DATABASE_URL:'fake',DEMOR_ORIGIN:'https://demor.in',DEMOR_OWNER_HASH:'fake',DEMOR_SESSION_SECRET:'a'.repeat(40)};
const a='a'.repeat(44),b='b'.repeat(44);
const identityFetch=async(_url,opts)=>{
  const token=opts.headers.Authorization;
  if(token===`Bearer ${a}`)return Response.json({id:'user-a12345678',email:'a@example.com'});
  if(token===`Bearer ${b}`)return Response.json({id:'user-b12345678',email:'b@example.com'});
  return Response.json({msg:'unauthorized'},{status:401});
};
async function query(sql,params){
  if(sql.includes('INSERT INTO demor_limits'))return [{count:1}];
  if(sql.includes('SELECT id,stock FROM demor_products'))return [...stock].map(([id,s])=>({id,stock:s}));
  if(sql.includes('SELECT items,revision FROM demor_customer_carts')){
    const saved=carts.get(params[0]);return saved?[{...saved}]:[];
  }
  if(sql.includes('INSERT INTO demor_customer_carts')){
    const [id,serialized,updated,expected]=params;const old=carts.get(id);
    if((old?.revision??0)!==expected)return [];
    const saved={items:JSON.parse(serialized),revision:(old?.revision??0)+1,updated};carts.set(id,saved);return [saved];
  }
  throw new Error('Unexpected query '+sql.slice(0,80));
}
const handler=makeHandler({query,env,catalog:[],identityFetch});
async function send(token,path,body,overrides={}){
  const response=await handler(new Request(`https://demor.in${path}`,{
    method:body===undefined?'GET':'POST',
    headers:{...(token?{Authorization:`Bearer ${token}`} : {}), Origin:overrides.origin??'https://demor.in','Content-Type':'application/json'},
    body:body===undefined?undefined:JSON.stringify(body)
  }),{ip:'203.0.113.20'});
  return {status:response.status,data:await response.json()};
}
test('guest cannot read or write account cart',async()=>{
  assert.equal((await send(null,'/api/my-cart')).status,401);
  assert.equal((await send(null,'/api/my-cart',{items:[],revision:0})).status,401);
});
test('a new account has an empty bag and can save live products',async()=>{
  assert.deepEqual((await send(a,'/api/my-cart')).data,{items:[],revision:0});
  const v=await send(a,'/api/my-cart',{items:[{id:'dm-001',size:'S',qty:2}],revision:0});
  assert.equal(v.status,200);assert.equal(v.data.revision,1);
});
test('same account reads cart from another device; other customer isolated',async()=>{
  const result=await send(a,'/api/my-cart');
  assert.deepEqual(result.data.items,[{id:'dm-001',size:'S',qty:2}]);
  assert.deepEqual((await send(b,'/api/my-cart')).data.items,[]);
});
test('stale device, invalid/duplicate stock and wrong origin rejected',async()=>{
  assert.equal((await send(a,'/api/my-cart',{items:[],revision:0})).status,409);
  assert.equal((await send(a,'/api/my-cart',{items:[{id:'dm-001',size:'S',qty:9}],revision:1})).status,409);
  assert.equal((await send(a,'/api/my-cart',{items:[{id:'dm-001',size:'S',qty:1},{id:'dm-001',size:'S',qty:1}],revision:1})).status,400);
  assert.equal((await send(a,'/api/my-cart',{items:[{id:'removed',size:'S',qty:1}],revision:1})).status,409);
  assert.equal((await send(a,'/api/my-cart',{items:[],revision:1},{origin:'https://evil.example'})).status,403);
});
test('new admin product syncs and delete clears account bag',async()=>{
  const saved=await send(a,'/api/my-cart',{items:[{id:'new-product',size:'XL',qty:1}],revision:1});
  assert.equal(saved.status,200);assert.equal(saved.data.revision,2);
  assert.equal((await send(a,'/api/my-cart',{items:[],revision:2})).status,200);
  assert.deepEqual((await send(a,'/api/my-cart')).data.items,[]);
});
