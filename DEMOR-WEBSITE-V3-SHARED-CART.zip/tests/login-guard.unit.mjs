import {test} from 'node:test';
import assert from 'node:assert/strict';
import {makeHandler} from '../server/handler.mjs';
import catalog from '../server/catalog.json' with {type:'json'};

const origin='https://demor.in';
const env={DATABASE_URL:'mock',DEMOR_ORIGIN:origin,DEMOR_OWNER_HASH:'valid_mock_owner_hash',DEMOR_SESSION_SECRET:'z'.repeat(40),RAZORPAY_MODE:'test'};
const validJwtA='a'.repeat(48); const validJwtB='b'.repeat(48);
const users={ [validJwtA]:{id:'user-aaa11111',email:'alpha@example.com'},[validJwtB]:{id:'user-bbb22222',email:'beta@example.com'} };
const product={id:'sample-blazer',details:{id:'sample-blazer',name:'Test Blazer',category:'blazers',price:3999,sizes:['M'],stock:{M:3}}};
function makeStore(){
 const orders=new Map();const keyed=new Map();
 const query=async (sql,params=[])=>{
  if(sql.includes('INSERT INTO demor_limits'))return [{count:1}];
  if(sql.includes('SELECT id,details FROM demor_products'))return [product];
  if(sql.includes('INSERT INTO demor_orders')){
   const [id,tokenHash,requestHash,payloadHash,created,customerJSON,itemsJSON,total]=params;
   if(keyed.has(requestHash))return [];
   const o={id,token_hash:tokenHash,request_hash:requestHash,payload_hash:payloadHash,created,customer:JSON.parse(customerJSON),items:JSON.parse(itemsJSON),total,status:'New',payment:'Pending',delivery:{}};
   keyed.set(requestHash,id);orders.set(id,o);return [{id,payload_hash:payloadHash,token_hash:tokenHash}];
  }
  if(sql.includes('SELECT id,payload_hash,token_hash FROM demor_orders')){const o=orders.get(keyed.get(params[0]));return o?[o]:[]}
  if(sql.includes('SELECT * FROM demor_orders WHERE id=$1'))return orders.has(params[0])?[orders.get(params[0])]:[];
  if(sql.includes("customer->>'account_id'=$1"))return [...orders.values()].filter(o=>o.customer.account_id===params[0]);
  if(sql.includes('SELECT * FROM demor_payments'))return [];
  throw new Error('Unmocked SQL '+sql.slice(0,100));
 };
 const identityFetch=async(_url,{headers})=>{
  const user=users[headers.Authorization?.replace('Bearer ','')];
  return new Response(JSON.stringify(user||{error:'invalid'}),{status:user?200:401,headers:{'Content-Type':'application/json'}});
 };
 return {orders,handler:makeHandler({query,env,catalog,identityFetch})};
}
async function request(store,path,{user,body,originHeader=origin}={}){
 const headers={origin:originHeader,'Content-Type':'application/json'};
 if(user)headers.authorization='Bearer '+user;
 const req=new Request(origin+path,{method:body?'POST':'GET',headers,body:body?JSON.stringify(body):undefined});
 const response=await store.handler(req,{ip:'192.0.2.12'});
 return {status:response.status,body:await response.json()};
}
const order=()=>({requestKey:'valid-request-key-123456789012345',online:false,customer:{name:'Customer',phone:'9999999999',address:'1 Test Lane',city:'Pune',state:'MH',pincode:'411002',email:'attacker@example.com',account_id:'user-bbb22222'},items:[{id:'sample-blazer',size:'M',qty:1,expectedPrice:3999}]});

test('customer login is enforced by backend, including spoofed request bodies',async()=>{
 const store=makeStore();
 assert.equal((await request(store,'/api/orders',{body:order()})).status,401);
 assert.equal((await request(store,'/api/orders',{user:'x'.repeat(48),body:order()})).status,401);
 assert.equal((await request(store,'/api/my-orders')).status,401);
 assert.equal(store.orders.size,0);
 const created=await request(store,'/api/orders',{user:validJwtA,body:order()});
 assert.equal(created.status,201,JSON.stringify(created));
 const saved=store.orders.get(created.body.id);
 assert.equal(saved.customer.email,'alpha@example.com');
 assert.equal(saved.customer.account_id,'user-aaa11111');
 assert.equal(saved.total,3999);
 const mine=await request(store,'/api/my-orders',{user:validJwtA});
 assert.equal(mine.status,200);assert.equal(mine.body.orders.length,1);
 const other=await request(store,'/api/my-orders',{user:validJwtB});
 assert.equal(other.status,200);assert.equal(other.body.orders.length,0);
 assert.equal((await request(store,'/api/track',{user:validJwtB,body:{id:created.body.id}})).status,404);
 assert.equal((await request(store,'/api/track',{user:validJwtA,body:{id:created.body.id}})).status,200);
});
test('cross-site request cannot place order even with login token',async()=>{
 const store=makeStore();const r=await request(store,'/api/orders',{user:validJwtA,body:order(),originHeader:'https://attacker.example'});
 assert.equal(r.status,403);assert.equal(store.orders.size,0);
});
