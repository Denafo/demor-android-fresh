import {test,before,after} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createHmac,randomUUID} from 'node:crypto';
import {PGlite} from '@electric-sql/pglite';
import {makeHandler} from '../server/handler.mjs';
import {passwordHash} from '../server/security.mjs';
let db,handler,env,cookie,creates=0,failure=null;const remoteOrders=new Map(),remotePayments=new Map();
const origin='https://demor.in';
const IDENTITY_TEST_TOKEN='aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa';
const identityFetch=async(_url,options)=>new Response(JSON.stringify({id:'test-user-12345678',email:'testbuyer@example.com'}),{status:options.headers.Authorization==='Bearer '+IDENTITY_TEST_TOKEN?200:401,headers:{'Content-Type':'application/json'}});

const customer={name:'Test buyer',phone:'9999999999',address:'Test address',city:'Mumbai',state:'MH',pincode:'400001'};
const gateway={orders:{
 async create(d){creates++;if(failure==='auth')throw {statusCode:401,error:{description:'DO NOT EXPOSE PROVIDER DETAILS'}};const x={...d,id:'order_Test'+creates};remoteOrders.set(x.id,x);if(failure==='timeout')throw Error('network timeout');return x},
 async fetch(id){return remoteOrders.get(id)},
 async fetchPayments(id){return {items:[...remotePayments.values()].filter(x=>x.order_id===id)}}
},payments:{async fetch(id){if(!remotePayments.has(id))throw {statusCode:400};return remotePayments.get(id)}}};
async function call(path,data,auth='',extra={}){const req=new Request(origin+path,{method:data===undefined?'GET':'POST',headers:{origin,'content-type':'application/json',cookie:auth,authorization:'Bearer '+IDENTITY_TEST_TOKEN,...extra},body:data===undefined?undefined:JSON.stringify(data)});const r=await handler(req,{ip:'203.0.113.88'});return {status:r.status,data:await r.json(),headers:r.headers}}
const sign=(id,pid)=>createHmac('sha256',env.RAZORPAY_KEY_SECRET).update(id+'|'+pid).digest('hex');
const eventSig=raw=>createHmac('sha256',env.RAZORPAY_WEBHOOK_SECRET).update(raw).digest('hex');
async function order(){const r=await call('/api/orders',{customer,items:[{id:'dm-001',size:'M',qty:1}],requestKey:randomUUID(),online:true});assert.equal(r.status,201);return r.data}
function payment(id,pid,options={}){const x={id:pid,order_id:id,amount:279900,currency:'INR',status:'captured',captured:true,amount_refunded:0,...options};remotePayments.set(pid,x);return x}
async function webhook(entity,type='payment.captured',sig){const body={event:type,payload:{payment:{entity}}},raw=JSON.stringify(body);return call('/api/razorpay-webhook',body,'',{'x-razorpay-signature':sig??eventSig(raw),origin:''})}
before(async()=>{db=new PGlite();for(const f of ['schema.sql','product-upgrade.sql','payments.sql'])await db.exec(await readFile(new URL('../server/'+f,import.meta.url),'utf8'));await db.exec(`UPDATE demor_products SET active=true,stock='{"M":100}'`);env={DATABASE_URL:'test',DEMOR_ORIGIN:origin,DEMOR_SESSION_SECRET:'local-test-session-secret'.repeat(3),DEMOR_OWNER_HASH:await passwordHash('owner-test-password'),RAZORPAY_KEY_ID:'rzp_test_Fixture',RAZORPAY_KEY_SECRET:'fixture-secret-not-a-credential',RAZORPAY_MODE:'test',RAZORPAY_WEBHOOK_SECRET:'fixture-webhook-secret'.repeat(3)};handler=makeHandler({query:async(s,p)=>(await db.query(s,p)).rows,env,gateway,identityFetch});const login=await call('/api/login',{password:'owner-test-password'});cookie=login.headers.get('set-cookie').split(';')[0]});
after(async()=>db.close());
test('server price, private ownership, origin validation and duplicate creation',async()=>{
 const o=await order(),before=creates;assert.equal((await call('/api/create-order',{...o,token:'bad'})).status,404);assert.equal((await call('/api/create-order',o,'',{origin:'https://evil.example'})).status,403);
 const results=await Promise.all([call('/api/create-order',{...o,amount:100}),call('/api/create-order',o)]);assert.ok(results.some(x=>x.status===200));assert.equal(creates-before,1);const reuse=await call('/api/create-order',o);assert.equal(reuse.data.amount,279900);assert.equal(reuse.data.currency,'INR');assert.equal(creates-before,1);assert.equal(JSON.stringify(reuse.data).includes(env.RAZORPAY_KEY_SECRET),false);
});
test('bad/missing signatures, cross-order verification and amount mismatch never mark paid',async()=>{
 const o=await order(),remote=await call('/api/create-order',o),id=remote.data.order_id,pid='pay_BadVerify';payment(id,pid);
 assert.equal((await call('/api/verify-payment',o)).status,400);
 assert.equal((await call('/api/verify-payment',{...o,razorpay_order_id:id,razorpay_payment_id:pid,razorpay_signature:'0'.repeat(64)})).status,400);
 assert.equal((await call('/api/verify-payment',{...o,razorpay_order_id:'order_Other',razorpay_payment_id:pid,razorpay_signature:sign('order_Other',pid)})).status,400);
 payment(id,pid,{amount:100});assert.equal((await call('/api/verify-payment',{...o,razorpay_order_id:id,razorpay_payment_id:pid,razorpay_signature:sign(id,pid)})).status,400);
 assert.equal((await call('/api/track',o)).data.payment_state,'ready');
});
test('authorization stays pending; captured test payment is idempotent and cannot dispatch',async()=>{
 const o=await order(),id=(await call('/api/create-order',o)).data.order_id,pid='pay_Authorize';const body={...o,razorpay_order_id:id,razorpay_payment_id:pid,razorpay_signature:sign(id,pid)};
 payment(id,pid,{status:'authorized',captured:false});assert.equal((await call('/api/verify-payment',body)).status,202);assert.equal((await call('/api/track',o)).data.payment_state,'authorized');
 payment(id,pid);assert.equal((await call('/api/verify-payment',body)).data.payment_state,'captured');assert.equal((await call('/api/verify-payment',body)).data.payment_state,'captured');
 assert.equal((await call('/api/create-order',o)).status,409);
 const track=(await call('/api/track',o)).data;assert.match(track.payment,/TEST/);assert.equal(track.can_pay,false);assert.equal('customer' in track,false);assert.equal('notes' in track,false);
 assert.equal((await call('/api/admin/update',{id:o.id,kind:'order',revision:1,status:'Shipped',payment:'Pending',notes:'test'},cookie)).status,409);
});
test('signed webhooks recover browser disconnects and delayed events do not regress refunds',async()=>{
 const o=await order(),id=(await call('/api/create-order',o)).data.order_id,p=payment(id,'pay_Webhook');
 assert.equal((await webhook(p,'payment.captured','0'.repeat(64))).status,400);assert.equal((await webhook(p)).status,200);assert.equal((await webhook(p)).status,200);
 assert.equal((await call('/api/track',o)).data.payment_state,'captured');
 payment(id,p.id,{status:'refunded',amount_refunded:279900});assert.equal((await webhook(p,'refund.processed')).status,200);assert.equal((await call('/api/track',o)).data.payment_state,'refunded');
 payment(id,p.id);assert.equal((await webhook(p)).status,200);assert.equal((await call('/api/track',o)).data.payment_state,'refunded');
});
test('cancelled order stays cancelled after late payment and is flagged for refund review',async()=>{
 const o=await order(),id=(await call('/api/create-order',o)).data.order_id;
 assert.equal((await call('/api/admin/update',{id:o.id,kind:'order',revision:1,status:'Cancelled',payment:'Pending',notes:''},cookie)).status,200);
 await webhook(payment(id,'pay_LateCapture'));const r=(await call('/api/track',o)).data;assert.equal(r.status,'Cancelled');assert.equal(r.review_required,true);assert.equal(r.can_pay,false);
});
test('uncertain create is not duplicated; owner can recover only matching provider order',async()=>{
 const o=await order();failure='timeout';assert.equal((await call('/api/create-order',o)).status,500);failure=null;const count=creates;assert.equal((await call('/api/create-order',o)).status,409);assert.equal(creates,count);
 const body={id:o.id,provider_order_id:'order_Test'+count};assert.equal((await call('/api/admin/payment-recover',body)).status,401);
 assert.equal((await call('/api/admin/payment-recover',{...body,provider_order_id:'order_Test1'},cookie)).status,400);
 assert.equal((await call('/api/admin/payment-recover',body,cookie)).status,200);assert.equal((await call('/api/create-order',o)).data.order_id,body.provider_order_id);assert.equal(creates,count);
});
test('provider authentication error is sanitized and can be retried after fixing keys',async()=>{
 const o=await order();failure='auth';const result=await call('/api/create-order',o);failure=null;assert.equal(result.status,401);assert.equal(JSON.stringify(result.data).includes('DO NOT EXPOSE'),false);assert.equal((await call('/api/create-order',o)).status,200);
});
test('minimum amount, customer delivery privacy, safe links and refreshed payment status',async()=>{
 const o=await order();await db.query('UPDATE demor_orders SET total=0 WHERE id=$1',[o.id]);assert.equal((await call('/api/create-order',o)).status,400);
 const d={id:o.id,revision:1,carrier:'Courier',tracking:'AWB123',url:'javascript:alert(1)',message:'Packed',estimate:'Next week'};
 assert.equal((await call('/api/admin/delivery',d,cookie)).status,400);assert.equal((await call('/api/admin/delivery',{...d,url:'https://example.com/track'},cookie)).status,200);assert.equal((await call('/api/track',o)).data.delivery.tracking,'AWB123');
 const paid=await order(),id=(await call('/api/create-order',paid)).data.order_id;payment(id,'pay_Refresh');assert.equal((await call('/api/payment-status',paid)).data.payment_state,'captured');
});
