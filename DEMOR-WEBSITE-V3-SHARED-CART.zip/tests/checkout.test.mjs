import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {webcrypto} from 'node:crypto';
import {JSDOM} from 'jsdom';
const script=await readFile(new URL('../public/assets/js/payments.js',import.meta.url),'utf8');
const tick=()=>new Promise(resolve=>setTimeout(resolve,10));
async function setup(page='checkout.html'){
 const html=await readFile(new URL('../public/'+page,import.meta.url),'utf8');const dom=new JSDOM(html,{url:'https://demor.in/'+page,runScripts:'outside-only'}),w=dom.window;
 Object.defineProperty(w,'crypto',{value:webcrypto});w.TextEncoder=TextEncoder;
 let modal;w.Razorpay=class{constructor(options){this.options=options;this.events={};modal=this}on(k,fn){this.events[k]=fn}open(){this.opened=true}};
 w.DemorAuth={ready:async()=>{},user:()=>({id:'test-user-12345678',email:'testbuyer@example.com'}),token:async()=> 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'};w.eval(script);return {dom,w,modal:()=>modal};
}
test('mobile checkout keeps the saved order after modal dismissal and retries the same order',async()=>{
 const {dom,w,modal}=await setup();const calls=[];
 w.cartLines=()=>[{product:{id:'dm-001',name:'Kurta',price:2799},size:'M',qty:1}];w.cartSubtotal=()=>2799;let cleared=false;w.saveCart=()=>{cleared=true};
 w.fetch=async(path,options)=>{const body=options?.body?JSON.parse(options.body):null;calls.push({path,body});return {ok:true,json:async()=>path==='/api/payment-config'?{enabled:true,mode:'test'}:path==='/api/orders'?{id:'DM-fixture',token:'private-fixture'}:{order_id:'order_Fixture',amount:279900,currency:'INR',key_id:'rzp_test_Fixture',mode:'test'}}};
 await w.DemorCheckout.init();w.document.getElementById('checkout-form').dispatchEvent(new w.Event('submit',{bubbles:true,cancelable:true}));
 for(let i=0;i<50&&!modal();i++)await tick();assert.ok(modal()?.opened);assert.equal(modal().options.amount,279900);assert.ok(cleared);assert.equal(w.localStorage.getItem('demor_checkout_request_v1'),null);assert.match(w.localStorage.getItem('demor_orders_v1'),/DM-fixture/);
 modal().options.modal.ondismiss();assert.match(w.document.getElementById('checkout-root').textContent,/Payment window closed/);
 w.document.querySelector('#checkout-root button').click();await tick();assert.equal(calls.filter(c=>c.path==='/api/orders').length,1);assert.equal(calls.filter(c=>c.path==='/api/create-order').length,2);assert.equal(calls.find(c=>c.path==='/api/create-order').body.token,'private-fixture');dom.window.close();
});
test('failed event, invalid verification and authorized payment never show paid success',async()=>{
 const {dom,w,modal}=await setup();const message=w.document.createElement('p');let resultMode='invalid';w.fetch=async path=>({ok:path!=='/api/verify-payment'||resultMode!=='invalid',json:async()=>path==='/api/create-order'?{order_id:'order_Fixture',amount:100,currency:'INR',key_id:'rzp_test_Fixture',mode:'test'}:resultMode==='invalid'?{error:'Payment signature is invalid'}:{payment_state:'authorized',payment_mode:'test'}});
 const order={id:'DM-fixture',token:'private-fixture'};await w.DemorCheckout.startPayment(order,message);modal().events['payment.failed']({});assert.match(message.textContent,/failed/);await modal().options.handler({razorpay_order_id:'order_Fixture',razorpay_payment_id:'pay_Fixture',razorpay_signature:'bad'});assert.match(message.textContent,/signature is invalid/);assert.doesNotMatch(message.textContent,/Payment verified/);
 resultMode='authorized';await w.DemorCheckout.startPayment(order,message);await modal().options.handler({});assert.match(message.textContent,/processing/);assert.doesNotMatch(message.textContent,/Payment verified/);dom.window.close();
});
test('My Orders renders product text safely and only sends saved private order credentials',async()=>{
 const {dom,w}=await setup('my-orders.html');w.localStorage.setItem('demor_orders_v1',JSON.stringify([{id:'DM-fixture',token:'private-fixture'}]));const calls=[];w.fetch=async(path,options)=>{calls.push(JSON.parse(options.body));return {ok:true,json:async()=>({id:'DM-fixture',created:1,items:[{name:'<img src=x onerror=alert(1)>',size:'M',qty:1,price:100}],total:100,status:'New',payment:'TEST — Paid online',payment_mode:'test',payment_state:'captured',can_pay:false,delivery:{carrier:'Courier',tracking:'ABC',url:'javascript:alert(1)'}})}};
 await w.DemorCheckout.orders();assert.equal(w.document.querySelectorAll('#my-order-list img').length,0);assert.equal(w.document.querySelectorAll('#my-order-list a[href^="javascript:"]').length,0);assert.match(w.document.getElementById('my-order-list').textContent,/TEST — Paid online/);assert.ok(calls.every(x=>x.token==='private-fixture'));dom.window.close();
});
