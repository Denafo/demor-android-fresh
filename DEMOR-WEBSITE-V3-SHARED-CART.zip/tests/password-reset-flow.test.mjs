import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';
const source=readFileSync(new URL('../public/assets/js/password-reset.js', import.meta.url),'utf8');
const homepage=readFileSync(new URL('../public/index.html', import.meta.url),'utf8');
function harness(hash, opts={}) {
  const handlers={};
  const elements={};
  const make = () => ({hidden:true,disabled:false,value:'',type:'password',dataset:{},textContent:'',listeners:{},
    addEventListener(name,fn){this.listeners[name]=fn},setAttribute(){}});
  for(const k of ['reset-form','reset-status','reset-submit','password','confirm'])elements[k]=make();
  const calls=[];
  const context={
    window:{location:{hash,pathname:'/reset-password.html',search:''},history:{replaceState(...args){calls.push(['replaceState',...args])}}},
    document:{getElementById(id){return elements[id]},querySelectorAll(){return []}},
    URLSearchParams,console,
    fetch:async (url,options)=>{calls.push(['fetch',url,options]); return opts.fetch?.(url,options)??{ok:false,json:async()=>({})}}
  };
  vm.runInNewContext(source,context);
  return {elements,calls,submit:()=>elements['reset-form'].listeners.submit({preventDefault(){}})};
}
test('missing token cannot show form or verify',()=>{
 const {elements,calls}=harness('');
 assert.equal(elements['reset-form'].hidden,true);
 assert.match(elements['reset-status'].textContent,/missing or invalid/);
 assert.equal(calls.some(x=>x[0]==='fetch'),false);
});
test('success verifies token, updates password and clears it',async()=>{
 const h=harness('#recovery_token=test%2Dsingle-use', {fetch:async(url)=>url.endsWith('/verify')?{ok:true,json:async()=>({access_token:'ephemeral-access'})}:{ok:true,json:async()=>({})}});
 assert.equal(h.elements['reset-form'].hidden,false);
 h.elements.password.value='a-very-long-and-strong-password';
 h.elements.confirm.value='a-very-long-and-strong-password';
 await h.submit();
 const requests=h.calls.filter(x=>x[0]==='fetch');
 assert.equal(requests.length,3);
 assert.equal(JSON.parse(requests[0][2].body).token,'test-single-use');
 assert.equal(requests[1][2].headers.Authorization,'Bearer ephemeral-access');
 assert.equal(JSON.parse(requests[1][2].body).password,'a-very-long-and-strong-password');
 assert.equal(h.elements['reset-form'].hidden,true);
 assert.equal(h.elements.password.value,'');
 assert.match(h.elements['reset-status'].textContent,/changed successfully/);
 assert.equal(h.calls[0][0],'replaceState');
});
test('mismatched passwords do not exchange one-time token',async()=>{
 const h=harness('#recovery_token=abc');
 h.elements.password.value='strong-and-long-pass';h.elements.confirm.value='mismatched-long-pass';
 await h.submit();
 assert.equal(h.calls.some(x=>x[0]==='fetch'),false);
 assert.match(h.elements['reset-status'].textContent,/do not match/);
});
test('invalid token rejection does not falsely claim reset',async()=>{
 const h=harness('#recovery_token=expired',{fetch:async()=>({ok:false,json:async()=>({msg:'expired'})})});
 h.elements.password.value='strong-and-long-pass';h.elements.confirm.value='strong-and-long-pass';
 await h.submit();
 assert.match(h.elements['reset-status'].textContent,/may have expired/);
 assert.equal(h.elements['reset-form'].hidden,false);
});
test('homepage has early recovery redirect before any other scripts',()=>{
 const pos=homepage.indexOf("h.has('recovery_token')");
 assert.ok(pos>0);
 assert.ok(pos<homepage.indexOf('</head>'));
});
