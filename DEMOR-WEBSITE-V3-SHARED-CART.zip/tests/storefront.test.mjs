import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {JSDOM} from 'jsdom';
const base=new URL('../public/',import.meta.url);
const sources=await Promise.all(['svg-art.js','main.js','modern.js'].map(name=>readFile(new URL('assets/js/'+name,base),'utf8')));
const fixture={id:'current-kurta',name:'Ivory Silk Kurta',fabric:'Silk',color:'Ivory',category:'kurtas',description:'Soft silk kurta',price:1999,compareAt:2999,sizes:['M','L'],stock:{M:2,L:3},care:['Dry clean'],art:{garment:'kurta',tone:'#efe6d0'},newArrival:true,bestSeller:true};
async function storefront(page='index.html',products=[fixture],cart=[]){
 const html=await readFile(new URL(page.split('?')[0],base),'utf8');
 const dom=new JSDOM(html,{url:'https://demor.in/'+page,runScripts:'outside-only',pretendToBeVisual:true}),w=dom.window;
 w.HTMLDialogElement.prototype.showModal=function(){this.open=true};w.HTMLDialogElement.prototype.close=function(){this.open=false;this.dispatchEvent(new w.Event('close'))};
 w.localStorage.setItem('demor_cart_v1',JSON.stringify(cart));
 w.eval('const PRODUCTS='+JSON.stringify(products)+';\n'+sources.join('\n'));
 await new Promise(resolve=>w.document.readyState==='loading'?w.document.addEventListener('DOMContentLoaded',resolve,{once:true}):resolve());
 return {dom,w,doc:w.document};
}
test('small live catalogue links hero to an existing product and avoids duplicate home rails',async()=>{
 const {dom,doc}=await storefront();
 assert.match(doc.querySelector('.hero-product').getAttribute('href'),/id=current-kurta$/);
 assert.match(doc.querySelector('.hero-product').textContent,/Ivory Silk Kurta/);
 assert.ok(doc.querySelector('#new-arrivals-grid').closest('section').hidden);
 assert.ok(doc.querySelector('#best-sellers-grid').closest('section').hidden);
 assert.ok(doc.querySelector('.occasion-everyday').hidden);
 assert.ok(doc.querySelector('.occasion-festive').hidden);
 dom.window.close();
});
test('larger catalogue appears without duplicate products in homepage rails',async()=>{
 const products=Array.from({length:10},(_,i)=>({...fixture,id:'style-'+String(i).padStart(2,'0')}));
 const {dom,doc}=await storefront('index.html',products);
 const ids=[...doc.querySelectorAll('#featured-grid [data-save],#new-arrivals-grid [data-save],#best-sellers-grid [data-save]')].map(el=>el.dataset.save);
 assert.equal(ids.length,new Set(ids).size);assert.equal(ids.length,10);dom.window.close();
});
test('product requires an explicit size and respects remaining stock already in the bag',async()=>{
 const {dom,doc,w}=await storefront('product.html?id=current-kurta');
 assert.equal(doc.getElementById('add-to-cart-btn').disabled,true);
 doc.querySelector('[data-size="M"]').click();assert.equal(doc.getElementById('add-to-cart-btn').disabled,false);
 doc.getElementById('qty-plus').click();assert.equal(doc.getElementById('qty-val').textContent,'2');assert.equal(doc.getElementById('qty-plus').disabled,true);
 doc.getElementById('add-to-cart-btn').click();assert.equal(JSON.parse(w.localStorage.getItem('demor_cart_v1'))[0].qty,2);assert.equal(doc.getElementById('add-to-cart-btn').disabled,true);
 doc.querySelector('[data-size="L"]').click();assert.equal(doc.getElementById('qty-val').textContent,'1');assert.equal(doc.querySelector('[data-size="L"]').getAttribute('aria-pressed'),'true');dom.window.close();
});
test('unavailable product gives a useful route back and never shows an add button',async()=>{
 const {dom,doc}=await storefront('product.html?id=removed-style');
 assert.match(doc.querySelector('#pd-root').textContent,/This style is unavailable/);assert.ok(doc.querySelector('#pd-root a[href="shop.html"]'));assert.equal(doc.getElementById('add-to-cart-btn'),null);dom.window.close();
});
test('unavailable cart item prevents checkout and can be removed with a button',async()=>{
 const {dom,doc}=await storefront('cart.html',[fixture],[{id:'removed-style',size:'M',qty:1}]);
 assert.equal(doc.querySelector('#cart-root a[href="checkout.html"]'),null);
 doc.querySelector('button.js-remove').click();assert.match(doc.getElementById('cart-root').textContent,/Your bag is empty/);dom.window.close();
});
test('search understands multiple words and empty state clears filters',async()=>{
 const {dom,doc,w}=await storefront('shop.html');w.initShopPage();const input=doc.getElementById('shop-search');
 input.value='silk ivory';input.dispatchEvent(new w.Event('input'));assert.equal(doc.querySelectorAll('#product-grid .product-card').length,1);
 input.value='not-a-product';input.dispatchEvent(new w.Event('input'));assert.equal(doc.querySelectorAll('#product-grid .product-card').length,0);
 doc.querySelector('[data-reset-filters]').click();assert.equal(doc.querySelectorAll('#product-grid .product-card').length,1);dom.window.close();
});
test('a failed local save never claims an item was added',async()=>{
 const {dom,w}=await storefront();w.Storage.prototype.setItem=function(){throw Error('Storage blocked')};
 assert.equal(w.addToCart('current-kurta','M',1),false);assert.match(w.document.querySelector('.toast').textContent,/could not save/);dom.window.close();
});
test('order search and status filters preserve private access and accurate delivery progress',async()=>{
 const html=await readFile(new URL('my-orders.html',base),'utf8'),script=await readFile(new URL('assets/js/payments.js',base),'utf8');
 const dom=new JSDOM(html,{url:'https://demor.in/my-orders.html',runScripts:'outside-only'}),w=dom.window,doc=w.document;
 w.localStorage.setItem('demor_orders_v1',JSON.stringify([{id:'DM-one',token:'fake-private-one'},{id:'DM-two',token:'fake-private-two'}]));
 w.fetch=async(_path,options)=>{const body=JSON.parse(options.body);return {ok:true,json:async()=>({id:body.id,created:1700000000,status:body.id==='DM-one'?'Shipped':'Delivered',payment:'Paid online',payment_state:'captured',payment_mode:'live',items:[{name:body.id==='DM-one'?'Silk Kurta':'Cotton Set',qty:1,size:'M',price:1999}],total:1999,delivery:{},can_pay:false})}};
 w.eval(script);await new Promise(resolve=>doc.readyState==='loading'?doc.addEventListener('DOMContentLoaded',resolve,{once:true}):resolve());await w.DemorCheckout.orders();
 assert.equal(doc.getElementById('orders-total').textContent,'2');assert.equal(doc.getElementById('orders-delivered').textContent,'1');
 doc.querySelector('[data-order-filter="delivered"]').click();assert.equal(doc.querySelectorAll('.order-card:not([hidden])').length,1);assert.equal(doc.querySelector('.order-card:not([hidden])').dataset.orderId,'DM-two');
 assert.equal(doc.querySelector('[data-order-id="DM-one"] [aria-current="step"]').textContent,'4Shipped');
 doc.querySelector('[data-order-filter="all"]').click();const search=doc.getElementById('order-search');search.value='silk';search.dispatchEvent(new w.Event('input'));assert.equal(doc.querySelector('.order-card:not([hidden])').dataset.orderId,'DM-one');
 assert.equal(doc.querySelectorAll('a[href*="fake-private"]').length,0);dom.window.close();
});
