import {test,before,after} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {PGlite} from '@electric-sql/pglite';
import {makeHandler} from '../server/handler.mjs';
import {passwordHash} from '../server/security.mjs';
let db,handler,cookie,order;
const origin='https://demor.in';
const IDENTITY_TEST_TOKEN='aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa';
const identityFetch=async(_url,options)=>new Response(JSON.stringify({id:'test-user-12345678',email:'testbuyer@example.com'}),{status:options.headers.Authorization==='Bearer '+IDENTITY_TEST_TOKEN?200:401,headers:{'Content-Type':'application/json'}});

const customer={name:'Test customer',phone:'9999999999',address:'12 Test Road',city:'Mumbai',state:'MH',pincode:'400001'};
const payload={requestKey:'12345678-1234-1234-1234-123456789012',customer,items:[{id:'dm-001',qty:1,size:'M',price:1}]};
async function call(path,data,auth='',overrides={}){
 const req=new Request(origin+path,{method:data===undefined?'GET':'POST',headers:{Origin:origin,'Content-Type':'application/json',Cookie:auth,Authorization:'Bearer '+IDENTITY_TEST_TOKEN,...overrides.headers},body:data===undefined?undefined:JSON.stringify(data)});
 const res=await handler(req,{ip:overrides.ip||'203.0.113.3'});return {status:res.status,data:await res.json(),headers:res.headers};
}
before(async()=>{
 db=new PGlite();await db.exec(await readFile(new URL('../server/schema.sql',import.meta.url),'utf8'));
 await db.exec(await readFile(new URL('../server/product-upgrade.sql',import.meta.url),'utf8'));
 await db.exec("UPDATE demor_products SET active=true, stock='{\"S\":5,\"M\":5,\"L\":5,\"XL\":5,\"XXL\":5}'::jsonb");
 await db.exec(await readFile(new URL('../server/payments.sql',import.meta.url),'utf8'));
 const catalog=JSON.parse(await readFile(new URL('../server/catalog.json',import.meta.url),'utf8'));
 handler=makeHandler({query:async(s,p)=>(await db.query(s,p)).rows,env:{DATABASE_URL:'test',DEMOR_ORIGIN:origin,DEMOR_SESSION_SECRET:'secret'.repeat(8),DEMOR_OWNER_HASH:await passwordHash('test-password-long')},catalog,identityFetch});
});
after(async()=>db.close());
test('private owner login and secure cookie',async()=>{
 assert.equal((await call('/api/admin')).status,401);
 assert.equal((await call('/api/login',{password:'wrong'})).status,401);
 const login=await call('/api/login',{password:'test-password-long'});assert.equal(login.status,200);cookie=login.headers.get('set-cookie').split(';')[0];
 assert.match(login.headers.get('set-cookie'),/HttpOnly; Secure; SameSite=Strict/);
 assert.equal((await call('/api/admin',undefined,cookie)).status,200);
});
test('server prices, duplicate submission, private tracking',async()=>{
 const created=await call('/api/orders',payload);assert.equal(created.status,201);order=created.data;
 assert.deepEqual((await call('/api/orders',payload)).data,order);
 assert.equal((await call('/api/orders',{...payload,customer:{...customer,name:'Changed'}})).status,409);
 const admin=await call('/api/admin',undefined,cookie);assert.equal(admin.data.orders.length,1);assert.equal(admin.data.orders[0].total,2799);
 assert.equal('token_hash' in admin.data.orders[0],false);
 assert.equal((await call('/api/track',{id:order.id,token:'wrong'})).status,404);
 assert.equal((await call('/api/track',order)).data.status,'New');
});
test('invalid quantities, owner-only updates and concurrent edit protection',async()=>{
 assert.equal((await call('/api/orders',{...payload,items:[{id:'dm-001',qty:-1,size:'M'}]})).status,400);
 const update={kind:'order',id:order.id,revision:1,status:'Shipped',payment:'Pending',notes:'Carrier reference 123'};
 assert.equal((await call('/api/admin/update',update)).status,401);
 assert.equal((await call('/api/admin/update',update,cookie)).status,200);
 assert.equal((await call('/api/admin/update',update,cookie)).status,409);
 assert.equal((await call('/api/admin/update',{...update,revision:2,payment:'Refunded externally',notes:''},cookie)).status,400);
 const result=await db.query('SELECT history FROM demor_orders WHERE id=$1',[order.id]);assert.equal(result.rows[0].history.length,1);
});
test('inventory is atomic, idempotent and restored once on cancellation',async()=>{
 const stock=async()=>(await db.query("SELECT stock FROM demor_products WHERE id='dm-001'")).rows[0].stock.M;
 assert.equal(await stock(),4);
 const base={...payload,requestKey:'inventory-order-12345678901234',items:[{id:'dm-001',qty:3,size:'M'}]};
 const a=await call('/api/orders',base);assert.equal(a.status,201);assert.equal(await stock(),1);
 assert.equal((await call('/api/orders',base)).status,201);assert.equal(await stock(),1);
 assert.equal((await call('/api/orders',{...base,requestKey:'outofstock-order-12345678901234'})).status,409);assert.equal(await stock(),1);
 const update={kind:'order',id:a.data.id,revision:1,status:'Cancelled',payment:'Pending',notes:''};
 assert.equal((await call('/api/admin/update',update,cookie)).status,200);assert.equal(await stock(),4);
 assert.equal((await call('/api/admin/update',{...update,revision:2},cookie)).status,200);assert.equal(await stock(),4);
 assert.equal((await call('/api/admin/update',{...update,revision:3,status:'New'},cookie)).status,409);
 const failed={...base,requestKey:'multi-item-rollback-123456789012',items:[{id:'dm-001',size:'M',qty:2},{id:'dm-002',size:'M',qty:20}]};
 assert.equal((await call('/api/orders',failed)).status,409);assert.equal(await stock(),4);
 assert.equal((await call('/api/admin/update',{...update,id:order.id,revision:2},cookie)).status,409);
});
test('owner product editing validates data and protects concurrent stock changes',async()=>{
 const product={id:'new-kurta',revision:0,active:true,details:{name:'New <kurta>',description:'Test',fabric:'Cotton',color:'Ivory',category:'kurtas',price:1200,care:'Wash cold'},stock:{M:2}};
 assert.equal((await call('/api/admin/product',product)).status,401);
 assert.equal((await call('/api/admin/product',product,cookie)).status,200);
 assert.equal((await call('/api/admin/product',product,cookie)).status,409);
 assert.equal((await call('/api/admin/product',{...product,revision:1,stock:{M:-1}},cookie)).status,400);
 assert.equal((await call('/api/admin/product',{...product,revision:1,image:'data:image/jpeg;base64,AAAA'},cookie)).status,400);
 const list=await call('/api/catalog');assert.equal(list.data.find(p=>p.id==='new-kurta').price,1200);
 const buy={...payload,requestKey:'new-product-purchase-12345678901',items:[{id:'new-kurta',size:'M',qty:1}]};assert.equal((await call('/api/orders',buy)).status,201);
 assert.equal((await call('/api/admin/product',{...product,revision:1},cookie)).status,409);
 const script=await handler(new Request(origin+'/api/catalog.js'),{ip:'203.0.113.3'});const js=await script.text();assert.ok(js.includes('New &lt;kurta&gt;'));assert.equal(js.includes('New <kurta>'),false);
 assert.equal((await call('/api/admin/product',{...product,revision:2,active:false},cookie)).status,200);
 assert.equal((await call('/api/catalog')).data.some(p=>p.id==='new-kurta'),false);
});
test('last item cannot oversell; legacy cancellations and rerunning migration preserve stock',async()=>{
 await db.exec("UPDATE demor_products SET stock='{\"M\":1}'::jsonb WHERE id='dm-002'");
 const buy=key=>call('/api/orders',{...payload,requestKey:key,items:[{id:'dm-002',size:'M',qty:1}]});
 const results=await Promise.all([buy('last-one-first-12345678901234'),buy('last-one-second-12345678901234')]);
 assert.deepEqual(results.map(r=>r.status).sort(),[201,409]);
 await db.exec(`INSERT INTO demor_orders(id,token_hash,request_hash,payload_hash,created,customer,items,total) VALUES('legacy','x','legacy','x',0,'{}','[{"id":"dm-002","size":"M","qty":3}]',100)`);
 assert.equal((await call('/api/admin/update',{kind:'order',id:'legacy',revision:1,status:'Cancelled',payment:'Pending',notes:''},cookie)).status,200);
 await db.exec(await readFile(new URL('../server/product-upgrade.sql',import.meta.url),'utf8'));
 assert.equal((await db.query("SELECT stock FROM demor_products WHERE id='dm-002'")).rows[0].stock.M,0);
 assert.equal((await call('/api/orders',{...payload,requestKey:'price-changed-12345678901234',items:[{id:'dm-001',size:'M',qty:1,expectedPrice:1}]})).status,409);
});
test('support idempotency, resolution, CSRF, login rate limit and logout',async()=>{
 const data={requestKey:'support-12345678901234567890',name:'Test',phone:'9999999999',message:'Payment issue',type:'Payment problem'};
 const a=await call('/api/tickets',data),b=await call('/api/tickets',data);assert.equal(a.status,201);assert.deepEqual(a.data,b.data);
 assert.equal((await call('/api/admin/update',{kind:'ticket',id:a.data.id,revision:1,status:'Resolved',notes:'Contacted customer'},cookie)).status,200);
 assert.equal((await call('/api/tickets',data,'',{headers:{Origin:'https://evil.example'}})).status,403);
 for(let i=0;i<10;i++)await call('/api/login',{password:'wrong'},'',{ip:'203.0.113.9'});
 assert.equal((await call('/api/login',{password:'test-password-long'},'',{ip:'203.0.113.9'})).status,429);
 assert.equal((await call('/api/logout',{},cookie)).status,200);
 assert.equal((await call('/api/admin',undefined,cookie)).status,401);
});
