import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';

const source=await readFile(new URL('../public/assets/js/cart-sync.js',import.meta.url),'utf8');
const product={id:'dm-001',stock:{S:4}};
function harness(local,server){
 const saved=new Map([['demor_cart_v1',JSON.stringify(local)]]);
 const session={items:server.map(x=>({...x})),revision:server.length?1:0};
 const documentListeners=new Map(),windowListeners=new Map();
 const storage={getItem:k=>saved.get(k)||null,setItem:(k,v)=>saved.set(k,v),removeItem:k=>saved.delete(k)};
 const user={id:'customer-id-1',email:'buyer@example.com'};
 const window={
  PRODUCTS:[product],
  getCart:()=>JSON.parse(storage.getItem('demor_cart_v1')||'[]'),
  updateCartCount:()=>{},renderCartPage:()=>{},
  DemorAuth:{ready:async()=>{},token:async()=>('a'.repeat(40)),user:()=>user},
  addEventListener:(type,fn)=>windowListeners.set(type,fn)
 };
 const document={getElementById:()=>null,addEventListener:(type,fn)=>documentListeners.set(type,fn)};
 const fetch=async(_path,opts)=>{
  assert.match(opts.headers.Authorization,/^Bearer /);
  if(opts.method==='GET')return {ok:true,json:async()=>({...session,items:[...session.items]})};
  const payload=JSON.parse(opts.body);
  if(payload.revision!==session.revision)return {ok:false,status:409,json:async()=>({error:'stale'})};
  session.items=payload.items;session.revision++;
  return {ok:true,json:async()=>({...session})};
 };
 const context=vm.createContext({window,document,localStorage:storage,fetch,PRODUCTS:[product],setTimeout,clearTimeout});
 vm.runInContext(source,context);
 return {window,session,storage,fireLoad:()=>documentListeners.get('DOMContentLoaded')?.()};
}
const wait=ms=>new Promise(r=>setTimeout(r,ms));
test('first web login merges old browser cart into account cart',async()=>{
 const h=harness([{id:'dm-001',size:'S',qty:2}],[]);
 h.fireLoad();await wait(30);
 assert.equal(h.session.items.length,1);
 assert.equal(h.session.items[0].qty,2);
 assert.equal(h.storage.getItem('demor_cloud_cart_migrated_v1:customer-id-1'),'1');
});
test('website receives app edits from shared cart after focus',async()=>{
 const h=harness([],[{id:'dm-001',size:'S',qty:1}]);
 h.fireLoad();await wait(30);
 assert.equal(h.window.getCart()[0].qty,1);
 h.session.items=[{id:'dm-001',size:'S',qty:3}];h.session.revision++;
 await h.window.DemorCartSync.pull();
 assert.equal(h.window.getCart()[0].qty,3);
});
test('website update writes back to shared account bag',async()=>{
 const h=harness([],[{id:'dm-001',size:'S',qty:1}]);
 h.fireLoad();await wait(30);
 h.storage.setItem('demor_cart_v1',JSON.stringify([{id:'dm-001',size:'S',qty:2}]));
 h.window.DemorCartSync.localChanged();await h.window.DemorCartSync.flush();
 assert.equal(h.session.items[0].qty,2);
});
