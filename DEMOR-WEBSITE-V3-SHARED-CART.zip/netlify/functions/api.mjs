import {neon} from '@neondatabase/serverless';
import {makeHandler} from '../../server/handler.mjs';
import catalog from '../../server/catalog.json' with {type:'json'};
export default async(request,context)=>{
 const env=process.env;
 if(!env.DATABASE_URL)return new Response(JSON.stringify({error:'Store setup is incomplete. Please contact the store owner.'}),{status:503,headers:{'Content-Type':'application/json','Cache-Control':'no-store'}});
 try{const sql=neon(env.DATABASE_URL);return await makeHandler({query:(q,p)=>sql.query(q,p),env,catalog})(request,context)}catch{return new Response(JSON.stringify({error:'Store configuration is unavailable.'}),{status:503,headers:{'Content-Type':'application/json','Cache-Control':'no-store'}})}
};
export const config={path:'/api/*'};
