DEMOR — CUSTOMER LOGIN (TEST BUILD) — 16 OCT 2026

Features in this ZIP:
1. DEMOR custom Login/Sign Up form on account.html. Netlify Identity used for its authentication backend (widget only loaded to maintain callback/session compatibility).
2. Google (custom OAuth provider configured separately on Netlify) + email/password signup/login/recovery.
3. /account.html with sign-in / signup entry points and account summary.
4. Shopping and cart without login; Checkout requires a signed-in Identity customer.
5. Backend POST /api/orders rejects missing/invalid Identity access token. It validates bearer tokens with the site's Netlify Identity service endpoint; never trusts account ID supplied by browser.
6. New orders tied to verified Identity user ID in customer JSON data, and email drawn from account.
7. My Orders loads verified account orders, including from other devices.
8. Payment, cancellation, tracking and return request endpoints recognize verified account ownership. Legacy private tracking-code access remains for older orders.
9. Existing legacy orders can be linked to account only with the private tracking code.
10. Existing Razorpay, Shiprocket and administrator code preserved.

SECURITY AND GO-LIVE CHECKLIST
- Not live until separately deployed and tested.
- Do not deploy this untested build directly to production. First deploy to staging/preview on the existing Netlify site or test using a rollback-ready method.
- On Google Auth Platform, your app is still in TESTING: only listed Google test users can sign in. Do not publish before support email, privacy links, and branding are reviewed.
- Before public launch, change Google OAuth support contact to appropriate business email (personal email can appear in OAuth consent screen).
- Test Google sign-in, email signup + confirmation, password recovery, sign-out, login-required checkout, unauthenticated POST /api/orders rejection, My Orders across browsers, cancel, returns and Razorpay in test mode.
- Shipping secrets and payment secrets stay in Netlify variables; no credentials should be in this ZIP.
- Test checkout with real Netlify Identity endpoint; it is unavailable locally without the live service.
- Server uses Netlify GoTrue GET /.netlify/identity/user to validate customer bearer token, so test its production availability before activation. This is a server-side authenticated request; do NOT just trust a token's decoded contents.
- A Netlify build/deploy that does not install dependencies correctly may break the site; inspect deploy logs.
- Existing private-code orders are not automatically associated with a customer's new account; use the provided Link to My Account action after login.
- Normal DEMOR Login and Sign Up never open the Netlify widget modal. OAuth/email confirmation callbacks may still be handled by the underlying widget; check these flows on a real deployed site. Google consent branding is configured separately.

STATUS:
- JS syntax and source structure checked locally.
- npm test is not runnable here because dev dependencies (jsdom, PGlite) are not installed and npm registry access is unavailable.
- Live Google OAuth, Netlify Identity API and Razorpay tests NOT run.
