"""Applied after flutter create in CI; brand the Android application."""
from pathlib import Path
import re

manifest = Path('android/app/src/main/AndroidManifest.xml')
s = manifest.read_text()
s = s.replace('<manifest xmlns:android="http://schemas.android.com/apk/res/android">',
              '<manifest xmlns:android="http://schemas.android.com/apk/res/android">\n    <uses-permission android:name="android.permission.INTERNET" />', 1)
s = re.sub(r'android:label="[^"]*"', 'android:label="DEMOR"', s, count=1)
manifest.write_text(s)

# Do not rewrite the Android package without moving MainActivity too.
# Package/applicationId will be finalized during the signed release build.

# Encrypted account tokens require Android API 23+.
for build_file in (Path('android/app/build.gradle.kts'), Path('android/app/build.gradle')):
    if build_file.exists():
        source = build_file.read_text()
        source = source.replace('minSdk = flutter.minSdkVersion', 'minSdk = 23')
        source = source.replace('minSdkVersion flutter.minSdkVersion', 'minSdkVersion 23')
        build_file.write_text(source)

# Do not back up app-scoped encrypted session material into a different device.
if 'android:allowBackup=' not in s:
    s = s.replace('<application', '<application android:allowBackup="false"', 1)
    manifest.write_text(s)
