# V2 native checkout

The previous V1 website cart URL bridge is no longer used in V2. Native checkout uses the original DEMOR account and `/api/orders`, `/api/create-order` and `/api/verify-payment` endpoints.

In the first V2 APK the checkout submit button is intentionally locked. To test placing orders, the build must **explicitly** set `--dart-define=DEMOR_ENABLE_TEST_CHECKOUT=true`, and the existing store's `/api/payment-config` endpoint must return `{"enabled":true,"mode":"test"}`.

Even in Razorpay TEST mode, a DEMOR test order can reserve **actual live inventory**. Never enable without preparing an isolated safe testing procedure. Do not deploy a payment-key or database change as a workaround.
