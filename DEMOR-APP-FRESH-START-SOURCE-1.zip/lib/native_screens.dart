part of 'main.dart';

/// Native account pages reuse the same Netlify Identity tenant as DEMOR.in.
class NativeAccountScreen extends StatelessWidget {
  final DemorAuth auth;
  const NativeAccountScreen({super.key, required this.auth});

  @override
  Widget build(BuildContext context) => AnimatedBuilder(animation: auth, builder: (context, _) {
    return ListView(children: [
      const SectionTitle('YOUR DEMOR', 'My account'),
      Padding(padding: const EdgeInsets.symmetric(horizontal: 17), child: Container(
        padding: const EdgeInsets.all(21),
        decoration: BoxDecoration(color: const Color(0xFFE4ECE6), borderRadius: BorderRadius.circular(18)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Icon(Icons.person_outline, color: forest, size: 35),
          const SizedBox(height: 12),
          Text(auth.signedIn ? (auth.name ?? 'Welcome back') : 'Your style. Your account.',
            style: const TextStyle(fontFamily: 'serif', color: ink, fontSize: 24)),
          const SizedBox(height: 7),
          Text(auth.signedIn ? (auth.email ?? '') : 'Sign in or create a DEMOR account without leaving the app.',
            style: const TextStyle(height: 1.5, color: ink)),
        ]),
      )),
      const SizedBox(height: 18),
      if (!auth.signedIn) _AccountAction(
        label: 'Log in / Create account', icon: Icons.login_outlined,
        onTap: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => NativeLoginPage(auth: auth))),
      ),
      if (auth.signedIn) _AccountAction(
        label: 'My Orders & Tracking', icon: Icons.local_shipping_outlined,
        onTap: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => NativeOrdersPage(auth:auth))),
      ),
      if (auth.signedIn) _AccountAction(label: 'Log out', icon: Icons.logout, onTap: () async {
        await auth.logout();
        if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Signed out on this device.')));
      }),
      _AccountAction(label: 'Customer support', icon: Icons.support_agent,
        onTap: () => visitWebsite(context, Uri.https(liveHost, '/contact.html'))),
      _AccountAction(label: 'Shipping & Returns', icon: Icons.assignment_return_outlined,
        onTap: () => visitWebsite(context, Uri.https(liveHost, '/shipping-returns.html'))),
      const Padding(padding: EdgeInsets.fromLTRB(24, 18, 24, 8), child: Text(
        'Google sign-in will be available after the secure Android OAuth return flow is configured. Existing email/password customers can sign in here now.',
        style: TextStyle(color: muted, height: 1.5, fontSize: 12), textAlign: TextAlign.center)),
    ]);
  });
}

class NativeLoginPage extends StatefulWidget {
  final DemorAuth auth;
  const NativeLoginPage({super.key, required this.auth});
  @override
  State<NativeLoginPage> createState() => _NativeLoginPageState();
}

class _NativeLoginPageState extends State<NativeLoginPage> {
  final formKey = GlobalKey<FormState>();
  final email = TextEditingController();
  final password = TextEditingController();
  final name = TextEditingController();
  String mode = 'login';
  bool busy = false;
  bool hidden = true;
  String? info;

  @override
  void dispose() {email.dispose();password.dispose();name.dispose();super.dispose();}

  Future<void> submit() async {
    if (!formKey.currentState!.validate() || busy) return;
    setState(() {busy = true; info = null;});
    try {
      if (mode == 'signup') {
        await widget.auth.signup(name.text, email.text, password.text);
        if (mounted) setState(() {info = 'Account request sent. Check your email and confirm your address before logging in.';mode = 'login';});
      } else if (mode == 'recover') {
        await widget.auth.sendPasswordReset(email.text);
        if (mounted) setState(() {info = 'If your account exists, check your email for a password reset link.';mode = 'login';});
      } else {
        await widget.auth.login(email.text, password.text);
        if (mounted) Navigator.of(context).pop();
      }
    } catch (e) {
      if (mounted) setState(() => info = e is DemorApiException ? e.message : 'Could not connect. Check internet and try again.');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('DEMOR Account')),
    body: SafeArea(child: SingleChildScrollView(padding: const EdgeInsets.all(22), child: Form(key:formKey,child:Column(
      crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const Text('Welcome to DEMOR', style: TextStyle(fontFamily:'serif',fontSize:30,color:ink)),
      const SizedBox(height: 12),
      Text(mode == 'signup' ? 'Create your account' : mode == 'recover' ? 'Reset your password' : 'Log in to continue shopping',
        style: const TextStyle(color:muted)),
      const SizedBox(height:24),
      if (mode != 'recover') Row(children: [
        Expanded(child: ChoiceChip(label:const Center(child:Text('Log in')),selected:mode=='login',onSelected:(_)=>setState(() {mode='login';info=null;}))),
        const SizedBox(width:10),
        Expanded(child: ChoiceChip(label:const Center(child:Text('Sign up')),selected:mode=='signup',onSelected:(_)=>setState(() {mode='signup';info=null;}))),
      ]),
      const SizedBox(height:20),
      if (mode == 'signup') ...[
        TextFormField(controller:name, textCapitalization:TextCapitalization.words, decoration:const InputDecoration(labelText:'Full name'),
          validator:(v)=>v == null || v.trim().length < 2 ? 'Enter your name' : null),
        const SizedBox(height:14),
      ],
      TextFormField(controller:email,keyboardType:TextInputType.emailAddress,autocorrect:false,
        decoration:const InputDecoration(labelText:'Email address'),
        validator:(v)=>v == null || !RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(v.trim()) ? 'Enter a valid email' : null),
      const SizedBox(height:14),
      if (mode != 'recover') ...[
        TextFormField(controller:password,obscureText:hidden,autocorrect:false,
          decoration:InputDecoration(labelText:'Password',suffixIcon:IconButton(
            onPressed:()=>setState(()=>hidden=!hidden),icon:Icon(hidden?Icons.visibility:Icons.visibility_off))),
          validator:(v)=>v == null || v.length < 6 ? 'Enter at least 6 characters' : null),
        const SizedBox(height:14),
      ],
      if (info != null) Padding(padding:const EdgeInsets.only(bottom:15),child:Text(info!,style:const TextStyle(color:forest,height:1.5))),
      FilledButton(onPressed:busy?null:submit,child:Padding(padding:const EdgeInsets.all(14),child:Text(
        busy?'Please wait…':mode=='signup'?'Create DEMOR account':mode=='recover'?'Send reset email':'Log in'))),
      if (mode != 'signup') TextButton(
        onPressed:()=>setState(() {mode=mode=='recover'?'login':'recover'; info=null;}),
        child:Text(mode=='recover'?'Back to login':'Forgot password?')),
      const SizedBox(height:15),
      const Text('Existing DEMOR.in email accounts use the same login. Google-only accounts need the upcoming secure Google sign-in integration.',
        textAlign:TextAlign.center,style:TextStyle(fontSize:12,color:muted,height:1.5)),
    ])))),
  );
}

class NativeOrdersPage extends StatefulWidget {
  final DemorAuth auth;
  const NativeOrdersPage({super.key,required this.auth});
  @override
  State<NativeOrdersPage> createState()=>_NativeOrdersPageState();
}
class _NativeOrdersPageState extends State<NativeOrdersPage> {
  late Future<List<dynamic>> request;
  @override
  void initState(){super.initState();load();}
  void load(){request = widget.auth.api('/api/my-orders').then((data) => data['orders'] is List ? data['orders'] as List : <dynamic>[]);}
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar:AppBar(title:const Text('My Orders'),actions:[IconButton(icon:const Icon(Icons.refresh),tooltip:'Refresh',onPressed:()=>setState(load))]),
    body:FutureBuilder<List<dynamic>>(future:request,builder:(context,snapshot){
      if(snapshot.connectionState!=ConnectionState.done)return const Center(child:CircularProgressIndicator());
      if(snapshot.hasError)return Center(child:Padding(padding:const EdgeInsets.all(24),child:Column(mainAxisSize:MainAxisSize.min,children:[
        Text('Could not load orders: ${snapshot.error}',textAlign:TextAlign.center),
        const SizedBox(height:14),FilledButton(onPressed:()=>setState(load),child:const Text('Try again'))])));
      final orders = snapshot.data ?? [];
      if(orders.isEmpty)return const Center(child:Text('No orders yet. Explore the collection.'));
      return RefreshIndicator(onRefresh:()async{setState(load);await request;},child:ListView.builder(
        padding:const EdgeInsets.all(16),itemCount:orders.length,itemBuilder:(context,index){
        final raw = orders[index]; final o = raw is Map ? raw : <String,dynamic>{};
        final items=o['items'] is List ? o['items'] as List : <dynamic>[];
        final delivery=o['delivery'] is Map ? o['delivery'] as Map : <dynamic,dynamic>{};
        return Card(color:Colors.white,margin:const EdgeInsets.only(bottom:12),child:Padding(
          padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Text('${o['id']??'Order'}',style:const TextStyle(fontWeight:FontWeight.bold,fontSize:17)),
          const SizedBox(height:8),Text('Status: ${o['status']??'Pending'}'),
          Text('Payment: ${o['payment']??'Pending'}'),
          Text('Total: ${rupees(asInt(o['total']))}',style:const TextStyle(fontWeight:FontWeight.bold,color:forest)),
          for(final item in items) if(item is Map) Text('${item['name']??'Product'} · ${item['size']??''} × ${item['qty']??1}',style:const TextStyle(color:muted)),
          if((delivery['tracking']??'').toString().isNotEmpty) ...[
            const SizedBox(height:8),Text('Tracking: ${delivery['tracking']}'),
          ],
          if(o['can_pay']==true) const Padding(padding:EdgeInsets.only(top:8),child:Text(
            'Payment pending. For your safety, verify payment status with DEMOR support before attempting payment again.',
            style:TextStyle(color:muted,fontSize:12))),
        ])));
      }));
    }),
  );
}

/// Deliberately opt-in for the first test APK; test orders reserve real store
/// inventory, so require explicit test mode and a human-approved build flag.
const bool _allowTestCheckout = bool.fromEnvironment('DEMOR_ENABLE_TEST_CHECKOUT', defaultValue:false);

class NativeCheckoutScreen extends StatefulWidget {
  final DemorStore store;
  final DemorAuth auth;
  const NativeCheckoutScreen({super.key,required this.store,required this.auth});
  @override
  State<NativeCheckoutScreen> createState()=>_NativeCheckoutScreenState();
}
class _NativeCheckoutScreenState extends State<NativeCheckoutScreen> {
  final formKey = GlobalKey<FormState>();
  final fields = <String,TextEditingController>{for(final k in ['name','phone','address','city','state','pincode','notes'])k:TextEditingController()};
  late final Razorpay razorpay;
  bool busy = false;
  String? warning;
  String? createdId;
  String? requestKey;

  @override
  void initState(){
    super.initState();
    fields['name']!.text = widget.auth.name ?? '';
    razorpay=Razorpay();
    razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS,_success);
    razorpay.on(Razorpay.EVENT_PAYMENT_ERROR,_failure);
    razorpay.on(Razorpay.EVENT_EXTERNAL_WALLET,_wallet);
  }
  @override
  void dispose(){for(final c in fields.values)c.dispose();razorpay.clear();super.dispose();}

  String _key(){
    if(requestKey!=null)return requestKey!;
    final random = Random.secure();
    final bytes=List<int>.generate(32,(_)=>random.nextInt(256));
    return requestKey=base64UrlEncode(bytes).replaceAll('=','');
  }
  void _message(String value){if(mounted)setState(()=>warning=value);}

  Future<void> checkout() async {
    if (!formKey.currentState!.validate() || busy || !_allowTestCheckout) return;
    setState((){busy=true;warning=null;});
    try {
      final config=await widget.auth.api('/api/payment-config');
      if(config['enabled']!=true||config['mode']!='test')throw const DemorApiException('Only Razorpay TEST mode is allowed in this preview. No order was placed.');
      if(!widget.store.bagValid)throw const DemorApiException('Some items are unavailable. Refresh shopping bag.');
      if(createdId==null){
        final payload=<String,dynamic>{
          'online':true,'requestKey':_key(),
          'customer':{...fields.map((k,c)=>MapEntry(k,c.text.trim())),'email':widget.auth.email},
          'items':widget.store.bag.map((line)=>{
            'id':line.id,'size':line.size,'qty':line.qty,'expectedPrice':widget.store.byId(line.id)!.price,
          }).toList(),
        };
        // Important: a timeout may occur after the server saved an order. Never
        // generate a new request key or retry blindly on uncertainty.
        final created=await widget.auth.api('/api/orders',payload:payload);
        createdId='${created['id']}';
      }
      final payment=await widget.auth.api('/api/create-order',payload:{'id':createdId});
      if(payment['mode']!='test')throw const DemorApiException('Payment mode changed. Check My Orders; do not retry blindly.');
      razorpay.open({
        'key':payment['key_id'],'order_id':payment['order_id'],
        'amount':payment['amount'],'currency':payment['currency'],
        'name':'DEMOR', 'description':'DEMOR test order $createdId',
        'prefill':{'email':widget.auth.email,'contact':fields['phone']!.text.trim()},
        'theme':{'color':'#225D50'},
      });
      _message('Order $createdId saved. Complete the TEST payment, or check My Orders before trying again.');
    } catch (e) {
      _message('${e is DemorApiException ? e.message : 'Connection error.'} ${createdId==null ? 'If unsure, check My Orders before retrying.' : 'Order $createdId remains saved in My Orders.'}');
    } finally {if(mounted)setState(()=>busy=false);}
  }

  Future<void> _success(PaymentSuccessResponse result) async {
    if(createdId==null)return;
    try {
      final verified=await widget.auth.api('/api/verify-payment',payload:{
        'id':createdId,
        'razorpay_order_id':result.orderId,
        'razorpay_payment_id':result.paymentId,
        'razorpay_signature':result.signature,
      });
      if(verified['payment_state']=='captured'){
        await widget.store.clearBag();
        _message('Test payment verified by DEMOR server. Order $createdId is in My Orders.');
      }else{
        _message('Payment processing for $createdId. Check My Orders before retrying.');
      }
    }catch(_){_message('Could not verify payment yet. Order $createdId was saved. Check My Orders; do not pay again until verified.');}
  }
  void _failure(PaymentFailureResponse result) => _message('Payment was not completed. Order $createdId is saved; check My Orders before retrying.');
  void _wallet(ExternalWalletResponse result) => _message('External wallet selected. Wait for verification, then check My Orders.');

  @override
  Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('DEMOR Checkout')),
    body:SafeArea(child:SingleChildScrollView(padding:const EdgeInsets.all(20),child:Form(key:formKey,child:Column(
      crossAxisAlignment:CrossAxisAlignment.stretch,children:[
      const Text('Delivery details',style:TextStyle(fontFamily:'serif',fontSize:28)),
      const SizedBox(height:8),
      Text('Account: ${widget.auth.email??'Please log in'}',style:const TextStyle(color:muted)),
      const SizedBox(height:12),
      for(final k in ['name','phone','address','city','state','pincode','notes']) ...[
        TextFormField(controller:fields[k],textCapitalization:k=='name'||k=='city'||k=='state'?TextCapitalization.words:TextCapitalization.none,
          keyboardType:k=='phone'||k=='pincode'?TextInputType.phone:TextInputType.text,
          maxLines:k=='address'?3:1,decoration:InputDecoration(labelText:k[0].toUpperCase()+k.substring(1)),
          validator:(v){if(k=='notes')return null;
            if(v==null||v.trim().isEmpty)return 'Required';
            if(k=='pincode'&&!RegExp(r'^\d{6}$').hasMatch(v.trim()))return 'Enter 6 digit PIN';
            if(k=='phone'&&!RegExp(r'^[0-9+ ()-]{10,18}$').hasMatch(v.trim()))return 'Enter valid mobile number';
            return null;}),
        const SizedBox(height:12),
      ],
      const SizedBox(height:10),Text('Amount: ${rupees(widget.store.subtotal)}',style:const TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
      const SizedBox(height:10),
      const Text('TEST PREVIEW: New order submission is locked until we explicitly enable test-only checkout and verify backend payment settings. Even test orders can reserve live stock.',
        style:TextStyle(color:Color(0xFF8B5220),height:1.5)),
      if(warning!=null)Padding(padding:const EdgeInsets.symmetric(vertical:16),child:Text(warning!,style:const TextStyle(color:forest,height:1.4))),
      const SizedBox(height:18),FilledButton(
        onPressed:(!_allowTestCheckout||busy)?null:checkout,
        child:Padding(padding:const EdgeInsets.all(14),child:Text(!_allowTestCheckout?'Order placement locked for testing':busy?'Please wait…':'Place TEST order & Pay'))),
      const SizedBox(height:12),
      OutlinedButton(onPressed:()=>Navigator.push(context,MaterialPageRoute<void>(builder:(_)=>NativeOrdersPage(auth:widget.auth))),
        child:const Text('View My Orders')),
    ])))),
  );
}
