import 'dart:convert';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';
import 'demor_auth.dart';
part 'native_screens.dart';

const forest = Color(0xFF225D50);
const ink = Color(0xFF1C2D27);
const canvas = Color(0xFFFAF8F4);
const muted = Color(0xFF7B7C70);
const gold = Color(0xFFC0A076);
const liveHost = 'demor.in';
final demorAuth = DemorAuth();

String rupees(int value) {
  final raw = value.toString();
  if (raw.length <= 3) return '₹$raw';
  final last = raw.substring(raw.length - 3);
  var lead = raw.substring(0, raw.length - 3);
  final parts = <String>[];
  while (lead.length > 2) {
    parts.insert(0, lead.substring(lead.length - 2));
    lead = lead.substring(0, lead.length - 2);
  }
  if (lead.isNotEmpty) parts.insert(0, lead);
  return '₹${parts.join(',')},$last';
}

int asInt(dynamic value, [int fallback = 0]) =>
    value is num ? value.toInt() : int.tryParse('$value') ?? fallback;

String categoryName(String category) => switch (category) {
      'kurtas' => 'Kurtas',
      'kurta-pajama-sets' => 'Kurta Sets',
      'nehru-jackets' => 'Nehru Jackets',
      'blazers' => 'Blazers',
      'jodhpuri' => 'Jodhpuri',
      _ => 'Menswear',
    };

class Product {
  final String id;
  final String name;
  final String description;
  final String category;
  final String fabric;
  final String color;
  final int price;
  final int? compareAt;
  final Map<String, int> stock;
  final bool newArrival;
  final bool bestSeller;
  final String? image;

  Product.fromJson(Map<String, dynamic> m)
      : id = '${m['id'] ?? ''}',
        name = '${m['name'] ?? ''}',
        description = '${m['description'] ?? ''}',
        category = '${m['category'] ?? ''}',
        fabric = '${m['fabric'] ?? ''}',
        color = '${m['color'] ?? ''}',
        price = asInt(m['price']),
        compareAt = m['compareAt'] == null ? null : asInt(m['compareAt']),
        stock = Map<String, int>.fromEntries(
          (m['stock'] is Map ? (m['stock'] as Map).entries : <MapEntry<dynamic, dynamic>>[])
          .map((e) => MapEntry(e.key.toString(), asInt(e.value))),
        ),
        newArrival = m['newArrival'] == true,
        bestSeller = m['bestSeller'] == true,
        image = (m['art'] is Map && (m['art'] as Map)['image'] is String)
            ? '${(m['art'] as Map)['image']}'
            : null;

  List<String> get sizes => ['S', 'M', 'L', 'XL', 'XXL']
      .where((s) => (stock[s] ?? 0) > 0)
      .toList();
  bool get inStock => sizes.isNotEmpty;
  String? get imageUrl => image == null || image!.isEmpty
      ? null
      : Uri.https(liveHost, image!.split('?').first,
              image!.contains('?')
                  ? Uri.parse(image!).queryParameters
                  : null)
          .toString();
}

class CartLine {
  final String id;
  final String size;
  final int qty;
  const CartLine(this.id, this.size, this.qty);
  Map<String, dynamic> toJson() => {'id': id, 'size': size, 'qty': qty};
  static CartLine? fromJson(dynamic d) {
    if (d is! Map) return null;
    final id = '${d['id'] ?? ''}';
    final size = '${d['size'] ?? ''}';
    final qty = asInt(d['qty']);
    if (!RegExp(r'^[a-z0-9][a-z0-9-]{2,59}$').hasMatch(id) ||
        !['S', 'M', 'L', 'XL', 'XXL'].contains(size) ||
        qty < 1 ||
        qty > 20) {
      return null;
    }
    return CartLine(id, size, qty);
  }
}

/// No payment secrets, database URLs, or admin credentials belong in this app.
/// Product pricing and stock always come from the existing DEMOR backend.
class DemorStore extends ChangeNotifier {
  List<Product> products = [];
  List<CartLine> bag = [];
  Set<String> saved = {};
  bool loading = true;
  String? error;

  Product? byId(String id) {
    for (final p in products) {
      if (p.id == id) return p;
    }
    return null;
  }

  Future<void> initialize() async {
    final prefs = await SharedPreferences.getInstance();
    try {
      final decoded = jsonDecode(prefs.getString('demor_bag_1') ?? '[]');
      if (decoded is List) {
        bag = decoded.map(CartLine.fromJson).whereType<CartLine>().toList();
      }
    } catch (_) {
      bag = [];
    }
    saved = (prefs.getStringList('demor_saved_1') ?? []).toSet();
    notifyListeners();
    await refresh();
  }

  Future<void> refresh() async {
    loading = true;
    error = null;
    notifyListeners();
    try {
      final response = await http
          .get(Uri.https(liveHost, '/api/catalog'))
          .timeout(const Duration(seconds: 18));
      if (response.statusCode != 200) {
        throw Exception('Store temporarily unavailable (${response.statusCode})');
      }
      final data = jsonDecode(response.body);
      if (data is! List) throw const FormatException('Unexpected product response');
      products = data
          .whereType<Map<String, dynamic>>()
          .map(Product.fromJson)
          .where((p) => p.id.isNotEmpty && p.price > 0)
          .toList();
    } catch (_) {
      error = 'Products could not be loaded. Check internet and try again.';
    } finally {
      loading = false;
      notifyListeners();
    }
  }

  Future<void> _persist() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('demor_bag_1', jsonEncode(bag.map((e) => e.toJson()).toList()));
    await prefs.setStringList('demor_saved_1', saved.toList());
  }

  Future<void> toggleSaved(String id) async {
    if (!saved.add(id)) saved.remove(id);
    notifyListeners();
    await _persist();
  }

  String? addToBag(Product product, String size) {
    if (!product.sizes.contains(size)) return 'This size is unavailable.';
    final index = bag.indexWhere((e) => e.id == product.id && e.size == size);
    final current = index < 0 ? 0 : bag[index].qty;
    if (current >= (product.stock[size] ?? 0) || current >= 20) {
      return 'Not enough stock available.';
    }
    if (index < 0) {
      bag = [...bag, CartLine(product.id, size, 1)];
    } else {
      bag[index] = CartLine(product.id, size, current + 1);
    }
    notifyListeners();
    _persist();
    return null;
  }

  void adjust(CartLine line, int delta) {
    final p = byId(line.id);
    final max = p?.stock[line.size] ?? 0;
    final next = line.qty + delta;
    if (next > max || next > 20) return;
    bag = bag.where((e) => !(e.id == line.id && e.size == line.size)).toList();
    if (next > 0) bag.add(CartLine(line.id, line.size, next));
    notifyListeners();
    _persist();
  }

  Future<void> clearBag() async {
    bag = [];
    notifyListeners();
    await _persist();
  }

  int get bagCount => bag.fold(0, (sum, line) => sum + line.qty);
  int get subtotal => bag.fold(0, (sum, line) {
        final p = byId(line.id);
        return sum + (p?.price ?? 0) * line.qty;
      });
  bool get bagValid => bag.isNotEmpty && bag.every((line) {
        final p = byId(line.id);
        return p != null && (p.stock[line.size] ?? 0) >= line.qty;
      });


}

Future<void> visitWebsite(BuildContext context, Uri url) async {
  try {
    final ok = await launchUrl(url, mode: LaunchMode.externalApplication);
    if (!ok && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not open the browser.')));
    }
  } catch (_) {
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not open the browser.')));
    }
  }
}

void main() => runApp(const DemorApp());

class DemorApp extends StatelessWidget {
  const DemorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'DEMOR – Men\'s Fashion',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: canvas,
        colorScheme: ColorScheme.fromSeed(seedColor: forest),
        fontFamily: 'Roboto',
        appBarTheme: const AppBarTheme(backgroundColor: canvas, foregroundColor: ink, elevation: 0),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none),
        ),
      ),
      home: const MainShell(),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  final store = DemorStore();
  int tab = 0;
  String category = '';

  @override
  void initState() {
    super.initState();
    store.initialize();
    demorAuth.initialize();
  }

  @override
  void dispose() {
    store.dispose();
    super.dispose();
  }

  void showCategory(String selected) {
    setState(() {
      category = selected;
      tab = 1;
    });
  }

  void openProduct(Product product) {
    Navigator.push(context, MaterialPageRoute<void>(
      builder: (_) => ProductDetails(product: product, store: store),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (_, __) => Scaffold(
        appBar: AppBar(
          title: const Text('D E M O R', style: TextStyle(fontFamily: 'serif', fontWeight: FontWeight.w600, fontSize: 24, letterSpacing: 3)),
          actions: [
            IconButton(
              tooltip: 'Search fashion', icon: const Icon(Icons.search),
              onPressed: () => showCategory(''),
            ),
            Stack(children: [
              IconButton(
                tooltip: 'Shopping bag', icon: const Icon(Icons.shopping_bag_outlined),
                onPressed: () => setState(() => tab = 3),
              ),
              if (store.bagCount > 0)
                Positioned(right: 2, top: 2, child: CircleAvatar(
                  backgroundColor: forest, radius: 9,
                  child: Text('${store.bagCount}', style: const TextStyle(color: Colors.white, fontSize: 10)),
                )),
            ]),
            const SizedBox(width: 8),
          ],
        ),
        body: IndexedStack(index: tab, children: [
          HomeScreen(store: store, onCategory: showCategory, onProduct: openProduct),
          ShopScreen(store: store, category: category, onProduct: openProduct),
          SavedScreen(store: store, onProduct: openProduct),
          BagScreen(store: store, auth: demorAuth),
          NativeAccountScreen(auth: demorAuth),
        ]),
        bottomNavigationBar: NavigationBar(
          height: 72,
          backgroundColor: const Color(0xFFF5F2EC),
          indicatorColor: const Color(0xFFDCEAE1),
          selectedIndex: tab,
          onDestinationSelected: (value) => setState(() => tab = value),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
            NavigationDestination(icon: Icon(Icons.grid_view_outlined), selectedIcon: Icon(Icons.grid_view), label: 'Shop'),
            NavigationDestination(icon: Icon(Icons.favorite_border), selectedIcon: Icon(Icons.favorite), label: 'Saved'),
            NavigationDestination(icon: Icon(Icons.shopping_bag_outlined), selectedIcon: Icon(Icons.shopping_bag), label: 'Bag'),
            NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Account'),
          ],
        ),
      ),
    );
  }
}

class HomeScreen extends StatelessWidget {
  final DemorStore store;
  final ValueChanged<String> onCategory;
  final ValueChanged<Product> onProduct;
  const HomeScreen({super.key, required this.store, required this.onCategory, required this.onProduct});

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: store.refresh,
      child: ListView(padding: const EdgeInsets.only(bottom: 24), children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 42),
          decoration: const BoxDecoration(gradient: LinearGradient(
            begin: Alignment.topLeft, end: Alignment.bottomRight,
            colors: [Color(0xFFF1E7D7), Color(0xFFDFE8DE)],
          )),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('THE MODERN INDIAN WARDROBE', style: TextStyle(color: forest, fontSize: 11, letterSpacing: 2.3, fontWeight: FontWeight.bold)),
            const SizedBox(height: 25),
            const Text('Tradition.\nMade for your moment.', style: TextStyle(color: ink, fontSize: 35, fontWeight: FontWeight.w500, height: 1.13, fontFamily: 'serif')),
            const SizedBox(height: 20),
            const Text('Modern blazers, Jodhpuri and occasion wear designed for your moments.', style: TextStyle(color: ink, height: 1.55, fontSize: 15)),
            const SizedBox(height: 24),
            FilledButton.icon(onPressed: () => onCategory(''), icon: const Icon(Icons.arrow_forward, size: 16), label: const Text('EXPLORE COLLECTION'),
              style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 18))),
          ]),
        ),
        const SectionTitle('SHOP BY CATEGORY', 'Find your signature look'),
        SizedBox(height: 118, child: ListView(
          scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 17),
          children: const [
            _CategoryData('Blazers', 'blazers', Icons.checkroom),
            _CategoryData('Jodhpuri', 'jodhpuri', Icons.auto_awesome_outlined),
            _CategoryData('Kurtas', 'kurtas', Icons.style_outlined),
            _CategoryData('Kurta Sets', 'kurta-pajama-sets', Icons.layers_outlined),
            _CategoryData('Nehru Jackets', 'nehru-jackets', Icons.dry_cleaning_outlined),
          ].map((item) => CategoryTile(item: item, onTap: () => onCategory(item.key))).toList(),
        )),
        const SectionTitle('CURATED FOR YOU', 'The latest from DEMOR'),
        if (store.loading) const Center(child: Padding(padding: EdgeInsets.all(30), child: CircularProgressIndicator()))
        else if (store.error != null) ErrorPanel(message: store.error!, retry: store.refresh)
        else if (store.products.isEmpty) const EmptyPanel('Our collection is being updated. New styles are coming soon.')
        else Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: ProductGrid(
          products: [
            ...store.products.where((p) => p.newArrival),
            ...store.products.where((p) => !p.newArrival),
          ].take(6).toList(),
          store: store, onProduct: onProduct,
        )),
        const SizedBox(height: 20),
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 17),
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(color: forest, borderRadius: BorderRadius.circular(18)),
          child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('DEMOR', style: TextStyle(color: gold, letterSpacing: 4, fontSize: 13)),
            SizedBox(height: 12),
            Text('Style for every occasion.', style: TextStyle(color: Colors.white, fontFamily: 'serif', fontSize: 25)),
            SizedBox(height: 6),
            Text('Explore considered menswear, from everyday essentials to celebration styles.', style: TextStyle(color: Colors.white70, height: 1.5)),
          ]),
        ),
      ]),
    );
  }
}

class _CategoryData {
  final String label;
  final String key;
  final IconData icon;
  const _CategoryData(this.label, this.key, this.icon);
}

class CategoryTile extends StatelessWidget {
  final _CategoryData item;
  final VoidCallback onTap;
  const CategoryTile({super.key, required this.item, required this.onTap});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 5),
    child: InkWell(
      onTap: onTap, borderRadius: BorderRadius.circular(16),
      child: Container(
        width: 113, padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFFE8E5DC))),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(item.icon, color: forest, size: 30), const SizedBox(height: 10),
          Text(item.label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, color: ink, fontWeight: FontWeight.w600)),
        ]),
      ),
    ),
  );
}

class SectionTitle extends StatelessWidget {
  final String label;
  final String title;
  const SectionTitle(this.label, this.title, {super.key});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.fromLTRB(20, 30, 16, 14),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(label, style: const TextStyle(color: forest, letterSpacing: 2.1, fontWeight: FontWeight.w700, fontSize: 10)),
      const SizedBox(height: 5),
      Text(title, style: const TextStyle(color: ink, fontFamily: 'serif', fontSize: 24)),
    ]),
  );
}

class ShopScreen extends StatefulWidget {
  final DemorStore store;
  final String category;
  final ValueChanged<Product> onProduct;
  const ShopScreen({super.key, required this.store, required this.category, required this.onProduct});
  @override
  State<ShopScreen> createState() => _ShopScreenState();
}

class _ShopScreenState extends State<ShopScreen> {
  String query = '';
  String sort = 'Featured';
  late String category;
  @override
  void initState() { super.initState(); category = widget.category; }
  @override
  void didUpdateWidget(covariant ShopScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.category != widget.category) category = widget.category;
  }
  @override
  Widget build(BuildContext context) {
    final list = widget.store.products.where((p) =>
      (category.isEmpty || p.category == category) &&
      (query.isEmpty || '${p.name} ${p.fabric} ${p.color} ${p.category}'.toLowerCase().contains(query.toLowerCase()))
    ).toList();
    if (sort == 'Price: Low to High') list.sort((a, b) => a.price.compareTo(b.price));
    if (sort == 'Price: High to Low') list.sort((a, b) => b.price.compareTo(a.price));
    if (sort == 'New Arrivals') list.sort((a, b) => (b.newArrival ? 1 : 0).compareTo(a.newArrival ? 1 : 0));

    return RefreshIndicator(onRefresh: widget.store.refresh, child: ListView(children: [
      const SectionTitle('DISCOVER', 'Explore the collection'),
      Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: TextField(
        decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search kurtas, blazers, Jodhpuri...'),
        onChanged: (text) => setState(() => query = text),
      )),
      SizedBox(height: 58, child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.fromLTRB(14, 14, 14, 0), children: [
        for (final c in ['', 'blazers', 'jodhpuri', 'kurtas', 'kurta-pajama-sets', 'nehru-jackets'])
          Padding(padding: const EdgeInsets.only(right: 8), child: ChoiceChip(
            selected: category == c,
            label: Text(c.isEmpty ? 'All' : categoryName(c)),
            onSelected: (_) => setState(() => category = c),
          )),
      ])),
      Padding(padding: const EdgeInsets.fromLTRB(16, 9, 16, 12), child: Row(children: [
        Text('${list.length} styles', style: const TextStyle(color: muted)),
        const Spacer(),
        DropdownButton<String>(value: sort, underline: const SizedBox(), items: [
          'Featured', 'New Arrivals', 'Price: Low to High', 'Price: High to Low',
        ].map((s) => DropdownMenuItem(value: s, child: Text(s, style: const TextStyle(fontSize: 13)))).toList(), onChanged: (s) => setState(() => sort = s ?? sort)),
      ])),
      if (widget.store.loading) const Center(child: Padding(padding: EdgeInsets.all(40), child: CircularProgressIndicator()))
      else if (widget.store.error != null) ErrorPanel(message: widget.store.error!, retry: widget.store.refresh)
      else if (list.isEmpty) const EmptyPanel('No matching styles. Try another category or search.')
      else Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: ProductGrid(
        products: list, store: widget.store, onProduct: widget.onProduct,
      )),
      const SizedBox(height: 28),
    ]));
  }
}

class ProductGrid extends StatelessWidget {
  final List<Product> products;
  final DemorStore store;
  final ValueChanged<Product> onProduct;
  const ProductGrid({super.key, required this.products, required this.store, required this.onProduct});
  @override
  Widget build(BuildContext context) => LayoutBuilder(builder: (context, constraints) => GridView.builder(
    shrinkWrap: true,
    physics: const NeverScrollableScrollPhysics(),
    itemCount: products.length,
    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
      crossAxisCount: constraints.maxWidth > 700 ? 3 : 2,
      crossAxisSpacing: 12, mainAxisSpacing: 12,
      childAspectRatio: 0.59,
    ),
    itemBuilder: (_, i) => ProductCard(product: products[i], store: store, onTap: () => onProduct(products[i])),
  ));
}

class ProductCard extends StatelessWidget {
  final Product product;
  final DemorStore store;
  final VoidCallback onTap;
  const ProductCard({super.key, required this.product, required this.store, required this.onTap});
  @override
  Widget build(BuildContext context) => InkWell(
    onTap: onTap, borderRadius: BorderRadius.circular(15),
    child: Container(
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(15), border: Border.all(color: const Color(0xFFECE7DF))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Expanded(child: Stack(fit: StackFit.expand, children: [
          ProductPhoto(product: product),
          Positioned(top: 8, left: 8, child: product.inStock ? (product.newArrival ? const SmallTag('NEW') : const SizedBox.shrink()) : const SmallTag('SOLD OUT')),
          Positioned(right: 5, top: 5, child: IconButton.filledTonal(
            visualDensity: VisualDensity.compact,
            tooltip: 'Save product',
            icon: Icon(store.saved.contains(product.id) ? Icons.favorite : Icons.favorite_border, color: forest, size: 20),
            onPressed: () => store.toggleSaved(product.id),
          )),
        ])),
        Padding(padding: const EdgeInsets.fromLTRB(11, 9, 11, 13), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(categoryName(product.category).toUpperCase(), style: const TextStyle(fontSize: 10, letterSpacing: 0.9, color: forest)),
          const SizedBox(height: 4),
          Text(product.name, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: ink)),
          const SizedBox(height: 6),
          Text(rupees(product.price), style: const TextStyle(color: ink, fontWeight: FontWeight.w700)),
        ])),
      ]),
    ),
  );
}

class SmallTag extends StatelessWidget {
  final String text;
  const SmallTag(this.text, {super.key});
  @override
  Widget build(BuildContext context) => DecoratedBox(
    decoration: BoxDecoration(color: const Color(0xFFEFE6D4), borderRadius: BorderRadius.circular(8)),
    child: Padding(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5), child: Text(text, style: const TextStyle(fontSize: 9, color: ink, fontWeight: FontWeight.w700))),
  );
}

class ProductPhoto extends StatelessWidget {
  final Product product;
  const ProductPhoto({super.key, required this.product});
  @override
  Widget build(BuildContext context) {
    final url = product.imageUrl;
    final placeholder = Container(
      decoration: const BoxDecoration(gradient: LinearGradient(colors: [Color(0xFFE9E3D9), Color(0xFFDCE8DE)], begin: Alignment.topLeft, end: Alignment.bottomRight)),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        const Icon(Icons.checkroom, color: Color(0xFF6C8378), size: 42),
        const SizedBox(height: 8),
        Text('DEMOR', style: TextStyle(color: forest.withValues(alpha: 0.7), letterSpacing: 3, fontFamily: 'serif', fontSize: 13)),
        const SizedBox(height: 4),
        const Text('PHOTO COMING SOON', style: TextStyle(color: muted, fontSize: 8, letterSpacing: 0.7)),
      ]),
    );
    if (url == null) return placeholder;
    return Image.network(url, fit: BoxFit.cover, errorBuilder: (_, __, ___) => placeholder);
  }
}

class ErrorPanel extends StatelessWidget {
  final String message;
  final Future<void> Function() retry;
  const ErrorPanel({super.key, required this.message, required this.retry});
  @override
  Widget build(BuildContext context) => Padding(padding: const EdgeInsets.all(25), child: Column(children: [
    const Icon(Icons.wifi_off_outlined, color: muted, size: 39),
    const SizedBox(height: 10), Text(message, textAlign: TextAlign.center),
    const SizedBox(height: 10), OutlinedButton(onPressed: retry, child: const Text('Try again')),
  ]));
}

class EmptyPanel extends StatelessWidget {
  final String text;
  const EmptyPanel(this.text, {super.key});
  @override
  Widget build(BuildContext context) => Padding(padding: const EdgeInsets.symmetric(horizontal: 35, vertical: 60), child: Column(children: [
    const Icon(Icons.inventory_2_outlined, size: 44, color: muted), const SizedBox(height: 14),
    Text(text, textAlign: TextAlign.center, style: const TextStyle(color: muted, height: 1.5)),
  ]));
}

class ProductDetails extends StatefulWidget {
  final Product product;
  final DemorStore store;
  const ProductDetails({super.key, required this.product, required this.store});
  @override
  State<ProductDetails> createState() => _ProductDetailsState();
}

class _ProductDetailsState extends State<ProductDetails> {
  String? size;
  @override
  Widget build(BuildContext context) {
    final p = widget.product;
    return Scaffold(
      appBar: AppBar(title: const Text('DEMOR', style: TextStyle(fontFamily: 'serif', letterSpacing: 4))),
      body: ListView(children: [
        AspectRatio(aspectRatio: 1, child: ProductPhoto(product: p)),
        Padding(padding: const EdgeInsets.fromLTRB(23, 22, 23, 38), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(categoryName(p.category).toUpperCase(), style: const TextStyle(fontSize: 11, letterSpacing: 2, color: forest, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          Text(p.name, style: const TextStyle(fontFamily: 'serif', fontSize: 29, color: ink)),
          const SizedBox(height: 11),
          Row(children: [
            Text(rupees(p.price), style: const TextStyle(fontSize: 25, color: ink, fontWeight: FontWeight.bold)),
            const SizedBox(width: 12),
            if (p.compareAt != null && p.compareAt! > p.price)
              Text(rupees(p.compareAt!), style: const TextStyle(color: muted, decoration: TextDecoration.lineThrough)),
          ]),
          const SizedBox(height: 22),
          if (p.fabric.isNotEmpty) Text('${p.fabric}  ·  ${p.color}', style: const TextStyle(color: muted)),
          const SizedBox(height: 19),
          const Text('SELECT SIZE', style: TextStyle(color: ink, fontWeight: FontWeight.w600, letterSpacing: 1)),
          const SizedBox(height: 11),
          Wrap(spacing: 9, runSpacing: 9, children: [
            for (final s in ['S', 'M', 'L', 'XL', 'XXL'])
              ChoiceChip(
                label: Text(s),
                selected: size == s,
                onSelected: (p.stock[s] ?? 0) == 0 ? null : (_) => setState(() => size = s),
              ),
          ]),
          const SizedBox(height: 16),
          Text(p.inStock ? 'Available sizes: ${p.sizes.join(', ')}' : 'Currently out of stock', style: const TextStyle(color: muted)),
          const SizedBox(height: 23),
          SizedBox(width: double.infinity, child: FilledButton.icon(
            icon: const Icon(Icons.shopping_bag_outlined),
            label: Text(p.inStock ? 'ADD TO BAG' : 'SOLD OUT'),
            style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 19)),
            onPressed: !p.inStock ? null : () {
              if (size == null) {
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Select a size first.')));
                return;
              }
              final error = widget.store.addToBag(p, size!);
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error ?? 'Added to your shopping bag.')));
            },
          )),
          const SizedBox(height: 25),
          const Divider(),
          const SizedBox(height: 12),
          const Text('PRODUCT DETAILS', style: TextStyle(fontWeight: FontWeight.bold, color: ink, letterSpacing: 1)),
          const SizedBox(height: 11),
          Text(p.description.isEmpty ? 'More details coming soon.' : p.description, style: const TextStyle(color: muted, height: 1.55)),
          const SizedBox(height: 23),
          const Text('Designed for DEMOR. Add a size to your bag without leaving the app.',
            style: TextStyle(color: muted, fontSize: 12)),
        ])),
      ]),
    );
  }
}

class SavedScreen extends StatelessWidget {
  final DemorStore store;
  final ValueChanged<Product> onProduct;
  const SavedScreen({super.key, required this.store, required this.onProduct});
  @override
  Widget build(BuildContext context) {
    final picks = store.products.where((p) => store.saved.contains(p.id)).toList();
    return ListView(children: [
      const SectionTitle('YOUR EDIT', 'Saved styles'),
      if (picks.isEmpty) const EmptyPanel('Tap the heart on a product to save your favourite looks.')
      else Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: ProductGrid(products: picks, store: store, onProduct: onProduct)),
    ]);
  }
}

class BagScreen extends StatelessWidget {
  final DemorStore store;
  final DemorAuth auth;
  const BagScreen({super.key, required this.store, required this.auth});

  Future<void> _checkout(BuildContext context) async {
    if (!store.bagValid) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Refresh your bag. One or more items are unavailable.')));
      return;
    }
    if (!auth.signedIn) {
      await Navigator.push(context,MaterialPageRoute<void>(builder:(_)=>NativeLoginPage(auth:auth)));
      if (!auth.signedIn || !context.mounted) return;
    }
    if (context.mounted) {
      Navigator.push(context,MaterialPageRoute<void>(builder:(_)=>NativeCheckoutScreen(store:store,auth:auth)));
    }
  }

  // Deliberately transfers only product IDs, sizes and quantities. No account
  // credentials or personal data are sent through a URL. Price and availability
  // remain controlled by DEMOR's live catalogue and checkout backend.
  Future<void> _openBagOnWebsite(BuildContext context) async {
    if (!store.bagValid) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('One or more items are unavailable. Please update your bag first.'),
      ));
      return;
    }
    final data = jsonEncode(store.bag.map((item) => item.toJson()).toList());
    final payload = base64Url.encode(utf8.encode(data)).replaceAll('=', '');
    if (payload.length > 8000) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Your bag is too large to transfer.'),
      ));
      return;
    }
    final link = Uri.parse('https://demor.in/cart.html#demor_app_cart=$payload');
    await visitWebsite(context, link);
  }

  @override
  Widget build(BuildContext context) => ListView(children: [
    const SectionTitle('MY SHOPPING BAG', 'Your selections'),
    if (store.bag.isEmpty) const EmptyPanel('Your bag is empty. Browse the collection and choose a size to get started.')
    else ...[
      for (final line in store.bag)
        Builder(builder: (context) {
          final p = store.byId(line.id);
          final available = p != null && (p.stock[line.size] ?? 0) >= line.qty;
          return Card(
            margin: const EdgeInsets.fromLTRB(16, 0, 16, 12),
            color: Colors.white, elevation: 0,
            child: Padding(padding: const EdgeInsets.all(12), child: Row(children: [
              SizedBox(width: 85, height: 110, child: p == null ? const ColoredBox(color: Color(0xFFE6E4E0)) : ProductPhoto(product: p)),
              const SizedBox(width: 14),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(p?.name ?? 'Product unavailable', maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600)),
                const SizedBox(height: 5), Text('Size ${line.size}', style: const TextStyle(color: muted)),
                const SizedBox(height: 5), Text(rupees((p?.price ?? 0) * line.qty), style: const TextStyle(fontWeight: FontWeight.bold)),
                if (!available) const Padding(padding: EdgeInsets.only(top: 5), child: Text('Update or remove this item', style: TextStyle(color: Colors.red, fontSize: 12))),
                const SizedBox(height: 9),
                Row(mainAxisSize: MainAxisSize.min, children: [
                  _QtyButton(icon: Icons.remove, onTap: () => store.adjust(line, -1)),
                  Padding(padding: const EdgeInsets.symmetric(horizontal: 15), child: Text('${line.qty}', style: const TextStyle(fontWeight: FontWeight.bold))),
                  _QtyButton(icon: Icons.add, onTap: () => store.adjust(line, 1)),
                  const Spacer(),
                  IconButton(icon: const Icon(Icons.delete_outline, color: muted, size: 19), tooltip: 'Remove item', onPressed: () => store.adjust(line, -line.qty)),
                ]),
              ])),
            ])),
          );
        }),
      Padding(padding: const EdgeInsets.fromLTRB(20, 22, 20, 34), child: Column(children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          const Text('Subtotal', style: TextStyle(fontSize: 18)),
          Text(rupees(store.subtotal), style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
        ]),
        const SizedBox(height: 11),
        const Text('Final stock and price are rechecked by DEMOR before placing an order.', style: TextStyle(fontSize: 12, color: muted)),
        const SizedBox(height: 19),
        SizedBox(width: double.infinity, child: FilledButton(
          onPressed: store.bagValid ? () => _checkout(context) : null,
          style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 18)),
          child: const Text('CONTINUE TO SECURE CHECKOUT'),
        )),
        const SizedBox(height: 12),
        SizedBox(width: double.infinity, child: OutlinedButton.icon(
          onPressed: store.bagValid ? () => _openBagOnWebsite(context) : null,
          icon: const Icon(Icons.open_in_browser),
          label: const Text('OPEN THIS BAG ON DEMOR.IN'),
        )),
        const SizedBox(height: 7),
        const Text('Transfer your selected items to the website bag. This is a one-way transfer, not automatic cross-device sync.',
          textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: muted)),
        const SizedBox(height: 10),
        TextButton.icon(onPressed: () async {
          final confirmed = await showDialog<bool>(context: context, builder: (dialogContext) => AlertDialog(
            title: const Text('Clear shopping bag?'),
            content: const Text('Only remove these items after you are finished. This does not cancel any existing order.'),
            actions: [TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Keep items')),
              FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Clear bag'))],
          ));
          if (confirmed == true) await store.clearBag();
        }, icon: const Icon(Icons.delete_outline), label: const Text('Clear bag')),
        const SizedBox(height: 14),
        const Text('Native checkout preview. Order submission is currently locked until test safety checks are complete.', textAlign: TextAlign.center, style: TextStyle(color: muted, fontSize: 11)),
      ])),
    ],
  ]);
}

class _QtyButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _QtyButton({required this.icon, required this.onTap});
  @override
  Widget build(BuildContext context) => InkWell(onTap: onTap, borderRadius: BorderRadius.circular(7),
    child: Container(padding: const EdgeInsets.all(6), decoration: BoxDecoration(border: Border.all(color: const Color(0xFFE5E2DB)), borderRadius: BorderRadius.circular(7)),
      child: Icon(icon, size: 17)));
}

class _AccountAction extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback onTap;
  const _AccountAction({required this.label, required this.icon, required this.onTap});
  @override
  Widget build(BuildContext context) => Padding(padding: const EdgeInsets.fromLTRB(17, 0, 17, 10),
    child: ListTile(
      tileColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      leading: Icon(icon, color: forest), title: Text(label, style: const TextStyle(fontWeight: FontWeight.w600)),
      trailing: const Icon(Icons.chevron_right), onTap: onTap,
    ),
  );
}
