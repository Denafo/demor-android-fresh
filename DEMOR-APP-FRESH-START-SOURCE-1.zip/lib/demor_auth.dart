/// DEMOR account access via the EXISTING demor.in Netlify Identity tenant.
/// Tokens are stored in Android encrypted storage, never SharedPreferences.
/// Google login is intentionally not faked: it needs a verified OAuth app link.
import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;

const _origin = 'https://demor.in';
const _identity = '$_origin/.netlify/identity';

class DemorApiException implements Exception {
  final String message;
  final int status;
  const DemorApiException(this.message, [this.status = 0]);
  @override
  String toString() => message;
}

class DemorAuth extends ChangeNotifier {
  static const _secure = FlutterSecureStorage();
  String? _accessToken;
  String? _refreshToken;
  DateTime? _expires;
  String? email;
  String? name;
  bool ready = false;
  Future<String?>? _inFlightRefresh;

  bool get signedIn => _accessToken != null && email != null;

  Future<void> initialize() async {
    try {
      _accessToken = await _secure.read(key: 'demor_native_access_v2');
      _refreshToken = await _secure.read(key: 'demor_native_refresh_v2');
      final t = await _secure.read(key: 'demor_native_expires_v2');
      _expires = t == null ? null : DateTime.tryParse(t);
      if (_refreshToken != null) {
        // A server fetch checks the token and gives us the account identity.
        try {
          await loadUser();
        } catch (_) {
          await logout();
        }
      }
    } catch (_) {
      await logout();
    } finally {
      ready = true;
      notifyListeners();
    }
  }

  Future<Map<String, dynamic>> _decode(http.Response response) async {
    Map<String, dynamic> data;
    try {
      final parsed = jsonDecode(response.body);
      data = parsed is Map<String, dynamic> ? parsed : <String, dynamic>{};
    } catch (_) {
      throw const DemorApiException('Server response could not be read.');
    }
    if (response.statusCode < 200 || response.statusCode >= 300) {
      final error = data['error_description'] ?? data['msg'] ?? data['error'];
      throw DemorApiException(error is String && error.isNotEmpty ? error :
          'Request failed. Please try again.', response.statusCode);
    }
    return data;
  }

  Future<void> _save(Map<String, dynamic> data) async {
    final access = data['access_token'];
    final refresh = data['refresh_token'];
    if (access is! String || refresh is! String || access.isEmpty || refresh.isEmpty) {
      throw const DemorApiException('Login did not return valid credentials.');
    }
    _accessToken = access;
    _refreshToken = refresh;
    _expires = DateTime.now().add(Duration(seconds: (data['expires_in'] is num ? (data['expires_in'] as num).toInt() : 3600) - 60));
    await _secure.write(key: 'demor_native_access_v2', value: _accessToken);
    await _secure.write(key: 'demor_native_refresh_v2', value: _refreshToken);
    await _secure.write(key: 'demor_native_expires_v2', value: _expires!.toIso8601String());
  }

  Future<void> login(String address, String password) async {
    final result = await _decode(await http.post(Uri.parse('$_identity/token'),
      headers: {'Content-Type':'application/x-www-form-urlencoded'},
      body: {'grant_type':'password','username':address.trim(),'password':password},
    ).timeout(const Duration(seconds: 20)));
    await _save(result);
    await loadUser();
  }

  Future<void> signup(String fullName, String address, String password) async {
    await _decode(await http.post(Uri.parse('$_identity/signup'),
      headers: {'Content-Type':'application/json'},
      body: jsonEncode({'email':address.trim(),'password':password,'data':{'full_name':fullName.trim()}}),
    ).timeout(const Duration(seconds: 20)));
    // Identity requires email confirmation; do not claim the user is logged in.
  }

  Future<void> sendPasswordReset(String address) async {
    await _decode(await http.post(Uri.parse('$_identity/recover'),
      headers: {'Content-Type':'application/json'}, body: jsonEncode({'email':address.trim()}),
    ).timeout(const Duration(seconds: 20)));
  }

  Future<String?> accessToken() async {
    if (_refreshToken == null) return null;
    if (_accessToken != null && _expires != null && DateTime.now().isBefore(_expires!)) {
      return _accessToken;
    }
    return _inFlightRefresh ??= _refresh().whenComplete(() => _inFlightRefresh = null);
  }

  Future<String?> _refresh() async {
    try {
      final result = await _decode(await http.post(Uri.parse('$_identity/token'),
        headers: {'Content-Type':'application/x-www-form-urlencoded'},
        body: {'grant_type':'refresh_token','refresh_token':_refreshToken!},
      ).timeout(const Duration(seconds: 20)));
      await _save(result);
      return _accessToken;
    } on DemorApiException catch (e) {
      if (e.status == 400 || e.status == 401) await logout();
      rethrow;
    }
  }

  Future<void> loadUser() async {
    final token = await accessToken();
    if (token == null) return;
    final user = await _decode(await http.get(Uri.parse('$_identity/user'),
      headers: {'Authorization':'Bearer $token'},
    ).timeout(const Duration(seconds: 20)));
    final address = user['email'];
    if (address is! String || address.isEmpty) throw const DemorApiException('Account email is missing.');
    email = address;
    final profile = user['user_metadata'];
    name = profile is Map && profile['full_name'] is String ? profile['full_name'] as String : null;
    notifyListeners();
  }

  Future<Map<String, dynamic>> api(String path, {Map<String, dynamic>? payload}) async {
    final token = await accessToken();
    if (token == null) throw const DemorApiException('Please sign in to continue.', 401);
    final uri = Uri.parse('$_origin$path');
    final headers = <String, String>{'Authorization':'Bearer $token','Accept':'application/json'};
    http.Response response;
    if (payload == null) {
      response = await http.get(uri, headers: headers).timeout(const Duration(seconds: 25));
    } else {
      headers['Content-Type'] = 'application/json';
      // Existing DEMOR backend requires Origin for POST. The bearer token is
      // independently verified by Identity on every customer action.
      headers['Origin'] = _origin;
      response = await http.post(uri,headers:headers,body:jsonEncode(payload)).timeout(const Duration(seconds: 30));
    }
    if (response.statusCode == 401) {
      // Do not auto-repeat an order-creation/payment POST: it may have succeeded.
      if (payload == null) {
        _expires = DateTime.fromMillisecondsSinceEpoch(0);
        final renewed = await accessToken();
        if (renewed != null) {
          final retried = await http.get(uri, headers:{'Authorization':'Bearer $renewed','Accept':'application/json'}).timeout(const Duration(seconds: 25));
          return _decode(retried);
        }
      }
    }
    return _decode(response);
  }

  Future<void> logout() async {
    // Local logout is immediate. Avoid leaving refresh tokens on device.
    _accessToken = null;
    _refreshToken = null;
    _expires = null;
    email = null;
    name = null;
    for (final key in ['demor_native_access_v2','demor_native_refresh_v2','demor_native_expires_v2']) {
      await _secure.delete(key:key);
    }
    notifyListeners();
  }
}
