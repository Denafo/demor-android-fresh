# DEMOR Fashion Android — V2.1 (Bag Transfer Update)

Is release mein Flutter app ka **Login / Signup / Forgot Password / My Orders / Checkout address** screen app ke andar hai. Account system wahi original `https://demor.in/.netlify/identity` use karta hai, naya customer database nahi hai.

### V2 mein kaunse features hain?

- Products, categories, sizes, wishlist, bag: app screens.
- Email/password login, signup + confirmation email, password recovery: native screens talking to existing Netlify Identity.
- User access+refresh token: encrypted Android storage (`flutter_secure_storage`), automatic refresh and logout.
- My Orders: same original DEMOR account se `/api/my-orders` par live data.
- Checkout address form: app ke andar. Razorpay native SDK hooks aur **server-side signature verification** code prepared.
- FIRST TEST BUILD MEIN **ORDER PLACEMENT LOCKED**. Stock changes aur real payments se bachne ke liye `DEMOR_ENABLE_TEST_CHECKOUT` default false hai. Isko bina structured QA ke enable mat karna.

### Google Login ka sach

Netlify Identity Google OAuth ka authorization browser/custom-tab se hota hai. Android app mein secure callback/app-link aur token handoff abhi implement nahi hua; hum Google sign-in ko working **nahi** bol rahe. Google-only accounts abhi native login nahi kar sakte. Iske liye next patch mein verified OAuth return flow banana hai. Web par login hona automatically Android app ke session ko sign-in nahi karta.

### Important build notes

- `flutter create --platforms=android --project-name demor_fashion .`
- `python3 scripts/prepare_android.py` Android minSdk 23 and Internet permission set karta hai.
- `flutter pub get`
- `dart run flutter_launcher_icons`
- `flutter analyze && flutter test && flutter build apk --debug`
- Existing GitHub Actions repo mein V2 ZIP use karne ke liye **workflow unpack line change karni padegi**: `unzip -q DEMOR-FASHION-ANDROID-V2.zip` and `cp -a DEMOR-FASHION-APP/. .`.
- GitHub root mein OLD ZIP aur NEW ZIP dono hain toh existing `unzip -q ./*.zip` command **fail** hogi. Exact new filename use karo.

### Backend and payments

- DEMOR's existing Netlify backend has `/api/my-orders`, `/api/orders`, `/api/create-order`, `/api/verify-payment`. New database, credentials, or Netlify variables app ZIP mein mat daalna.
- Backend already requires and verifies a Netlify Identity Bearer token for account actions. Flutter HTTP client sends `Origin: https://demor.in` for POST to satisfy DEMOR's strict origin check.
- Test checkout is intentionally disabled. Future release needs Google sign in, payment reconciliation review, track/cancel QA, and signed release APK/AAB.

Yeh source ZIP hai, ready-made APK nahi. Dart/Flutter tools is environment mein available nahin the; GitHub Actions par build/test karne ke baad hi APK confirmed maani jayegi.

### V2.1: Website bag transfer
- App bag mein **OPEN THIS BAG ON DEMOR.IN** button.
- Is button se items, sizes aur quantities sirf `https://demor.in/cart.html` ko bheje jaate hain, URL fragment mein. Password ya token kabhi URL mein nahi jayega.
- Web cart mein items merge karne ke liye website par included **DEMOR-WEBSITE-BAG-TRANSFER-V2.1.zip** ka update deploy hona chahiye.
- Yeh **manual one-way transfer** hai, automatic two-way cart synchronization nahin. Full sync ke liye authenticated server-side cart storage required hoga.
- Native payment button previous version ki tarah **locked** hai. Website se actual checkout tabhi karein jab product real ho aur payment setup verify ho.
- GitHub workflow ZIP ka naam `DEMOR-FASHION-ANDROID-V2-1-BAG-TRANSFER.zip` select kare.
