import 'package:flutter_test/flutter_test.dart';
import 'package:demor_fashion/main.dart';

void main() {
  test('Indian rupee formatting', () {
    expect(rupees(999), '₹999');
    expect(rupees(1999), '₹1,999');
    expect(rupees(1234567), '₹12,34,567');
  });
  test('Catalog determines available sizes from actual stock', () {
    final p = Product.fromJson({
      'id': 'demo-blazer', 'name': 'Blazer', 'price': 2999,
      'category': 'blazers', 'stock': {'S': 0, 'M': 2, 'L': 1, 'XL': 0}
    });
    expect(p.sizes, ['M', 'L']);
    expect(p.inStock, true);
  });
  test('Cart quantities and sizes are validated', () {
    expect(CartLine.fromJson({'id': 'sample-blazer', 'size': 'M', 'qty': 1})?.qty, 1);
    expect(CartLine.fromJson({'id': 'sample-blazer', 'size': 'M', 'qty': 21}), null);
    expect(CartLine.fromJson({'id': 'x', 'size': 'M', 'qty': 1}), null);
    expect(CartLine.fromJson({'id': 'sample-blazer', 'size': '<script>', 'qty': 1}), null);
  });
  test('Cart tracks products by ID, size and quantity', () {
    const line = CartLine('demo-blazer', 'M', 2);
    expect(line.toJson(), {'id': 'demo-blazer', 'size': 'M', 'qty': 2});
  });
}
