import {createHash,createHmac,randomBytes,scrypt as scryptCallback,timingSafeEqual} from 'node:crypto';
import {promisify} from 'node:util';
const scrypt=promisify(scryptCallback);
export const hash=value=>createHash('sha256').update(value).digest('hex');
export const random=()=>randomBytes(32).toString('base64url');
export function equal(a,b){const x=Buffer.from(a),y=Buffer.from(b);return x.length===y.length&&timingSafeEqual(x,y)}
export async function passwordHash(password){const salt=randomBytes(16).toString('hex');const key=await scrypt(password,salt,64,{N:16384,r:8,p:1});return `scrypt:${salt}:${key.toString('hex')}`}
export async function passwordMatches(password,encoded){const [type,salt,key]=encoded.split(':');if(type!=='scrypt'||!salt||!key)return false;const actual=await scrypt(password,salt,64,{N:16384,r:8,p:1});return equal(actual.toString('hex'),key)}
export const trackingCode=(secret,key)=>createHmac('sha256',secret).update('order:'+key).digest('base64url');

// RFC 6238 compatible six-digit TOTP. Base32 secret is stored only in Netlify environment.
export function verifyTotp(code,base32,timeMs=Date.now()){
 if(typeof code!=='string'||!/^[0-9]{6}$/.test(code)||typeof base32!=='string'||!/^[A-Z2-7]{16,128}$/i.test(base32))return false;
 const alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';let bits=0,n=0,bytes=[];
 for(const ch of base32.toUpperCase()){n=(n<<5)|alphabet.indexOf(ch);bits+=5;if(bits>=8){bits-=8;bytes.push((n>>>bits)&255)}}
 const key=Buffer.from(bytes);
 for(let drift=-1;drift<=1;drift++){
  const counter=Math.floor(timeMs/30000)+drift;
  const block=Buffer.alloc(8);block.writeBigUInt64BE(BigInt(counter));
  const digest=createHmac('sha1',key).update(block).digest();const offset=digest[19]&15;
  const value=(digest.readUInt32BE(offset)&0x7fffffff)%1000000;
  const wanted=String(value).padStart(6,'0');if(timingSafeEqual(Buffer.from(code),Buffer.from(wanted)))return true;
 }
 return false;
}
