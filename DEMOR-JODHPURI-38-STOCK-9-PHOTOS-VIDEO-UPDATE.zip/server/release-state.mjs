// Generated at build from business-profile.json. Do not edit directly.
export const verifiedForCommerce = true;
