HISTORICAL DOCUMENT (PRE-APPROVAL). See FINAL-APPROVAL-AND-DEPLOY-HINDI.txt for 23 October 2026 owner-approved release instructions.

DEMOR social footer fix - 22 October 2026

CHANGE:
- Facebook, Instagram aur WhatsApp: separate 48px round SVG icon buttons with readable labels below.
- Footer social buttons ke beech 14px gap, 72px per-item width, responsive wrap, keyboard focus.
- 18 footer pages updated. Footer Shop links bhi alag lines par rakhe gaye. Existing links, business/legal pages, account/cart/payment logic untouched.

DEPLOY: GitHub source repo ke existing files update karein, Netlify automatically build karega.
Static Netlify drag-and-drop uploads backend Functions ko deploy nahi karte.

SAFETY: GST certificate/policy-owner approval pending release flags ko badla nahi gaya hai; live checkout gate ki pehle wali condition bani rahegi.

SMOKE CHECK: Mobile browser refresh, footer par 3 distinct icon buttons, tap Facebook / Instagram / WhatsApp. Desktop footer check too.
