import {readFile,writeFile,access} from 'node:fs/promises';
await access(new URL('../server/product-upgrade.sql',import.meta.url));
const details=JSON.parse(await readFile(new URL('../business-profile.json',import.meta.url),'utf8'));
const required=['registeredBusinessAddress','customerSupportEmail','grievanceOfficerName','grievanceOfficerEmail','grievanceOfficerPhone'];
const missing=required.filter(k=>typeof details[k]!=='string'||details[k].trim().length<4);
if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(details.customerSupportEmail||''))missing.push('valid customerSupportEmail');
if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(details.grievanceOfficerEmail||''))missing.push('valid grievanceOfficerEmail');
if(missing.length){
 console.error('BLOCKED: missing public contact details:',[...new Set(missing)].join(', '));
 process.exitCode=1;
}else{
 if(details.gstConfirmedAgainstCertificate!==true||details.policyApprovedByBusinessOwner!==true)
  console.warn('PREVIEW ONLY — business-policy approval and/or certificate reconciliation is pending. Live checkout stays disabled until owner approval and an explicit DEMOR_COMMERCE_ENABLED=true setting.');
 const publicDetails=Object.fromEntries(['legalName','tradeName','brandName','gstin','registeredBusinessAddress','customerSupportEmail','customerSupportPhone','grievanceOfficerName','grievanceOfficerEmail','grievanceOfficerPhone'].map(k=>[k,details[k]]));
 const safe=JSON.stringify(publicDetails).replace(/</g,'\\u003c').replace(/>/g,'\\u003e');
 const script=`/* Generated from business-profile.json at build. Public data only. */\n(()=>{'use strict';const p=${safe};\nconst map={legalName:p.legalName,tradeName:p.tradeName,address:p.registeredBusinessAddress,gstin:p.gstin,email:p.customerSupportEmail,supportPhone:p.customerSupportPhone,officer:p.grievanceOfficerName,grievanceEmail:p.grievanceOfficerEmail,grievancePhone:p.grievanceOfficerPhone};\nfor(const [k,v] of Object.entries(map)){document.querySelectorAll('[data-business-'+k+']').forEach(el=>{el.textContent=v||'Not yet published';if(el.tagName==='A'&&v){if(k==='email'||k==='grievanceEmail')el.href='mailto:'+v;if(k==='grievancePhone'||k==='supportPhone')el.href='tel:'+v.replace(/[^+0-9]/g,'');}})}\n})();\n`;
 await writeFile(new URL('../public/assets/js/business-disclosures.js',import.meta.url),script);
 await writeFile(new URL('../server/release-state.mjs',import.meta.url),`// Generated at build from business-profile.json. Do not edit directly.\nexport const verifiedForCommerce = ${details.gstConfirmedAgainstCertificate===true && details.policyApprovedByBusinessOwner===true};\n`);
 console.log('Storefront built. Confirm live Netlify/Neon/Identity/Razorpay configuration separately.');
}
