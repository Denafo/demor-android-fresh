DEMOR — Desktop Search/Bag spacing + Mobile My Account visibility

Base: DEMOR-PASSWORD-RESET-FIX-FULL-WEBSITE.zip (pre shared-cart V3 rollback version).

Changed ONLY these files:
- public/assets/css/modern.css: desktop search input no longer overflows container; cart spacing; mobile menu scroll and dock layout.
- public/assets/js/modern.js: fifth "My Account" shortcut in mobile bottom navigation.
- public/assets/js/customer-auth.js: insert mobile account link at top of menu rather than at very bottom.

No changes to payments, products, order handling, Netlify Functions, customer account service, database migration, or server code.

IMPORTANT: Verify this base matches current production deployment before uploading. Use test deploy first if possible. Keep production rollback available. After publishing test desktop width 1366/1440 and phone width 360/390; tap menu, account, bag.
