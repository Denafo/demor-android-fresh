DEMOR OPTION 6 — PLUM AUBERGINE + SOFT CREAM
Updated 25 October 2026

WHAT CHANGED
- Site header/footer deep plum, entire storefront ivory/soft cream, DEMOR gold wordmark only.
- Hero updated to A Modern Royalty and editorial styling artwork from the previously selected DEMOR mockup.
- Hero artwork is AI-generated editorial inspiration (not a real stock product). Visible disclaimer provided.
- Shop-by-category, product cards, sizes, Sold Out and purchase controls restyled for desktop/mobile.
- No changes to order data, products/prices, admin stock, Netlify server, database, GST, policy approval or payment logic.
- Social links, business contacts and legal disclosures retained as source.

INSTALL
- Upload source into existing GitHub repository, NOT Netlify drag/drop static deploy.
- Run npm run build and inspect Netlify deployment log.
- Check mobile 360/390px and desktop screenshots, signed-in checkout and product listings on staging.
- Live commerce requires separate DEMOR_COMMERCE_ENABLED and thorough payment/invoice/stock verification.

IMPORTANT
- Do not represent hero concept illustration as a product actually available for sale. Replace with original licensed campaign photography when available.
- This ZIP is a layout/design release, NOT a guarantee of legal compliance or live security certification.
