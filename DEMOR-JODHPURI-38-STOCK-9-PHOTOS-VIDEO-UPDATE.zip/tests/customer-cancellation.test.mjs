import {test,before,after} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {PGlite} from '@electric-sql/pglite';
import {makeHandler} from '../server/handler.mjs';
import {passwordHash} from '../server/security.mjs';
const origin='https://demor.in';
const IDENTITY_TEST_TOKEN='aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa';
const identityFetch=async(_url,options)=>new Response(JSON.stringify({id:'test-user-12345678',email:'testbuyer@example.com'}),{status:options.headers.Authorization==='Bearer '+IDENTITY_TEST_TOKEN?200:401,headers:{'Content-Type':'application/json'}});

let db,handler;
const customer={name:'Test buyer',phone:'9999999999',email:'test@example.com',address:'1 Test Lane',city:'Pune',state:'MH',pincode:'411002'};
let serial=0;
async function api(path,data){const req=new Request(origin+path,{method:'POST',headers:{Origin:origin,'Content-Type':'application/json',Authorization:'Bearer '+IDENTITY_TEST_TOKEN},body:JSON.stringify(data)});const r=await handler(req,{ip:'198.51.100.9'});return {status:r.status,data:await r.json()}}
async function order(){serial++;const payload={policyAccepted:true,requestKey:'cancel-test-key-1234567890-'+serial,customer,items:[{id:'dm-001',qty:1,size:'L'}]};const r=await api('/api/orders',payload);assert.equal(r.status,201);return r.data}
before(async()=>{db=new PGlite();for(const file of ['schema.sql','product-upgrade.sql','payments.sql'])await db.exec(await readFile(new URL('../server/'+file,import.meta.url),'utf8'));await db.exec("UPDATE demor_products SET active=true,stock='{\"S\":5,\"M\":5,\"L\":5,\"XL\":5,\"XXL\":5}'::jsonb");handler=makeHandler({query:async(q,p)=>(await db.query(q,p)).rows,env:{DATABASE_URL:'test',DEMOR_ORIGIN:origin,DEMOR_SESSION_SECRET:'longsecret'.repeat(8),DEMOR_OWNER_HASH:await passwordHash('private-owner-pass')},identityFetch})});
after(async()=>db.close());
test('private tracking code is required, cancellation is immediate and restores inventory once',async()=>{
 const beforeStock=(await db.query("SELECT (stock->>'L')::integer AS n FROM demor_products WHERE id='dm-001'")).rows[0].n;
 const o=await order();assert.equal((await api('/api/cancel-order',{id:o.id,token:'wrong-code',reason:'Wrong size selected'})).status,404);
 const result=await api('/api/cancel-order',{...o,reason:'Need another size'});assert.equal(result.status,200);assert.equal(result.data.status,'Cancelled');
 assert.equal((await api('/api/cancel-order',{...o,reason:'Need another size'})).status,409);
 const afterStock=(await db.query("SELECT (stock->>'L')::integer AS n FROM demor_products WHERE id='dm-001'")).rows[0].n;assert.equal(afterStock,beforeStock);
 assert.equal((await api('/api/track',o)).data.status,'Cancelled');
});
test('customer cannot cancel after courier booking begins',async()=>{
 const o=await order();await db.query("UPDATE demor_orders SET delivery='{\"shiprocket\":{\"stage\":\"creating\"}}'::jsonb WHERE id=$1",[o.id]);
 const r=await api('/api/cancel-order',{...o,reason:'I changed my mind'});assert.equal(r.status,409);
 const [stored]=(await db.query('SELECT status FROM demor_orders WHERE id=$1',[o.id])).rows;assert.equal(stored.status,'New');
});
test('customer cannot cancel a dispatched order',async()=>{
 const o=await order();await db.query("UPDATE demor_orders SET status='Shipped' WHERE id=$1",[o.id]);
 assert.equal((await api('/api/cancel-order',{...o,reason:'No longer needed'})).status,409);
});
