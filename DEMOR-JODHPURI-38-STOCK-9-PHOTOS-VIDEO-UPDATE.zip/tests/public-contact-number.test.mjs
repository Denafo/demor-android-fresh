import test from 'node:test';
import assert from 'node:assert/strict';
import {readdir,readFile} from 'node:fs/promises';
import path from 'node:path';
const root=new URL('../public/',import.meta.url);
const previous=['87678','83774'];
const forbidden=[previous.join(' '), '91'+previous.join(''), previous.join('')];
async function walk(location){
  for(const entry of await readdir(location,{withFileTypes:true})){
    const name=path.join(location,entry.name);
    if(entry.isDirectory())await walk(name);
    else if(/\.(?:html|js|css)$/.test(entry.name)){
      const content=await readFile(name,'utf8');
      for(const old of forbidden)assert.ok(!content.includes(old),`${name}: outdated public contact`);
    }
  }
}
test('Old personal number is absent from all published pages and scripts',async()=>{await walk(root.pathname)});
