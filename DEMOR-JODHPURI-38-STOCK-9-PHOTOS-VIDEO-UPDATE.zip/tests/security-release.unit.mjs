import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
import {verifyTotp} from '../server/security.mjs';
const root=new URL('../',import.meta.url);
const read=relative=>readFile(new URL(relative,root),'utf8');

test('TOTP authenticator accepts correct RFC test vector and rejects wrong code',()=>{
 const secret='GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ';
 assert.equal(verifyTotp('287082',secret,59000),true);
 assert.equal(verifyTotp('123456',secret,59000),false);
 assert.equal(verifyTotp('bad code',secret,59000),false);
});
test('build succeeds after business owner approves policy; env gate still protects checkout',()=>{
 const p=spawnSync(process.execPath,['scripts/build.mjs'],{cwd:new URL('../',import.meta.url).pathname,encoding:'utf8',env:{...process.env,DEMOR_COMMERCE_ENABLED:''}});
 assert.equal(p.status,0,p.stderr);
 assert.doesNotMatch(p.stderr,/PREVIEW ONLY/);
});
test('checkout requires affirmative policy acceptance and browser fields',async()=>{
 const checkout=await read('public/checkout.html');
 const server=await read('server/handler.mjs');
 assert.match(checkout,/name="policyAccepted"[^>]*required/);
 assert.doesNotMatch(checkout,/name="policyAccepted"[^>]*checked/);
 assert.match(server,/d\.policyAccepted===true/);
 assert.match(server,/policy_accepted_at/);
});
test('security headers protect framing, transport and content-type',async()=>{
 const headers=await read('netlify.toml');
 for(const s of ['X-Frame-Options','Strict-Transport-Security','Content-Security-Policy','X-Content-Type-Options','Referrer-Policy'])assert.ok(headers.includes(s));
});
test('all store pages with business address use the centrally generated disclosure script',async()=>{
 const fs=await import('node:fs/promises');
 const dir=new URL('../public/',import.meta.url);
 for(const name of await fs.readdir(dir)){
  if(!name.endsWith('.html'))continue;
  const html=await read('public/'+name);
  if(html.includes('data-business-address'))assert.match(html,/business-disclosures\.js/,name);
 }
});
