import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile,readdir} from 'node:fs/promises';
const root=new URL('../',import.meta.url);
const read=path=>readFile(new URL(path,root),'utf8');

test('18 storefront footers have three separate labeled icon buttons',async()=>{
 let count=0;
 for(const file of await readdir(new URL('public/',root))){
  if(!file.endsWith('.html'))continue;
  const html=await read('public/'+file);
  if(!html.includes('<footer class="site-footer">'))continue;
  count++;
  const match=html.match(/<nav class="footer-social"[^>]*>([\s\S]*?)<\/nav>/);
  assert.ok(match,`${file}: missing social nav`);
  const content=match[1];
  assert.equal((content.match(/class="footer-social-link"/g)||[]).length,3,`${file}: missing social links`);
  assert.equal((content.match(/class="social-icon"/g)||[]).length,3,`${file}: missing social icons`);
  assert.equal((content.match(/class="social-label"/g)||[]).length,3,`${file}: missing labels`);
  for(const name of ['Facebook','Instagram','WhatsApp'])assert.ok(content.includes('>'+name+'</span>'),`${file}: ${name}`);
 }
 assert.equal(count,18);
});

test('footer social CSS does not force textual labels inside fixed 36px circles',async()=>{
 const css=await read('public/assets/css/style.css');
 assert.ok(css.includes('gap:14px'));
 assert.ok(css.includes('width:48px; height:48px'));
 assert.ok(css.includes('flex-direction:column'));
 assert.ok(css.includes(':focus-visible'));
 assert.doesNotMatch(css,/\.footer-social a\{\s*width:36px/);
});
