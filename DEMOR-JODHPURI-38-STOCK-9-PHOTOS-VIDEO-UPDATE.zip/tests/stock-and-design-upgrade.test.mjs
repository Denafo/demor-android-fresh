import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile,readdir} from 'node:fs/promises';
import vm from 'node:vm';
const load=async path=>readFile(new URL('../'+path,import.meta.url),'utf8');
test('admin SOLD OUT action is authenticated and atomically clears every size with revision guard',async()=>{
 const api=await load('server/handler.mjs');
 assert.match(api,/if\(path==='\/api\/admin\/product\/sold-out'\)[\s\S]*?await owner\(request\)/);
 assert.match(api,/rate\('admin-stock',ip,120\)/);
 assert.match(api,/Object.fromEntries\(Object.keys\(current.stock\|\|\{\}\).map\(key=>\[key,0\]\)\)/);
 assert.match(api,/UPDATE demor_products SET stock=\$1::jsonb,details=jsonb_set\(details,'\{forceSoldOut\}'/);
 assert.match(api,/WHERE id=\$2 AND revision=\$3 RETURNING/);
 assert.match(api,/check\(rows.length,'Stock changed since loading/);
 const panel=await load('public/assets/js/admin-products.js');
 assert.match(panel,/Mark SOLD OUT · Set every size to 0/);
 assert.match(panel,/confirm\('Mark '/);
 assert.match(panel,/api\/admin\/product\/sold-out/);
 assert.match(panel,/resumeSales=el\('input'\)/);
});
test('manual sold-out override resists cancellation-driven restock and cannot be bought',async()=>{
 const api=await load('server/handler.mjs');
 assert.match(api,/sizes:p.details.forceSoldOut\?\[\]:Object.keys\(p.stock\)/);
 assert.match(api,/stock:p.details.forceSoldOut\?/);
 assert.match(api,/check\(p&&!p.forceSoldOut&&p.sizes.includes\(i.size\)/);
 const shop=await load('public/assets/js/main.js');
 assert.match(shop,/demor-soldout-overlay/);
 assert.match(shop,/data-quick="\$\{p.id\}" \$\{available.length\?'':'disabled'\}/);
});
test('product cards render sold-out and disable purchase when stock is zero',async()=>{
 const js=await load('public/assets/js/main.js');
 const start=js.indexOf('function productCard(p){');const end=js.indexOf('\nfunction renderProductGrid',start);
 const cardFn=js.slice(start,end);
 const sandbox={INR:n=>'₹'+n,categoryLabel:n=>n,garmentSVG:()=>'<svg></svg>',starsMarkup:()=>''};
 vm.runInNewContext(cardFn+'\nthis.render=productCard',sandbox);
 const item={id:'dm-test',name:'Test Jacket',fabric:'Cotton',category:'blazers',sizes:[],stock:{S:0,M:0,L:0,XL:0,XXL:0},price:1500,art:{},care:[],rating:0,reviewCount:0};
 const sold=sandbox.render(item);
 assert.match(sold,/SOLD OUT/);assert.match(sold,/Out of stock — all sizes unavailable/);assert.match(sold,/data-quick="dm-test" disabled/);
 item.sizes=['M'];item.stock.M=3;
 const available=sandbox.render(item);assert.match(available,/Available sizes: M/);assert.doesNotMatch(available,/demor-soldout-overlay/);
});
test('black-white branding CSS, zoom, reduced motion and all storefront pages',async()=>{
 const css=await load('public/assets/css/demor-monochrome.css');
 assert.match(css,/--cream:#fff/);assert.match(css,/--ink:#111/);
 assert.match(css,/\.logo,\.logo span,\.footer-logo,\.footer-logo span,\.art-word\{color:#b89752!important\}/);
 assert.match(css,/prefers-reduced-motion:reduce/);
 const presentation=await load('public/assets/js/presentation.js');
 assert.match(presentation,/demor-image-zoom/);assert.match(presentation,/IntersectionObserver/);
 const pages=(await readdir(new URL('../public',import.meta.url))).filter(f=>f.endsWith('.html')&&!['admin.html','reset-password.html','support.html'].includes(f));
 for(const f of pages){const text=await load('public/'+f);assert.match(text,/assets\/css\/demor-monochrome.css/,f);}
});
