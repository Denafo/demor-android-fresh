import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
const read=async file=>readFile(new URL('../'+file,import.meta.url),'utf8');
test('checkout preview fails closed at client and at /api/orders and payment create',async()=>{
 const handler=await read('server/handler.mjs');const js=await read('public/assets/js/payments.js');
 assert.match(handler,/path==='\/api\/orders'\)\{\s*check\(verifiedForCommerce&&env\.DEMOR_COMMERCE_ENABLED==='true'/);
 assert.match(handler,/path==='\/api\/create-order'\)check\(verifiedForCommerce&&env\.DEMOR_COMMERCE_ENABLED==='true'/);
 assert.match(js,/New orders temporarily paused/);
 assert.match(handler,/path==='\/api\/store-status'/);
});
test('seven-day exchange, shipping costs and consumer rights appear in owner-approved policy',async()=>{
 const page=await read('public/shipping-returns.html');
 for(const word of ['seven calendar days','reverse-courier charge','three working days','defective','original payment method','Approved by the business owner'])assert.ok(page.includes(word),word);
});
test('complaint status never returns private complaint text or contact information',async()=>{
 const handler=await read('server/handler.mjs');
 const scope=handler.split("if(path==='/api/ticket-status')")[1].split("if(path==='/api/tickets')")[0];
 assert.match(scope,/SELECT id,status,created FROM demor_tickets/);
 assert.match(scope,/return reply\(\{id:ticket\.id,status:ticket\.status,receivedAt:ticket\.created\}\)/);
 assert.doesNotMatch(scope,/return reply\(\{[^}]*?(?:email|phone|message|notes)[^}]*\}\)/);
});

test('approval is recorded but actual checkout still requires explicit production switch',async()=>{
 const profile=JSON.parse(await read('business-profile.json'));
 const state=await read('server/release-state.mjs');
 const handler=await read('server/handler.mjs');
 assert.equal(profile.gstConfirmedAgainstCertificate,true);
 assert.equal(profile.policyApprovedByBusinessOwner,true);
 assert.match(state,/verifiedForCommerce = true/);
 assert.match(handler,/verifiedForCommerce&&env\.DEMOR_COMMERCE_ENABLED==='true'/);
});
