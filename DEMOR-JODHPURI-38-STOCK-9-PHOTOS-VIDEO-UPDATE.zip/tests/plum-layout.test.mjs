import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root=new URL('../',import.meta.url).pathname;
const pub=path.join(root,'public');
const css=fs.readFileSync(path.join(pub,'assets/css/demor-plum.css'),'utf8');
const home=fs.readFileSync(path.join(pub,'index.html'),'utf8');
const profile=JSON.parse(fs.readFileSync(path.join(root,'business-profile.json'),'utf8'));
test('Plum + cream theme is present across shopping and legal pages',()=>{
  assert.match(css,/--plum:#38172d/);
  assert.match(css,/--cream-warm:#fff7ee/);
  for(const name of fs.readdirSync(pub).filter(x=>x.endsWith('.html')&&!['admin.html','reset-password.html'].includes(x))){
    assert.match(fs.readFileSync(path.join(pub,name),'utf8'),/assets\/css\/demor-plum\.css/,name);
  }
});
test('Selected editorial homepage is accessible and not advertised as available inventory',()=>{
 assert.match(home,/A Modern/);
 assert.match(home,/plum-hero-title/);
 assert.match(home,/editorial styling photograph.*not an actual DEMOR product listing/);
 assert.match(home,/Hero artwork is styling inspiration/);
 assert.match(home,/href="shop.html"/);
 assert.ok(fs.statSync(path.join(pub,'assets/images/plum-editorial-inspiration.webp')).size>10000);
});
test('Existing approval, contact, social and sold-out integrations are preserved',()=>{
 assert.equal(profile.gstConfirmedAgainstCertificate,true);
 assert.equal(profile.policyApprovedByBusinessOwner,true);
 assert.match(home,/\+91 77588 60145/);
 assert.match(home,/https:\/\/wa\.me\/917758860145/);
 assert.match(home,/https:\/\/www\.facebook\.com\/share\//);
 assert.match(home,/https:\/\/www\.instagram\.com\/demorethnic/);
 assert.match(fs.readFileSync(path.join(pub,'assets/js/main.js'),'utf8'),/soldout|sold-out|Sold out|SOLD OUT/i);
});
