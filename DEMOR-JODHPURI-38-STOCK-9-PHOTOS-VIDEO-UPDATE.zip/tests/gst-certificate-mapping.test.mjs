import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
const read=async file=>readFile(new URL('../'+file,import.meta.url),'utf8');
test('GST REG-06 reference details are represented exactly in business profile',async()=>{
 const profile=JSON.parse(await read('business-profile.json'));
 assert.equal(profile.gstin,'27HBNPM6784E1ZY');
 assert.equal(profile.legalName,'Darshan Manoj Mohite');
 assert.equal(profile.tradeName,'D M Enterprise');
 assert.equal(profile.businessConstitution,'Proprietorship');
 assert.match(profile.registeredBusinessAddress,/PRAPHMESH/);
 assert.match(profile.registeredBusinessAddress,/Anandnagar S\.O\./);
 assert.match(profile.registeredBusinessAddress,/411051/);
 assert.equal(profile.gstConfirmedAgainstCertificate,true);
 assert.equal(profile.policyApprovedByBusinessOwner,true,'business owner approved the current policy text on 23 October 2026');
});
test('legal identity is not confused with business trade name across public pages',async()=>{
 const business=await read('public/business-information.html');
 const terms=await read('public/terms-conditions.html');
 assert.match(business,/Legal name \(proprietor\)/);
 assert.match(business,/Registered trade name/);
 assert.match(terms,/Legal seller: <strong>Darshan Manoj Mohite<\/strong>/);
 assert.doesNotMatch(business,/D M Enterprises/);
});
