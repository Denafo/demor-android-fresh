import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile,readdir} from 'node:fs/promises';
const root=new URL('../',import.meta.url);
const read=async path=>readFile(new URL(path,root),'utf8');
const fb='https://www.facebook.com/share/1FPD54z7fE/';
const ig='https://www.instagram.com/demorethnic?vrfl=MW5yaGo5dnFka2dmeA==';
const whatsapp='https://wa.me/917758860145';
test('Facebook and Instagram appear alongside WhatsApp in all public storefront footers',async()=>{
 let n=0;
 for(const filename of await readdir(new URL('public/',root))){
  if(!filename.endsWith('.html'))continue;
  const html=await read('public/'+filename);
  if(!html.includes('<footer class="site-footer">'))continue;
  n++;
  const footer=html.split('<footer class="site-footer">')[1];
  for(const link of [fb,ig,whatsapp])assert.ok(footer.includes('href="'+link+'"'),`${filename} missing ${link}`);
  assert.ok(footer.includes('rel="noopener noreferrer"'),filename);
  assert.ok(footer.includes('aria-label="DEMOR official social media"'),filename);
 }
 assert.equal(n,18);
});
test('Contact page shows correspondence address at bottom, accessible legal info and social links',async()=>{
 const html=await read('public/contact.html');
 const addr=html.indexOf('id="registered-business-address-title"');
 const form=html.indexOf('id="contact-form"');
 const footer=html.indexOf('<footer class="site-footer">');
 assert.ok(addr>form && footer>addr);
 assert.ok(html.includes('data-business-address'));
 assert.ok(html.includes('href="business-information.html"'));
 assert.ok(html.includes('Follow DEMOR'));
 for(const link of [fb,ig,whatsapp])assert.ok(html.includes(link));
});
test('Provided grievance identity and correspondence address populate public disclosure script',async()=>{
 const script=await read('public/assets/js/business-disclosures.js');
 for(const item of ['Darshan Manoj Mohite','contect@demor.in','77588 60145','PRAPHMESH','411051']) assert.ok(script.includes(item),item);
 assert.ok(!script.includes('policyApprovedByBusinessOwner'));
});
