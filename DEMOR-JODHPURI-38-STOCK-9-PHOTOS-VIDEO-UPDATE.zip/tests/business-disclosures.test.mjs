import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile,readdir} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
import vm from 'node:vm';
const root=new URL('../',import.meta.url);
async function file(name){return readFile(new URL(name,root),'utf8')}
test('dedicated business page discloses legal entity, location and customer rights',async()=>{
 const html=await file('public/business-information.html');
 for(const fragment of ['Darshan Manoj Mohite','D M Enterprise','data-business-legalName','data-business-tradeName','data-business-address','data-business-gstin','data-business-email','data-business-supportPhone','data-business-officer','data-business-grievanceEmail','data-business-grievancePhone','support.html','privacy-policy.html','shipping-returns.html'])assert.ok(html.includes(fragment),fragment);
 assert.match(html,/<main class="section section--tight">/);
});
test('storefront footers contain directly visible business information link',async()=>{
 let count=0;
 for(const name of await readdir(new URL('public/',root))){
  if(!name.endsWith('.html'))continue;
  const html=await file('public/'+name);
  if(!html.includes('<footer class="site-footer">'))continue;
  count++;
  const footer=html.split('<footer class="site-footer">')[1];
  assert.ok(footer.includes('href="business-information.html"'),name);
  assert.ok(footer.includes('data-business-address'),name);
 }
 assert.ok(count>=15,`only ${count} store pages found`);
});
test('build succeeds after recorded GST certificate and business policy approvals',()=>{
 const run=spawnSync(process.execPath,['scripts/build.mjs'],{cwd:new URL('../',import.meta.url),env:{PATH:process.env.PATH,HOME:process.env.HOME},encoding:'utf8'});
 assert.equal(run.status,0,run.stderr);
 assert.doesNotMatch(run.stderr,/PREVIEW ONLY/);
});
test('generated business data has no private build flags and renders text safely',async()=>{
 const js=await file('public/assets/js/business-disclosures.js');
 assert.doesNotMatch(js,/policyApprovedByBusinessOwner/);
 assert.doesNotMatch(js,/gstConfirmedAgainstCertificate/);
 const el={tagName:'SPAN',textContent:''};
 const document={querySelectorAll(selector){return selector==='[data-business-gstin]'?[el]:[]}};
 vm.runInNewContext(js,{document},{timeout:1000});
 assert.ok(el.textContent.startsWith('27'));
});
