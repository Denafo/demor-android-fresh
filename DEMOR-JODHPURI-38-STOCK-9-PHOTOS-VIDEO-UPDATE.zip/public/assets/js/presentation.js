/* DEMOR visual enhancements: accessible zoom and subtle progressive reveal, no third-party scripts. */
(()=>{'use strict';
 const reduced=window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
 if(!reduced&&'IntersectionObserver' in window){
  const observe=new IntersectionObserver((entries)=>{for(const entry of entries){if(entry.isIntersecting){entry.target.classList.add('demor-revealed');observe.unobserve(entry.target)}}},{threshold:0.07,rootMargin:'0px 0px 50px 0px'});
  const scan=()=>document.querySelectorAll('.product-card:not([data-reveal-ready]),.occasion-card:not([data-reveal-ready]),.demor-category-card:not([data-reveal-ready])').forEach(el=>{el.dataset.revealReady='true';el.classList.add('demor-reveal');observe.observe(el)});
  scan();new MutationObserver(scan).observe(document.body,{childList:true,subtree:true});
 }
 document.addEventListener('click',(event)=>{
  const control=event.target.closest?.('.demor-image-zoom');if(!control)return;
  const source=control.closest('.pd-gallery-main')?.querySelector('img,svg');if(!source)return;
  const dialog=document.createElement('dialog');dialog.className='demor-zoom-dialog';dialog.setAttribute('aria-label','Enlarged product image');
  const close=document.createElement('button');close.type='button';close.textContent='Close ×';close.className='demor-zoom-close';
  const artwork=source.cloneNode(true);artwork.removeAttribute('id');
  dialog.append(close,artwork);document.body.append(dialog);
  const dismiss=()=>{dialog.close();dialog.remove();control.focus()};
  close.onclick=dismiss;dialog.addEventListener('cancel',e=>{e.preventDefault();dismiss()});
  dialog.addEventListener('click',e=>{if(e.target===dialog)dismiss()});
  if(typeof dialog.showModal==='function')dialog.showModal();else dialog.setAttribute('open','');
 });
})();
