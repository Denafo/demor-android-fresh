let productRequest=0;
async function renderProducts(){
 const out=$('#records'),request=++productRequest;
 out.replaceChildren(el('p','Loading products…'));
 try{
  const products=await api('/api/admin/products');if(tab!=='products'||request!==productRequest)return;
  out.replaceChildren();
  const intro=el('section'),add=el('button','+ Add product');
  const prepared=el('button','Prepare Steel Blue Jodhpuri · 9 photos + video · Size 38: 1');
  intro.append(el('h2','Products & stock'),el('p','Stock is the quantity still available to sell. New orders reduce it automatically. Cancelling an unshipped new order restores it. Existing orders from before this upgrade do not change stock.'),el('p','Sample products start as drafts with zero stock. Check details, upload a real photo, enter available quantities, then publish. Editing stock replaces the available quantity.'),add,prepared);out.append(intro);add.onclick=()=>editProduct({id:'',revision:0,details:{category:'kurtas',sizeSystem:'alpha',care:[]},stock:{},active:false});
  prepared.onclick=()=>{if(products.some(p=>p.id==='dm-steel-blue-jodhpuri')){$('#message').textContent='Steel Blue already exists. Edit its existing record instead.';return}const paths=['01-front.webp','02-back.webp','03-collar.webp','04-pocket-chain.webp','05-angle.webp','06-sleeve.webp','07-hem.webp','08-buttons.webp','09-fabric.webp','10-product-video.mp4'].map(name=>'/assets/product-media/steel-blue-jodhpuri/'+name);editProduct({id:'dm-steel-blue-jodhpuri',revision:0,details:{name:'Steel Blue Textured Jodhpuri',category:'jodhpuri',sizeSystem:'numeric',price:0,compareAt:null,mrp:null,fabric:'Confirm actual fabric before publishing',color:'Steel Blue',description:'Steel blue Jodhpuri with textured shimmer, stand collar, decorative buttons and pocket chain. Check the physical garment for exact material and measurements.',care:[],media:paths},stock:{34:0,36:0,38:1,40:0,42:0,44:0,46:0,48:0},active:false})};
  const q=$('#search').value.toLowerCase();
  products.filter(p=>(p.id+' '+p.details.name).toLowerCase().includes(q)).forEach(p=>{
   const card=el('section'),button=el('button','Edit product / stock'),soldOut=el('button','Mark SOLD OUT · Set every size to 0');
   card.className='demor-stock-card';
   const units=Object.values(p.stock||{}).reduce((sum,n)=>sum+Math.max(0,Number(n)||0),0);
   const paused=!!p.details.forceSoldOut;
   const state=el('strong',paused?'SOLD OUT · sales paused':units?'In stock · '+units+' total pieces':'SOLD OUT · All sizes 0','demor-stock-state');
   if(!units||paused)state.classList.add('is-sold-out');
   soldOut.type='button';soldOut.className='demor-soldout-action';soldOut.disabled=!units||paused;
   const note=el('p','','demor-stock-note');note.setAttribute('role','status');
   card.append(el('h2',p.details.name),el('p',p.id+' · '+(p.active?'Published':'Draft')+' · ₹'+p.details.price),state,el('p',Object.keys(p.stock||{}).map(size=>size+': '+(p.stock?.[size]||0)).join('  |  ')),el('p',p.has_image?'Photo uploaded':'Illustration only — add your product photo'),button,soldOut,note);
   out.append(card);button.onclick=()=>editProduct(p);
   soldOut.onclick=async()=>{
    if(!confirm('Mark '+p.details.name+' SOLD OUT? This sets every configured size to 0. Customers cannot order it until you restock.'))return;
    soldOut.disabled=true;button.disabled=true;note.textContent='Updating all sizes securely…';
    try{
     await api('/api/admin/product/sold-out',{id:p.id,revision:p.revision});
     $('#message').textContent=p.details.name+' marked SOLD OUT across every size.';
     await renderProducts();
    }catch(error){note.textContent=error.message+' Refresh stock and try again.';button.disabled=false;soldOut.disabled=false;}
   };
  });
 }catch(e){if(tab==='products')out.replaceChildren(el('p',e.message+' If this is your first upgrade, run product-upgrade.sql in Neon.'))}
}
function editProduct(p){
 const out=$('#records'),form=el('form'),title=el('h2',p.revision?'Edit '+p.details.name:'New product');out.replaceChildren(title,form);
 const fields={};
 function field(key,label,value,type='text'){const wrap=el('label',label),input=el(type==='textarea'?'textarea':'input');if(type!=='textarea')input.type=type;input.value=value??'';wrap.append(input);form.append(wrap);fields[key]=input;return input}
 field('id','Product ID (unique, e.g. dm-021)',p.id).readOnly=!!p.revision;
 field('name','Product name',p.details.name).required=true;
 const category=select('Category',['kurtas','kurta-pajama-sets','nehru-jackets','blazers','jodhpuri'],p.details.category);form.append(category[0]);fields.category=category[1];
 field('price','Selling price (whole ₹; enter real price before publishing)',p.details.price??0,'number').min=0;
 field('compareAt','Original price (optional, higher than selling price)',p.details.compareAt,'number');
 field('fabric','Fabric',p.details.fabric);field('color','Colour',p.details.color);
 field('description','Description',p.details.description,'textarea');field('care','Care instructions (one per line)',(p.details.care||[]).join('\n'),'textarea');
 form.append(el('h3','Required product disclosures — verify using garment label'));
 field('mrp','MRP in ₹ (inclusive of taxes)',p.details.mrp,'number').min=1;
 field('countryOfOrigin','Country of origin (e.g. India)',p.details.countryOfOrigin);
 field('manufacturer','Manufacturer full name and address',p.details.manufacturer,'textarea');
 field('packer','Packer full name and address',p.details.packer,'textarea');
 field('consumerCare','Product consumer-care phone/email',p.details.consumerCare);
 field('packQuantity','Pack quantity (e.g. 1 piece / set of 2)',p.details.packQuantity);
 field('manufactureMonth','Month/year of manufacture or packing if applicable (e.g. 10/2026)',p.details.manufactureMonth);
 form.append(el('h3','Available stock by size'));
 const kind=select('Size format',['alpha','numeric'],p.details.sizeSystem==='numeric'?'numeric':'alpha');form.append(kind[0]);
 const stockBox=el('div');form.append(stockBox);
 const configuredSizes=()=>kind[1].value==='numeric'?['34','36','38','40','42','44','46','48']:['S','M','L','XL','XXL'];
 function drawStock(){stockBox.replaceChildren();for(const size of ['S','M','L','XL','XXL','34','36','38','40','42','44','46','48'])delete fields['stock_'+size];for(const size of configuredSizes()){const wrap=el('label',size),input=el('input');input.type='number';input.min='0';input.max='100000';input.step='1';input.required=true;input.value=p.stock?.[size]??0;fields['stock_'+size]=input;wrap.append(input);stockBox.append(wrap)}}
 kind[1].onchange=()=>{if(!confirm('Changing the size format will replace the stock fields in this form. Continue?')){kind[1].value=kind[1].value==='numeric'?'alpha':'numeric';return}drawStock()};drawStock();
 const zeroAll=el('button','Set all displayed sizes to 0');
 zeroAll.type='button';zeroAll.className='demor-zero-all';
 zeroAll.onclick=()=>{for(const size of configuredSizes())fields['stock_'+size].value='0';message.textContent='All displayed sizes set to 0. Click Save product to apply.'};
 form.append(zeroAll);
 form.append(el('h3','Gallery · multiple photos and MP4 video'));
 const mediaHelp=el('p','Images and video in the ZIP are already deployed as static files. Enter one path per line below, with video last. This is a media-path editor, not a direct multi-file upload.');form.append(mediaHelp);
 field('media','Deployed media paths (one per line)',(p.details.media||[]).join('\n'),'textarea');
 let resumeSales=null;
 if(p.details.forceSoldOut){
  const wrap=el('label','Enable this sold-out product again after restocking');
  resumeSales=el('input');resumeSales.type='checkbox';wrap.append(resumeSales);
  form.append(el('p','This product was manually marked SOLD OUT. Enter correct available quantities, tick the box below, then save to resume sales.'),wrap);
 }
 const active=select('Visibility',['Draft','Published'],p.active?'Published':'Draft');form.append(active[0]);
 const fresh=field('newArrival','New arrival',undefined,'checkbox');fresh.checked=!!p.details.newArrival;
 const best=field('bestSeller','Feature as bestseller',undefined,'checkbox');best.checked=!!p.details.bestSeller;
 const file=field('photo','Product photo (choose from your phone)',undefined,'file');file.accept='image/jpeg,image/png,image/webp';
 const preview=el('img');preview.style.cssText='max-width:100%;max-height:280px;display:none';form.append(preview);
 let imageValue,photoBusy=false;
 const photoStatus=el('p');form.append(photoStatus);
 file.onchange=async()=>{imageValue=undefined;preview.style.display='none';if(!file.files[0])return;photoBusy=true;photoStatus.textContent='Preparing photo…';save.disabled=true;try{imageValue=await compressPhoto(file.files[0]);preview.src=imageValue;preview.style.display='block';photoStatus.textContent='Photo ready. Save changes to upload it.'}catch(e){file.value='';photoStatus.textContent=e.message}finally{photoBusy=false;save.disabled=false}};
 if(p.has_image){const remove=el('button','Remove existing photo');remove.type='button';remove.onclick=()=>{imageValue='';file.value='';photoStatus.textContent='Photo will be removed when you save.'};form.append(remove)}
 const message=el('p');message.setAttribute('role','status');const save=el('button','Save product'),back=el('button','Back to products');save.type='submit';back.type='button';back.onclick=renderProducts;form.append(message,save,back);
 form.onsubmit=async e=>{e.preventDefault();if(photoBusy)return;save.disabled=true;message.textContent='Saving…';try{
  const details=Object.fromEntries(['name','category','fabric','color','description','care','countryOfOrigin','manufacturer','packer','consumerCare','packQuantity','manufactureMonth'].map(k=>[k,fields[k].value]));details.sizeSystem=kind[1].value;details.media=fields.media.value.split('\n').map(s=>s.trim()).filter(Boolean);details.mrp=fields.mrp.value?Number(fields.mrp.value):null;details.price=Number(fields.price.value);details.compareAt=fields.compareAt.value?Number(fields.compareAt.value):null;details.newArrival=fresh.checked;details.bestSeller=best.checked;details.forceSoldOut=!!p.details.forceSoldOut&&!resumeSales?.checked;
  await api('/api/admin/product',{id:fields.id.value.trim(),revision:p.revision,details,stock:Object.fromEntries(configuredSizes().map(size=>[size,Number(fields['stock_'+size].value)])),active:active[1].value==='Published',...(imageValue!==undefined?{image:imageValue}:{})});$('#message').textContent='Product saved. Refresh the shop to see published changes.';await renderProducts();
 }catch(e){message.textContent=e.message}finally{save.disabled=false}};
 title.scrollIntoView({block:'start',behavior:'smooth'});
}
async function compressPhoto(file){
 if(file.size>20000000)throw Error('Choose a photo smaller than 20 MB.');
 const url=URL.createObjectURL(file),img=new Image();
 try{await new Promise((resolve,reject)=>{img.onload=resolve;img.onerror=()=>reject(Error('Choose a JPEG, PNG or WebP photo.'));img.src=url});let edge=1000;const canvas=document.createElement('canvas');
 for(let attempt=0;attempt<5;attempt++){const scale=Math.min(1,edge/Math.max(img.width,img.height));canvas.width=Math.max(1,Math.round(img.width*scale));canvas.height=Math.max(1,Math.round(img.height*scale));const ctx=canvas.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.drawImage(img,0,0,canvas.width,canvas.height);const data=canvas.toDataURL('image/jpeg',0.78);if(data.length<=280000)return data;edge*=0.75}throw Error('This photo is too large. Choose a smaller photo.');
 }finally{URL.revokeObjectURL(url)}
}
