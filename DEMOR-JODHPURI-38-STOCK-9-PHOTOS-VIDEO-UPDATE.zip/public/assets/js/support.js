for(const [id,endpoint,result] of [['track','track','tracking'],['ticket','tickets','result']]){const f=document.getElementById(id);let requestKey=crypto.randomUUID();f.onsubmit=async e=>{e.preventDefault();const b=f.querySelector('button');b.disabled=true;try{const r=await fetch('/api/'+endpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...Object.fromEntries(new FormData(f)),requestKey})}),d=await r.json();if(!r.ok)throw Error(d.error);document.getElementById(result).textContent=id==='ticket'?'Request received. Save reference: '+d.id:`Order: ${d.id}\nStatus: ${d.status}\nPayment: ${d.payment}\nItem total: ₹${d.total}`;if(id==='ticket'){f.reset();requestKey=crypto.randomUUID()}}catch(e){document.getElementById(result).textContent=e.message}finally{b.disabled=false}}}

// Tracking exposes status only; the complaint reference must be kept private.
const ticketStatusForm=document.getElementById('ticket-status-form');
if(ticketStatusForm)ticketStatusForm.addEventListener('submit',async event=>{
 event.preventDefault();const result=document.getElementById('ticket-status-result'),button=ticketStatusForm.querySelector('button[type="submit"]');
 button.disabled=true;result.textContent='Checking reference…';
 try{const id=String(new FormData(ticketStatusForm).get('id')||'').trim();const response=await fetch('/api/ticket-status',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id})});const data=await response.json();if(!response.ok)throw Error(data.error||'Unable to check status');result.textContent='Reference: '+data.id+' — Current status: '+data.status;}
 catch(error){result.textContent=error.message}finally{button.disabled=false}
});
