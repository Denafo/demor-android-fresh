NOTE (22 OCTOBER 2026): Address and complaint contact details are now entered in business-profile.json but must be verified; read DEMOR-SOCIAL-LEGAL-UPDATE-READ-ME-HINDI.txt first.

DEMOR.in — BUSINESS INFORMATION PAGE UPDATE
===========================================
Source update prepared 21 October 2026. Website not deployed.

KYA BADLA
- Naya page: business-information.html
- Har normal storefront page ke footer mein "Business & Legal Information" link.
- Contact Us aur customer support page se bhi direct link.
- Business page mein D M Enterprise, GSTIN, verified registered address,
  customer care, grievance officer aur refund/privacy/terms links.
- Pura address readable rahega. Koi tiny type, misleading text, ya hiding nahi.
- Existing storefront footer aur Contact page par bhi registered address ka
  provision preserve kiya hai.

ABHI LIVE DEPLOY MAT KAREIN
- business-profile.json me REAL aur CONFIRMED details chahiye:
  registeredBusinessAddress — GST certificate ka full registered address
  customerSupportEmail — working inbox
  grievanceOfficerName — real name
  grievanceOfficerEmail — working inbox
  grievanceOfficerPhone — working contact
  gstConfirmedAgainstCertificate — certificate check ke baad true
  policyApprovedByBusinessOwner — policies verify karke true
- Apna ghar ka address chat mein dena zaroori nahi. File ko privately edit kar
  sakte hain. Upload ke baad public website aur invoices me address dikhega.
- DEMOR_ALLOW_INCOMPLETE_LEGAL=1 sirf local testing ke liye. Isse kabhi production
  mein enable mat karein. npm run build real details se pahle fail hona sahi hai.
- Deployment Git/Netlify build pipeline se karein. public folder ka raw drag-drop
  karke build safety checks bypass mat karein.
- Publish se pehle current Netlify and database ka backup, staging test, payment,
  admin, login, support and mobile tests aur CA/legal review required hain.

VALIDATION
- 23 HTML pages structure and links checked.
- 4 focused business disclosure tests passed.
- Existing full npm test suite incomplete: missing jsdom/pglite package files
  in the available environment. No live penetration test performed.

NOTE
Business Information page identity transparent banata hai; ise bharne se
sab compliance automatically complete hone ki guarantee nahi hoti.
