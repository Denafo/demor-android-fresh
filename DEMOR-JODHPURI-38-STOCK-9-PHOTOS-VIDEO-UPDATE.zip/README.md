*** CURRENT RELEASE: OWNER POLICY APPROVED 23 OCTOBER 2026 ***
Read FINAL-APPROVAL-AND-DEPLOY-HINDI.txt first. Live commerce still requires separate Netlify DEMOR_COMMERCE_ENABLED=true, only after staging/payment/invoice verification.

# LATEST UPDATE — SOCIAL LINKS + BUSINESS CONTACT (22 OCTOBER 2026)

Read `DEMOR-SOCIAL-LEGAL-UPDATE-READ-ME-HINDI.txt` first. Real contact details were supplied and encoded into `business-profile.json`, but **GST certificate matching, email/WhatsApp verification, and owner policy approval remain pending**. Do NOT publish the bundle as certified compliant. The production build intentionally blocks deployment. No live site changes made.

---

# IMPORTANT — SECURITY + LEGAL RELEASE (21 OCTOBER 2026)

This package supersedes earlier readmes. **Read `RELEASE-SECURITY-CHECKLIST-HINDI.txt` FIRST.**
The existing DEMOR business profile is incomplete: verify and fill `business-profile.json`
before attempting the production Netlify build. The production build intentionally fails
until verified business address, support/grievance contacts and owner policy approval are present.
This archive has not been deployed or tested against live payment/provider accounts.

---

# Latest storefront improvement — 15 October 2026

Read `PEHLE-PADHO.txt` and `WEBSITE-UPDATE-15-OCT-2026.md` first for this update. No new database migration or secret is needed when updating the already configured payment store. The setup instructions below are for a fresh installation.

# DEMOR — Razorpay checkout and My Orders

Start with PAYMENT-SETUP.txt and UPGRADE-PAYMENTS.html. Keep the previous ZIP as a backup.

Node 22+, Netlify Functions, Neon PostgreSQL, plain HTML/CSS/JavaScript, Razorpay Node SDK. Secrets belong in Netlify Functions environment variables, not public files.

Includes server-priced payment orders, timing-safe HMAC verification plus captured payment validation, signed webhooks, retry recovery, browser-saved My Orders, and owner-entered delivery details. COD and automatic courier integration are not included.

This update is not live until deployed. Sandbox tests are mocked; perform an actual Razorpay test-mode checkout after configuring new keys. See PAYMENT-SETUP.txt for the complete testing and live-mode checklist.

Validation: 18 automated tests passed (mock gateway + PGlite + DOM frontend tests), production build passed, and Netlify function module imported successfully. Full provider test-mode checkout remains a manual step.
